ACPVI <- function(Y, QY = 1, D = 1, X, centrer = TRUE, cor = T, k = 3, impres = TRUE, graph = TRUE) {
#
#                ACPVI de X par rapport a un triplet (Y,QY,D)
#
#    Entrees
#
# Y matrice des variables a expliquer
# QY metrique des u.s. pour Y : si QY=1 alors QY=Idn, si QY est un vecteur alors QY=diag(vecteur), sinon QY=matrice
# D metrique des variables, si D=1 alors 1/nIdn, si D est un vecteur alors D=diag(vecteur), sinon D=matrice
# X matrice des variables explicatives ou variables instrumemtales
# centrer=F on ne centre pas X et Y, sinon centrer=T
# cor=F on ne reduit pas, centrage et reduction si cor=T
# k nombre de composantes retenues, par defaut 3
# impres impression des resultats si T, si F rien
# graph trace des graphiques si T, si F pas de trace
#
#    Sorties
#
# nomfichX nom du fichier X
# nomfichY nom du fichier Y
# Xini tableau initial
# Yini tableau initial
# X tableau apres eventuel centrage et/ou reduction
# Y tableau apres eventuel centrage et/ou reduction
# Yhat projection de Y sur Im(X) i.e. regression multivariee de Y par X
# Yres Y-Yhat residu
# QY metrique utilisee pour le triplet de Y
# D metrique utilisee pour les u.s. de X et Y
# inertiaY inertie du triplet (Y,QY,D)
# inertiaACPVI inertie du triplet (X,QX,D)
# QX metrique optimale pour X
# k rang de la DSD retenue
# valp vecteur de toutes les valeurs propres de l'ACPVI
# A matrice des k premiers axes de l'ACPVI, des correlations variables de Y composantes si cor=T
# C matrice des k premieres composantes principales de l'ACPVI
# ZA matrice des correlations de X avec les composantes principales de l'ACPVI si cor=T
#
#    Fonctions exterieures appelees
#
#     Dcentred, invgene, acpxqd
#
#                               R.Sabatier
#                              MAJ 03/04/97
#
# lecture des donnees
        nomfichX <- deparse(substitute(X))
        if(!is.matrix(X))                        stop("X n'est pas une matrice")
        X <- as.matrix(X)
        if(length(c(which.inf(X), which.na(X)))) stop("valeurs manquantes ou infinies dans X")
        Xini     <- as.matrix(X)
        nomfichY <- deparse(substitute(Y))
        if(!is.matrix(Y))                        stop("Y n'est pas une matrice")
        Y <- as.matrix(Y)
        if(length(c(which.inf(Y), which.na(Y)))) stop("valeurs manquantes ou infinies dans Y")
        Yini <- as.matrix(Y)
        n <- nrow(X)
        p <- ncol(X)
        q <- ncol(Y)
        if(n != nrow(Y))                         return()
        if(p <= 2)                               return()
        if(impres == FALSE)  graph   <- FALSE
        if(centrer == FALSE) cor     <- FALSE
        if(cor == T)         centrer <- TRUE
        q2 <- q * q
        n2 <- n * n     # calcul de la metrique QY
        imet <- as.numeric(1)
        if(length(QY) == q2) {
                QY <- as.matrix(QY)
                imet <- 2
        }
        if(length(QY) == 1) QY <- diag(q)
        if(length(QY) == q) QY <- diag(QY, nrow = q)        # calcul de la metrique D
        if(length(D) == 1)  D <- diag(rep(1/n, n), nrow = n)
        if(length(D) == n)  D <- diag(D, nrow = n)
        if(length(D) == n2) D <- as.matrix(D)       # centrage et/ou reduction
        centrageX <- Dcentred(X, D = D)
        meanX     <- matrix(centrageX$moy)
        varX      <- matrix(centrageX$var)
        dimnames(meanX) <- list(dimnames(X)[[2]], "moy")
        dimnames(varX)  <- list(dimnames(X)[[2]], "var")
        centrageY       <- Dcentred(Y, D = D)
        meanY           <- matrix(centrageY$moy)
        varY            <- matrix(centrageY$var)
        dimnames(meanY) <- list(dimnames(Y)[[2]], "moy")
        dimnames(varY)  <- list(dimnames(Y)[[2]], "var")
        if(centrer == TRUE) {
                X <- centrageX$Xc
                Y <- centrageY$Xc
        }
        if(cor == TRUE) {
                X <- centrageX$Xcr
                Y <- centrageY$Xcr
        }
# calcul de la metrique optimale QX
        invVX <- invgene(t(X) %*% D %*% X)
        VXY   <- t(X) %*% D %*% Y
        QX    <- invVX %*% VXY %*% QY %*% t(VXY) %*% invVX
        # calcul de quelques valeurs optimales associees a l'ACPVI
        VQY      <- t(Y) %*% D %*% Y %*% QY
        inertiaY <- sum(diag(VQY))
        normY    <- sum(diag(VQY %*% VQY))
        if(impres) {
                cat("__________________________________________________________________\n")
                cat("            - A.C.P.V.I. de X par rapport a un triplet (Y,QY,D) -\n" )
                if(cor == T) {
                        cat("         Pour X : ", nomfichX, "\n")
                        cat("                donnees centrees et reduites\n")
                        cat("                moyenne des variables de X\n")
                        print(t(meanX))
                        cat("                variance des variables de X\n")
                        print(t(varX))
                        cat("         Pour Y : ", nomfichY, "\n")
                        cat("                donnees centrees et reduites\n")
                        cat("                moyenne des variables de Y\n")
                        print(t(meanY))
                        cat("                variance des variables de X\n")
                        print(t(varY))
                        cat("                inertie du triplet de Y :", format(inertiaY), "\n")
                }
                if(centrer == T && cor == F) {
                        cat("         Pour X : ", nomfichX, "\n")
                        cat("                donnees centrees\n")
                        cat("                moyenne des variables de X\n")
                        print(t(meanX))
                        cat("                variance des variables de X\n")
                        print(t(varX))
                        cat("         Pour Y : ", nomfichY, "\n")
                        cat("                donnees centrees\n")
                        cat("                moyenne des variables de Y\n")
                        print(t(meanY))
                        cat("                variance des variables de Y\n")
                        print(t(varY))
                        cat("                inertie du triplet de Y :", format(inertiaY), "\n")
                        cat("__________________________________________________________________\n")
                }
                if(centrer == F) {
                        cat("         Pour X et Y donnees non transformees\n")
                        cat("                inertie du triplet de Y :", format(inertiaY), "\n")
                        cat("__________________________________________________________________\n")
                }
        }
# calcul des differentes matrices
        Yhat <- X %*% invVX %*% VXY     # matrice Y apres projection sur Im(X)
        Yres <- Y - Yhat                # matrice residuelle de Y apres projection sur Im(X)
        varYhat <- matrix(Dcentred(Yhat, D = D)$var)
        dimnames(varYhat) <- list(dimnames(Y)[[2]], "var.expliquee")
        if(impres) {
                cat("__________________________________________________________________\n")
                cat("Variance des variables de Y apres ACPVI\n")
                print(t(varYhat))
        }
# ACPVI
        resACPVI     <- acpxqd(Yhat, Q = QY, D = D, centrer = F, k = k, impres = F,graph = F)
        inertiaACPVI <- resACPVI$inertiaX
        valp         <- resACPVI$valp
        normYhat     <- sum(valp^2)
        C <- resACPVI$C
        k <- resACPVI$k
        A <- resACPVI$A # impression de l'histogramme des valeurs propres
        if(impres) {
                cat("__________________________________________________________________\n")
                cat(paste("Inertie de l'ACPVI                             =",format(inertiaACPVI), "(", format(inertiaACPVI/inertiaY * 100), "%)\n"))
                cat(paste("Carre de la norme de l'ACPVI                   =",format(normYhat), "\n"))
                cat(paste("RV de l'ACPVI                                  =",format(sqrt(normYhat/normY)), "\n"))
                cat(paste("Carre de la distance entre les deux operateurs =",format(normY - normYhat), "\n"))
                cat("__________________________________________________________________\n")
                cat("histogramme des valeurs propres (o ou n) ?\n")
                plth <- scan("", character(), 1)
                if(plth == "o") {
                        par(mfrow = c(1, 1))
                        barplot(valp, space = 2, names = paste("v. p.", 1:q))
                        title("valeurs propres")
                }
        }
#  choix du nombre d'axes si non donne en argument
        cat("__________________________________________________________________\n" )
        valtab <- matrix(0, q, 4)
        dimnames(valtab) <- list(format(1:q), c("val.pro.", "% inert.","% cumul.", " RV"))
        valtab[, 1] <- round(valp, digits = 4)
        valtab[, 2] <- round(valp/inertiaACPVI * 100, digits = 2)
        for(i in 1:q) {
                valtab[i, 3] <- sum(valtab[1:i, 2])
                valtab[i, 4] <- sqrt(sum(valp[1:i]^2)/normY)
        }
        if(k == 0) {
                print(valtab)
                repeat {
                        cat("Combien d'axes voulez-vous ? (<=", q, ")\n")
                        k <- scan("", n = 1)
                        if(k != 0) break
                }
        }
        ZA <- t(C) %*% D %*% X
        dimnames(ZA) <- list(paste("c", format(1:k), sep = ""), dimnames(X)[[2]])
        dimnames(A) <- list(dimnames(Y)[[2]], paste("a", format(1:k), sep = ""))
        dimnames(C) <- list(dimnames(Y)[[1]], paste("c", format(1:k), sep = ""))      
        # aides a l'interpretations eventuels des variables de Y
        if(impres == T) {
                if(imet == 1) {
                        repeat {
                                cat("Aide a l'interpretation des variables (o/n) ?\n")
                                aiv <- scan("", character(), 1)
                                if((length(aiv) == 0) | (aiv == "n")) break
                                else {
                                  aivtab0 <- matrix(0, q, 2)
                                  aivtab1 <- matrix(0, q, k)
                                  aivtab2 <- matrix(0, q, k)
                                  dimnames(aivtab0) <- list(dimnames(Y)[[2]], c("var.exp.", "part"))
                                  dimnames(aivtab1) <- list(dimnames(Y)[[2]], paste("CTR", format(1:k), sep = ""))
                                  dimnames(aivtab2) <- list(dimnames(Y)[[2]], paste("PART", format(1:k), sep = ""))
                                  aivtab0[, 1] <- round(varYhat * 1000, digits = 0)
                                  for(j in 1:k) aivtab1[, j]  <- round((QY[j, j] * A[, j]^2)/valp[j] * 1000, digits = 0)
                                  for(i in 1:q) aivtab2[i,  ] <- round(A[i,  ]^2/varYhat[i] *  1000, digits = 0)
                                  for(i in 1:q) aivtab0[i, 2] <- sum(aivtab2[i,  ])
                                  aivtab <- data.frame(aivtab0, aivtab1,aivtab2)
                                  print(aivtab)
                                }
                        }
                }
        }
# trace des eventuels graphique
        if(graph == T) {
                repeat {
                        cat("graphique pour les composantes (o/n) ?\n")
                        pltc <- scan("", character(), 1)
                        if((length(pltc) == 0) | (pltc == "n")) break
                        else {
                                cat("axe horizontal (<=", k, ") ?\n")
                                pltch <- scan("", numeric(), 1)
                                cat("axe vertical (<=", k, ") ?\n")
                                pltcv <- scan("", numeric(), 1)
                                par(mfrow = c(1, 1), pty = "s")
                                axespar <- c(pltch, pltcv)
                                plot(C[, axespar], xlab = paste("c", axespar[1]," ", round(valp[axespar[1]], digits = 4), "(", round(valp[axespar[1]]/inertiaACPVI * 100,digits = 2), "%)"), ylab = paste("c", axespar[2], " ", round(valp[axespar[2]], digits = 4),"(", round(valp[axespar[2]]/inertiaACPVI *100, digits = 2), "%)"), type = "n")
                                abline(h = 0)
                                abline(v = 0)
                                text(C[, axespar], dimnames(C)[[1]])
                        }
                }
                cat("_______________________________________________________________\n")
                if(cor == F) {
                        repeat {
                                cat("graphique pour les axes (o/n) ?\n")
                                plta <- scan("", character(), 1)
                                if((length(plta) == 0) | (plta == "n")) break

                                  cat("axe horizontal (<=", k, ") ?\n")
                                  pltah <- scan("", numeric(), 1)
                                  cat("axe vertical (<=", k, ") ?\n")
                                  pltav <- scan("", numeric(), 1)
                                  par(mfrow = c(1, 1), pty = "s")
                                  axespar <- c(pltah, pltav)
                                  plot(A[, axespar], xlab = paste("a", axespar[1], " ", round(valp[axespar[1]], digits = 4), "(", round(valp[axespar[1]]/inertiaACPVI *100, digits = 2), "%)"), ylab = paste("a",axespar[2], " ", round(valp[axespar[2]],digits = 4), "(", round(valp[axespar[2]]/inertiaACPVI * 100, digits = 2), "%)"),type = "n")
                                  abline(h = 0)
                                  abline(v = 0)
                                  text(A[, axespar], dimnames(A)[[1]])    
                        }
                }
                else {
                        repeat {
                                cat("cercle des correlations pour les variables de Y (o/n) ?\n")
                                plta <- scan("", character(), 1)
                                if((length(plta) == 0) | (plta == "n")) break
                                else {
                                  cat("axe horizontal (<=", k, ") ?\n")
                                  pltah <- scan("", numeric(), 1)
                                  cat("axe vertical (<=", k, ") ?\n")
                                  pltav <- scan("", numeric(), 1)
                                  par(mfrow = c(1, 1), pty = "s")
                                  axespar <- c(pltah, pltav)
                                  theta   <- seq(0, 20, 0.05)
                                  x       <- cos(theta)
                                  y       <- sin(theta)
                                  plot(x, y, type = "l", xlab = paste("a",axespar[1], " ", round(valp[axespar[1]],digits = 4), "(", round(valp[axespar[1]]/inertiaACPVI * 100, digits = 2), "%)"),ylab = paste("a", axespar[2], " ", round(valp[axespar[2]], digits = 4), "(", round( valp[axespar[2]]/inertiaACPVI * 100, digits= 2), "%)"), type = "n")
                                  abline(h = 0)
                                  abline(v = 0)
                                  text(A[, axespar], dimnames(A)[[1]])
                                }
                        }
                        repeat {
                                cat("cercle des correlations pour les variables de X (o/n) ?\n")
                                plta <- scan("", character(), 1)
                                if((length(plta) == 0) | (plta == "n")) break
                                else {
                                  cat("axe horizontal (<=", k, ") ?\n")
                                  pltah <- scan("", numeric(), 1)
                                  cat("axe vertical (<=", k, ") ?\n")
                                  pltav <- scan("", numeric(), 1)
                                  par(mfrow = c(1, 1), pty = "s")
                                  axespar <- c(pltah, pltav)
                                  theta   <- seq(0, 20, 0.05)
                                  x       <- cos(theta)
                                  y       <- sin(theta)
                                  plot(x, y, type = "l", xlab = paste("a",axespar[1], " ", round(valp[axespar[1]],digits = 4), "(", round(valp[axespar[1]]/inertiaACPVI * 100, digits = 2), "%)"),ylab = paste("a", axespar[2], " ", round( valp[axespar[2]], digits = 4), "(", round(valp[axespar[2]]/inertiaACPVI * 100, digits = 2), "%)"), type = "n")
                                  abline(h = 0)
                                  abline(v = 0)
                                  text(t(ZA[axespar,  ]/sqrt(valp[axespar])),dimnames(ZA)[[2]])
                                }
                        }
                }
        }
        return(list(nomfichX      = nomfichX, 
                    Xini          = Xini, 
                    X             = X, 
                    QX            = QX, 
                    nomfichY      = nomfichY, 
                    Yini          = Yini, 
                    Y             = Y, 
                    QY            = QY, 
                    D             = D, 
                    inertiaACPVI  = inertiaACPVI, 
                    k             = k, 
                    valp          = valp, 
                    A             = A, 
                    C             = C, 
                    ZA            = ZA ))
}