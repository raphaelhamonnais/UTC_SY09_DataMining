kde2d.env <- function(x,y,n=50,lims=c(range(x),range(y)),k=100,w){

if(missing(w)) w <- rep(1,length(x))

ech.length <- length(x)

distrib.0   <-  kde2dw(x,y,n=n,lims=lims,w=w)
Z <- matrix(0,nr=k,nc=n^2)

for(i in 1:k){
  indiv   <- sample(1:ech.length,replace=T) #echantillon bootstrap
  Z[i,]   <- c(kde2dw(x[indiv],y[indiv],n=n,lims=lims,w=w[indiv])$z)   
  cat(i,"\n")
}
lower <- matrix(apply(Z,2,quantile,0.025),nr=n)
upper <- matrix(apply(Z,2,quantile,0.975),nr=n)

return(list(lower=lower,upper=upper))
}
