sphere.correl<-function(axes=c(1,2,3),A,A.sup,col.var=NULL,col.var.sup=NULL,COS2,cex.lim=c(1,1),valp,inertiaX,precision=40,col.axe=T){

XLAB <- paste("c", axes[1], " ", round(valp[axes[1]], digits = 4),
                                  "(", round(valp[axes[1]]/inertiaX * 100,
                                   digits = 2), "%)")

YLAB <- paste("c", axes[2], " ", round(valp[axes[2]], digits = 4),
                                  "(", round(valp[axes[2]]/inertiaX * 100,
                                  digits = 2), "%)")

ZLAB <- paste("c", axes[3], " ", round(valp[axes[3]], digits = 4),
                                  "(", round(valp[axes[3]]/inertiaX * 100,
                                  digits = 2), "%)")

if( is.null(A.sup) ) 	A.tot<-A
else 			      A.tot<-rbind(A,A.sup)
A.tot<-A.tot[,axes] 
COS<-apply(COS2[,axes],1,sum)
N<-dim(A)[1]
nsup<-dim(A.sup)[1]
if(is.null(nsup)) nsup<-0

if(col.axe==F){
  if( (length(col.var)!=0)&(length(col.var)!=1)&(length(col.var)!=N) )                return()
  if( (length(col.var.sup)!=0)&(length(col.var.sup)!=1)&(length(col.var.sup)!=nsup) ) return()

  if( length(col.var)==0 ) col.var<-rep(1,N)
  if( length(col.var)==1 ) col.var<-rep(col.var,N)

  if( length(col.var.sup)==0 ) col.var.sup<-rep(2,nsup)
  if( length(col.var.sup)==1 ) col.var.sup<-rep(col.var.sup,nsup)

  col.tot<-c( col.var , col.var.sup )
}
else {
  sortie.couleurAXE<-couleurAXE(A.tot[,2],axe.lim=c(-1,1))
  col.tot<-sortie.couleurAXE$col.axe
  colors <-sortie.couleurAXE$couleurs
}
cex.var<-cex.lim[1]+ (cex.lim[2]-cex.lim[1])*COS/10000
cex.var.sup<-NULL
if(nsup!=0) {
      cex.var.sup<-rep(cex.lim[2],nsup)        
}
cex.tot<-c( cex.var , cex.var.sup )

library(scatterplot3d)
theta<-seq(0,2*pi,length=precision)
x<-y<-z<-rep(0,precision^2)
for(i in 1:precision)
   for(j in 1:precision){
       x[precision*(i-1)+j]<-sin(theta[j])*cos(theta[i])
       y[precision*(i-1)+j]<-sin(theta[j])*sin(theta[i])
       z[precision*(i-1)+j]<-cos(theta[j])
   }
s3d<-scatterplot3d(x,y,z,color=gray(0.9),type="l",scale=0.8,xlab=XLAB,ylab=YLAB,zlab=ZLAB)
s3d$points3d(z,x,y,type="l",col=gray(0.9))
text(s3d$xyz.convert(A.tot),dimnames(A.tot)[[1]],col=col.tot,cex=cex.tot)
pos000<-s3d$xyz.convert(0,0,0)
posVA<-s3d$xyz.convert(A.tot*0.9)
arrows(pos000$x,pos000$y,posVA$x,posVA$y,lty=c(rep(1,N),rep(2,nsup)),col=col.tot,lwd=2)
if(col.axe){
   y<-seq(-1,1,length=500)
   for(i in 1:500) s3d$points3d(c(0.5,1),rep(y[i],2),rep(-1,2),col=colors[i],type="l")
   s3d$points3d(c(1,1),c(-1,1),c(-1,-1),type="l")
   s3d$box3d()
}
long<-matrix(1,N+nsup,5)
long[,1:3]<-round(A.tot,3)
long[,4]<-round( sqrt(apply(A.tot^2,1,sum)) ,3)
long[,5]<-c(COS,rep(NA,nsup))
dimnames(long)<-list(dimnames(A.tot)[[1]],c(dimnames(A.tot)[[2]],"norme2","COS 2"))
cat("coordonn�es,norme et COS2 des variables actives\n")
print(long[1:N,])
if(nsup>0){
  cat("\ncoordonn�es et norme des variables suppl�mentaires\n")
  print(long[-(1:N),1:4])
}
s3d$box3d()

return(s3d)
}