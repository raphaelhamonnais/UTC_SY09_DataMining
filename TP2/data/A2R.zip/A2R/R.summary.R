R.summary<-function(M){
# summary du mod�le M avec seulement les coefs et l'AIC
cof<-summary(M)$coefficients
if(is.null(cof)){
  cat("modele vide, AIC=",round(AIC(M),2),"\n")
}
else{
  sig<-rep("",dim(cof)[1])
  for(i in 1:dim(cof)[1]) sig[i]<-codeSignif(cof[i,4])

  cat("               Estimate Std. Error   t value    Pr(>|t|) \n")
  cat(paste(format(dimnames(cof)[[1]])," ",
                    format(round(cof[,1],5))," ",
                    format(round(cof[,2],5))," ",
                    format(cof[,3])," ",
                    format(cof[,4])," ",
                    sig,"\n" ),sep="")
  cat("AIC=",AIC(M),"\n")
  cat("Codes signif. 0 �***� 0.001 �**� 0.01 �*� 0.05 �..� 0.1 �.� 0.2 � � 1\n")
}
}