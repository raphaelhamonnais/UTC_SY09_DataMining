codeSignif<- function(p.value,breaks=c(0,0.001,0.01,0.05,0.1,1),code=c("***","**","*",".","")){
# retourne le code correspondant � un chiffre entre 0 et 1 
if(p.value==0) return(code[1])
for(i in 1:(length(breaks)-1)) if((p.value>breaks[i])&(p.value<=breaks[i+1])) return(code[i])
}
