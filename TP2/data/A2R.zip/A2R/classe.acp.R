validAcpObject <- function(a){
#  if(dim(a@Xini)!=dim(a@X)){ 
#     cat("Xini n'a pas les m�mes dimensions que X\n")
#     return(FALSE)
#  }
#  if(!is.matrix(a@X)) {
#    cat("X n'est pas une matrice\n")
#    return(FALSE)
#  }
#  if(is.null(As)) return(TRUE)
#  if(is.null(Cs)) return(TRUE)
 TRUE 
}


setClass("acp",
         representation(nomfichX   = "character", 
                        Xini       = "matrix", 
                        X          = "matrix", 
                        Q          = "matrix", 
                        D          = "matrix", 
                        inertiaX   = "numeric", 
                        k          = "numeric", 
                        valp       = "numeric", 
                        Fa         = "matrix", 
                        A          = "matrix", 
                        CP         = "matrix", 
                        CTRus      = "matrix", 
                        COSus      = "matrix", 
                        CTRva      = "matrix", 
                        COSva      = "matrix", 
                        As         = "matrix", 
                        Cs         = "matrix",
                        cor        = "logical",
                        centrer    = "logical"),      
         validity = validAcpObject       
         )         