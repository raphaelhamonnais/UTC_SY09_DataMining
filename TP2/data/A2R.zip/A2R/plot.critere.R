plot.critere <- function(calc.resul,cex=3,bg=c("purple","magenta","lemonchiffon"),aicmax,aicmin,Y,poids,col.star="red"){
# plot du R2 et du PRESS
##########################

family <- calc.resul$family
aic    <- calc.resul$step.resul$AIC
changes<- calc.resul$step.resul$changements
nb.mod <- length(aic)

modeles<-calc.resul$step.resul$modeles
if(missing(aicmax)) aicmax<-max(aic)
if(missing(aicmin)) aicmin<-min(aic)
rangeaic<-aicmax-aicmin
xlim<-c(0.5,nb.mod+0.5)


if(family=="gaussian"){
   PRESS<-calc.resul$PRESS
   R2   <-calc.resul$R2
   plot(1:nb.mod,PRESS,ylim=c(0,1),xlim=xlim,type="n",axes=F,ylab="",xlab="")
   abline(h=seq(0,1,by=0.05),col=gray(0.8),lty=2)
   axis(2,seq(0,1,by=0.2))
   axis(4,seq(0,1,length=6),labels=round(seq(aicmin,aicmax,length=6)))
   rect((1:nb.mod)-0.2,0,(1:nb.mod)+0.2,(aic-aicmin)/rangeaic,col=bg[3])
   points(1:nb.mod,PRESS,type="o",cex=cex,pch=21,bg=bg[2],col=1,lwd=1.5)
   points(1:nb.mod,R2,type="o",cex=cex,pch=22,bg=bg[1],col=1,lwd=1.5)
   text((1:nb.mod)-0.5,rep(0.075,nb.mod),changes,cex=0.8)
   sig<-rep(NA,nb.mod)
   sig[1]<-codeSignif(anova(glm(Y~0,weights=poids),modeles[[1]],test="F")[2,6])
   for(i in 2:nb.mod) sig[i]<-codeSignif(anova(modeles[[i-1]],modeles[[i]],test="F")[2,6])
   text((1:nb.mod)-0.5,rep(0.025,nb.mod),sig,cex=2,col=col.star)
   box()
   legend(locator(1),c(expression(R^2),"PRESS","AIC"),pch=c(22,21,22),cex=1.5,bg=gray(0.99),pt.bg=bg)
}
if(family=="binomial"){
   AJUS   <-calc.resul$AJUS
   PRED   <-calc.resul$PRED  
   plot(1:nb.mod,PRED,ylim=c(0,100),xlim=xlim,type="n",axes=F,ylab="",xlab="")
   abline(h=seq(0,100,by=5),col=gray(0.8),lty=2)
   axis(2,seq(0,100,by=20))
   axis(4,seq(0,100,length=6),labels=round(seq(aicmin,aicmax,length=6)))
   rect((1:nb.mod)-0.2,0,(1:nb.mod)+0.2,(aic-aicmin)/rangeaic*100,col=bg[3])
   points(1:nb.mod,PRED,type="o",cex=cex,pch=21,bg=bg[2],col=1,lwd=1.5)
   points(1:nb.mod,AJUS,type="o",cex=cex,pch=22,bg=bg[1],col=1,lwd=1.5)
   text((1:nb.mod)-0.5,rep(7.5,nb.mod),changes,cex=0.8)
   sig<-rep(NA,nb.mod)
   sig[1]<-codeSignif(anova(glm(Y~0,weights=poids),modeles[[1]],test="F")[2,6])
   for(i in 2:nb.mod) sig[i]<-codeSignif(anova(modeles[[i-1]],modeles[[i]],test="F")[2,6])
   text((1:nb.mod)-0.5,rep(2.5,nb.mod),sig,cex=2,col=col.star)
   box()
   legend(locator(1),c("% ajust.","% pred.","AIC"),pch=c(22,21,22),cex=1.5,bg=gray(0.99),pt.bg=bg)
}


}