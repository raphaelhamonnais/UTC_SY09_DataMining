####################################################################
STATIS.plot <- function(resul){
k <- length(resul$valp)
par(ask=T)      # hit return to see next plot
x <- as.vector(resul$vect[,1]*sqrt(resul$valp[1]))
y <- as.vector(resul$vect[,2]*sqrt(resul$valp[2]))
plot(c(x,0),c(y,0),xlab="axe 1",ylab="axe 2",type="n")
text(x,y)
arrows(rep(0,k),rep(0,k),x*0.95,y*0.95)
diagWDC <- eigen(round(resul$WDC,6),symmetric=T)
xx <- diagWDC$vectors[,1]*sqrt(diagWDC$values[1])
yy <- diagWDC$vectors[,2]*sqrt(diagWDC$values[2])
plot(xx,yy,xlab="axe 1",ylab="axe 2",type="n")
abline(h=0)
abline(v=0)
text(xx,yy,dimnames(resul$WDC)[[1]])
}