IC<-function(stat,alpha=0.05,trace=T,titre=""){
# intervalle de confiance, test de normalit� (shapiro.test : ctest)
##############"
# entr�es :
# stat      -- statistique
# alpha     -- risque de 1ere espece
# trace     -- trac� des r�sultats
##############
# sorties :
# inf,sup   -- bornes inf et sup de l'IC
# mean      -- la moyenne de la statistique
###############

if(trace){
  cat("------------------- test de normalit� ----------------------------------\n")
  print(shapiro.test(stat))
}
ms<-mean(stat)
sds<-sqrt(var(stat))
quant<-qnorm(1-alpha/2)

BI<-ms-quant*sds
BS<-ms+quant*sds
if(trace){
  cat("----------------- intervalle de confiance � ",100*(1-alpha),"% ----------------------\n")
  cat("borne inf :",BI,"\n")
  cat("moyenne   :",ms,"\n")
  cat("borne sup :",BS,"\n")
  cat("------------------------------------------------------------------------\n")
  d<-density(stat)
  maxy<-max(d$y)
  plot(d,ylim=c(0,maxy*1.1),axes=F,main=titre,ylab="")

  indice1<-(1:512)[abs(d$x-BI)==min(abs(d$x-BI))]
  indice2<-(1:512)[abs(d$x-BS)==min(abs(d$x-BS))]
  indiceM<-(1:512)[abs(d$x-ms)==min(abs(d$x-ms))]

  polygon(x=d$x[c(indice1,indice1:indice2,indice2,indice1)],y=c(0,d$y[indice1:indice2],0,0),col="lavender",border="lavender")
  points(d,type="l",lwd=2)
  arrows(x0=d$x[indice1],x1=d$x[indice2],y0=maxy*1.03,y1=maxy*1.03,code=3,lwd=2)
  text(d$x[indiceM],maxy*1.07,paste("IC (",100*(1-alpha),"%)"),cex=1.7)
  segments(x0=d$x[c(indice1,indice2)],x1=d$x[c(indice1,indice2)],
           y0=c(0,0),y1=rep(maxy*1.03,2),lty=3)
  axis(1,d$x[c(indice1,indiceM,indice2)],round( c(BI,ms,BS) ,3))

}
return(invisible(list(inf=BI,mean=ms,sup=BS)))
}