print.acp <- function(a){
  cat("A.C.P de",a@nomfichX,"\n")
}
