R.step<-function(Y,X,poids,trace.step=F,trace.sum=F,family="gaussian",M){
# s�lection stepwise

N.i<-length(Y)
noms.variables<-c("(Intercept)",dimnames(X)[[2]])
X<-as.data.frame(cbind(rep(1,N.i),X))
dimnames(X)[[2]]<-noms.variables

N.v<-dim(X)[2]
if(missing(poids)) poids<-rep(1,N.i)

stop.step<-F
etape<-0
sortie.modeles<-sortie.changements<-sortie.AIC<-list()
resume.step<-matrix(0,nr=1000,nc=2)
if(missing(M)) {
  M<-glm(Y~0,weights=poids,family=family)
  mod.null<-T
}
else mod.null<-F
AIC.M<-AIC(M)

while(stop.step==F){
  etape<-etape+1 
  modeles<-list()
  modeles[[1]]<-M
  if(trace.sum){
       cat("----------------------------------------------------------------\n")
       cat("�tape ",etape,"\n")
       R.summary(M)    
  }
  changes    <-rep("<none>",N.v+1)
  changes.AIC<-rep(AIC(M),N.v+1)
  indice     <-indice.var(M,X,data.intercept=T)
  
  if(is.null(indice)&(etape>1)) stop("modele nul")  
  if((etape==1)&(mod.null)){
     for(i in 1:N.v){ #parcours des variables de X
         a               <-as.data.frame(X[,i])
         dimnames(a)[[2]]<-noms.variables[i]
         modeles[[1+i]]  <-glm(Y~.-1,data=a,weights=poids)
         changes[1+i]    <-paste("+",noms.variables[i])
         changes.AIC[1+i]<-AIC(modeles[[1+i]])
     }   
  }
  else{
     for(i in 1:N.v){
         ############# cr�ation des indices du mod�le � construire
         if(sum(i==indice)==1){ 
             if(length(indice)==1) indice2<-NULL                                      ## la variable i �tait seule dans le modele pr�c�dent
             else                  indice2<-indice[ -(1:length(indice))[indice==i] ]  ## la variable i etait pas seule dans le mod pr�c�dent
             changes[1+i]<-paste("-",noms.variables[i])
         }
         else{
             indice2<-c(indice,i)                                                    ## la varible i n'�tait pas dans le mod pr�c�cdent
             changes[1+i]<-paste("+",noms.variables[i])
         }
         ############# cr�ation du mod�le
         if(is.null(indice2)) modeles[[1+i]]<-glm(Y~0,weights=poids,family=family)
         else{
            a               <-as.data.frame(X[,indice2])
            dimnames(a)[[2]]<-noms.variables[indice2]
            modeles[[1+i]]  <-glm(Y~.-1,data=a,weights=poids,family=family)
         }
         
         ############# calcul de l'AIC
         changes.AIC[1+i]<-AIC(modeles[[1+i]])
     }
  }
  ordre      <-order(changes.AIC)
  changes    <-changes[ordre]
  changes.AIC<-sort(changes.AIC)
  if(changes.AIC[1]==AIC.M) stop.step<-T
  else{
     if(trace.step){
        cat("----------------------------------------------------------------\n")
        cat("--------------------- stepwise �tape",etape," ------------------------\n")
        cat("----------------------------------------------------------------\n")       
        write.table(cbind(format(changes),round(changes.AIC,2)),quote=F,sep="\t",row.names=F,col.names=F)
     }  
     modeles2<-list()
     for(i in 1:length(changes)) modeles2[[i]]<-modeles[[ ordre[i] ]]
     M<-modeles2[[1]]
     AIC.M<-AIC(M)

     sortie.changements[[etape]]<-changes[1]
     sortie.AIC[[etape]]        <-AIC.M
     sortie.modeles[[etape]]    <-M
  }
}
if(trace.step){
  if(etape==1) stop("pas mieux que le mod�le vide")
  cat("----------------------------------------------------------------\n")
  cat("----------------- r�sum� du stepwise ---------------------------\n")
  cat("----------------------------------------------------------------\n")
  res.ch <-rep("",etape-1)
  res.AIC<-rep(0,etape-1)
  for(i in 1:(etape-1)){
     res.ch[i] <-sortie.changements[[i]]
     res.AIC[i]<-sortie.AIC[[i]]
  }
  write.table(cbind(format(res.ch),round(res.AIC,2)),quote=F,sep="\t",row.names=F,col.names=F)
}
return(invisible(list(modeles     = sortie.modeles,
                      AIC         = in.vector(sortie.AIC),
                      changements = in.vector(sortie.changements),
                      last        = sortie.modeles[[etape-1]])))
}