affecte<-function(X,g,Y,imin=1,imax=nrow(Y),D=1)
{
# entrees:
#       X matrice dont les lignes sont les coordonnees de points
#       g vecteur des modalites des groupes
#       Y matrice des vecteurs lignes des coordonnees des points a affecter;
#                                                       si Y manque, alors Y=X.
#       imin et imax indices des individus de Y a affecter.
#       D vecteur des poids des individus.
# objectif: a quel groupe (a quelle modalite de g) affecter les lignes de Y ?
# sortie : liste de composantes:
#       La matrice des centres de gravite des groupes, A.
#       La metrique de Mahalanobis de X, V.
#       Le vecteur des numero des groupes d'affectation des individus de Y,
#                                                                         groupe.
#       Si Y=X, (Y manquant) alors:
#       Le tableau croisant les groupes reels avec les groupes affectes, tableau.
#--------------------------------------------------------------------
        if(missing(Y)) Y<-as.matrix(X)
        # A matrice des coordonnees des centres de gravites
        # A est max(g) x ncol(X)
        ng   <- max(g)
        codg <- codisj(g)
        G <- Mahalanobis(codg,D)
        if(length(D)==1) A<-G%*%t(codg)%*%X/nrow(X)
                else
                {
                XC<-D*X
                A<-G%*%t(codg)%*%XC
                }
        V<-Mahalanobis(X,D)
        groupe<-rep(0,nrow(Y))
        for(j in imin:imax)
        {
        x<-Y[j,]
        U<-NULL
        for(i in 1:ng) U<-rbind(U,x)
        U<-(U-A)
        UU<-U%*%V
        aa<-NULL
        for(i in 1:ng) aa[i]<-sum(UU[i,]*U[i,])
        distmin<-min(aa)
        i<-0
        repeat
        {i<-i+1
        if(aa[i]==distmin) break
        }
        groupe[j]<-i
        }
        tableau<-matrix(0,ng,ng)
        if(missing(Y)) {
          for(i in 1:nrow(X)) tableau[groupe[i],g[i]] <- tableau[groupe[i],g[i]]+1
          dimnames(tableau)<-list(paste("gaf",format(1:ng)),paste("gr",format(1:ng)))
          return(list(A       = A,
                      V       = V,
                      groupe  = groupe,
                      tableau = tableau))
        }
        else return(list(A       = A,
                         V       = V,
                         groupe  = groupe))
}