calc.critere <- function(Y,X,poids,step.resul,family="gaussian"){
# calcul du R2 et du PRESS lors de la s�lection stepwise
###################
# Y          -- variable � expliquer (quantitative)
# X          -- data.frame ou matrix des pr�dicteurs
# poids      -- � votre avis
# step.resul -- r�sultat de la fonction R.step
################################################################################################ 


if(missing(poids)) poids<-rep(1,length(Y))
modeles<- step.resul$modeles
nb.mod <- length(modeles)

if(family=="gaussian"){ 
   PRESS<- R2<- rep(NA,nb.mod)
   for(i in 1:length(modeles)){
      XV.resul<- XV.predict(Y,X,poids=poids,MOD=modeles[[i]],trace=F)
      PRESS[i]<- XV.resul$PRESS
      R2[i]   <- XV.resul$R2
   }
   return(invisible(list(step.resul = step.resul,
                         PRESS      = PRESS,
                         R2         = R2,
                         family     = "gaussian")))
}
if(family=="binomial"){
   AJUS<-PRED<- rep(NA,nb.mod)
   for(i in 1:length(modeles)){
      XV.resul<- XV.predict(Y,X,poids=poids,MOD=modeles[[i]],trace=F,family="binomial",type="response")
      AJUS[i] <- XV.resul$ajus.p
      PRED[i] <- XV.resul$pred.p
   }
   return(invisible(list(step.resul = step.resul,
                         AJUS       = AJUS,
                         PRED       = PRED,
                         family     = "binomial")))
}

}