arbre.getXlim <- function(arbre # un arbre
                         ){

return(c(1,arbre.getN(arbre)))
}

arbre.getN <- function(arbre){
  if(arbre.isLeaf(arbre)) return(length(arbre))
  else                    return(arbre.getN(arbre$left)+arbre.getN(arbre$right))
}