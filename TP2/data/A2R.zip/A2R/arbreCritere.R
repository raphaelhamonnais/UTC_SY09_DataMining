arbreCritere <- function(d,            ## d matrice de distance
                         hclu,         ## sortie de hclust
                         k.max=20,     ## nombre max de clusters
                         plot=FALSE,   ## afficher les graphiques
                         trace = TRUE, ## afficher la trace du d�roulement des calculs
                         G2=FALSE,
                         G3=FALSE){ 

require(cluster)
require(MASS)
require(fpc)

n.ind <- nrow(as.matrix(d))
criteres <- matrix(0,nc=5,nr=k.max-1)
dimnames(criteres) <- list( 2:k.max , c("dunn","wb","hubertgamma","g2","g3") )

for(i in 2:k.max) {
   if(trace) cat("doing level \t",i,"\t")
   groupes <- cutree(hclu,k=i)
   tmp     <- R.cluster.stats(d,groupes,G2=G2,G3=G3)
   if(is.null(tmp$g2)) tmp$g2 <- NA
   if(is.null(tmp$g3)) tmp$g3 <- NA
   
   criteres[i-1,] <- c(tmp$dunn,tmp$wb,tmp$hubertgamma,tmp$g2,1 - tmp$g3)
   if(trace) cat(" ----> done\n")
}

return(criteres)
}
