Profils<-function(TC,cexpar=1,titlepar=T,bgpar="lavender",spacepar=0.6)
{
# �dition des diagrammes en batons des profils et des marges d'un tableau de contingence
# TC, matrice, tableau de contingence
# cexpar, scalaire, param�tre cex pour l'�dition des graphiques
# titlepar, bool�en, si T le titre du grahique est �dit�.
# bgpar, couleur du background graphique, utiliser aussi "cornsilk" ou "lightgray" utiliser aussi colours()[624]
# spacepar, espacement entre deux batons, par defaut 0.6
#                       Auteur : Jean-Francois Durand 10/10/2001
#
TC<-as.matrix(TC)
I<-nrow(TC)
J<-ncol(TC)
N<-sum(TC)
P<-TC/N
margeC<-apply(P,2,sum)
margeL<-apply(P,1,sum)
ProfilsL<-P/margeL
ProfilsC<-t(t(P)/margeC)
par(ask=T)
par(bg=bgpar)
palette(rainbow(12))
cat("Diagrammes des Profils Lignes + diagramme marge Colonnes\n")
cat("Nombre de graphes par ligne ? (<=",I+1,")\n")
                                            colo<-scan("",numeric(),1)
                                            cat("Nombre de lignes ?\n")
                                            lign<-scan("",numeric(),1)
                                            par(oma=c(0,0,4,0),mfrow=c(lign,colo),pty="s")
for(i in 1:I)
barplot(ProfilsL[i,],ylim=c(0,max(rbind(ProfilsL,margeC))),space=spacepar,main=paste(dimnames(TC)[[1]][i]," (",round(margeL[i],3),")",sep=""),cex.names=cexpar,cex.axis=cexpar)
barplot(margeC,ylim=c(0,max(rbind(ProfilsL,margeC))),space=spacepar,main="Profil Moyen",cex.names=cexpar,cex.axis=cexpar)
if(titlepar)
mtext(side=3,line=0,cex=cexpar+0.5,outer=TRUE,paste("Profils Lignes ","+ Marge Colonne",sep=""))
cat("Diagrammes des Profils Colonnes + diagramme marge Ligne\n")
cat("Nombre de graphes par ligne ? (<=",J+1,")\n")
                                            colo<-scan("",numeric(),1)
                                            cat("Nombre de lignes ?\n")
                                            lign<-scan("",numeric(),1)
                                            par(oma=c(0,0,4,0),mfrow=c(lign,colo),pty="s")
for(i in 1:J)
barplot(ProfilsC[,i],ylim=c(0,max(cbind(ProfilsC,margeL))),space=spacepar,main=paste(dimnames(TC)[[2]][i]," (",round(margeC[i],3),")",sep=""),cex.names=cexpar,cex.axis=cexpar)
barplot(margeL,ylim=c(0,max(cbind(ProfilsC,margeL))),space=spacepar,main="Profil Moyen",cex.names=cexpar,cex.axis=cexpar)
if(titlepar)
mtext(side=3,line=0,cex=cexpar+0.5,outer=TRUE,paste("Profils Colonnes ","+ Marge Ligne",sep=""))
return(list(P        = P,
            margeL   = margeL,
            margeC   = margeC,
            ProfilsL = ProfilsL,
            ProfilsC = ProfilsC))
}