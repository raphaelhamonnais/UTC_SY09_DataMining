Rplot.tree <- function(TR,Y,noms,reg=F,leg.text="",col.0=4,col.1=2,leg.step=2,nomY="Y",rectangles=F){
# trac� plus joli des arbres de segmentation
#############
# entr�es :
# TR         -- l'arbre � dessiner (tree : tree)
# Y          -- variable � expliquer
# noms       -- noms des individus
# reg        -- arbre de r�gression/arbre de classification
# leg.text   -- texte de la l�gende (cas des arbres de classification)
# col.0      -- couleur des individus t.q. Y=0
# col.1      -- couleur des individus t.q. Y=1
# leg.step   -- pas (d�grad�) (cas des arbres de regression)
# nomY       -- nom de la variable Y
# rectangles -- pour dessiner des rectangles � la place des noms des individus ( � utiliser
#               quand il y en a trop
#############
N.ind<-length(Y)
if(missing(noms)) noms<-1:N.ind
if(reg==T){
  YY.lim<-c(trunc(min(Y))-1,trunc(max(Y))+1)
  YY.seq<-seq(YY.lim[1],YY.lim[2],length=500)
  col<-couleurAXE(Y,YY.lim)
  couleurs<-col$couleurs
  col<-col$col.axe
}
else{
  col<-col.0*(Y==0)+col.1*(Y==1)
}
N.ne<-length(TR$frame$var)
ter.ne<-(1:N.ne)[TR$frame$var=="<leaf>"]
Ytext<-rep(0,N.ind)
for(i in ter.ne){ 
  truc<-1*(TR$where==i)
  ordre<-order(Y[truc==1],decreasing=T)
  Y[truc==1]<-Y[truc==1][ordre]
  noms[truc==1]<-noms[truc==1][ordre]
  col[truc==1]<-col[truc==1][ordre]
  j<- -1
  for(k in 1:N.ind) if(truc[k]==1) {
                       Ytext[k]<-j
                       j<-j+1
                    }
}
if(reg==F) ylim<-c(-1,N.ind*1.05)
else       ylim<-c(-3.5,N.ind*1.05)
par(mar=rep(1,4),pty="s")
plot(0,0,type="n",xlim=c(min(ter.ne-0.1),max(ter.ne+0.1)),ylim=ylim,axes=F,ylab="",xlab="",main="")
if(rectangles==F) text(TR$where,Ytext,noms,cex=1.2,col=col)
else              rect(xleft=TR$where-0.15,xright=TR$where+0.15,ybottom=Ytext+0.5,ytop=Ytext+1.5,col=col,border=col)



ne<-matrix(0,nr=3,nc=N.ne)
dimnames(ne)<-list(c("y","truc","x"),1:N.ne)
ne[1,]<-TR$frame$n
ne[2,]<-1*(TR$frame$var=="<leaf>")
ne[3,]<-(1:N.ne)*ne[2,]
list.ne<-list(1:N.ne)
for(i in 1:N.ne) list.ne[[i]]<-(1:N.ind)[TR$where==i]
texte<-paste(TR$frame$var,TR$frame$split[,1],sep="")

while(dim(ne)[2]!=1){
  n.L<-1
  n.R<-2
  while(ne[2,n.L]+ne[2,n.R]!=2){
    n.R<-n.R+1
    n.L<-n.L+1
  }
  racine<-n.L-1
  x.racine<-mean(c(ne[3,n.L],ne[3,n.R]))
  y.racine<-ne[1,racine]
  x.L<-ne[3,n.L]
  x.R<-ne[3,n.R]
  y.R<-ne[1,n.R]
  y.L<-ne[1,n.L]
  p.L<-p.R<-0
  if(texte[n.L]!="<leaf>") p.L<-2
  if(texte[n.R]!="<leaf>") p.R<-2
  ne.L<-as.numeric(dimnames(ne)[[2]][n.L])
  ne.R<-as.numeric(dimnames(ne)[[2]][n.R])
  ne.racine<-as.numeric(dimnames(ne)[[2]][racine])
  points(c(x.L,x.L,x.R,x.R),c(y.L+p.L,y.racine,y.racine,y.R+p.R),type="l")
  indic<-c(rep(1,length(list.ne[[ne.L]])),rep(0,length(list.ne[[ne.R]])))
  if(reg==T) {
     mean.L<- mean(Y[ list.ne[[ne.L]] ])
     col.L<-couleurs[ (1:500)[abs(YY.seq-mean.L)==min( abs(YY.seq-mean.L) )] ]
     if(rectangles==F) text(x.L,y.L-1,substitute( paste(bar(list(a))," = ",list(b)),list(a=nomY,b=round(mean.L,2)) ),cex=1)
     mean.R<- mean(Y[ list.ne[[ne.R]] ])
     col.R<-couleurs[ (1:500)[abs(YY.seq-mean.R)==min( abs(YY.seq-mean.R) )] ]
     if(rectangles==F) text(x.R,y.R-1,substitute( paste(bar(list(a))," = ",list(b)),list(a=nomY,b=round(mean.R,2)) ),cex=1)    
     etoile<-codeSignif(anova(glm(Y[c(list.ne[[ne.L]],list.ne[[ne.R]])]~1),
                              glm(Y[c(list.ne[[ne.L]],list.ne[[ne.R]])]~indic),test="F")[2,6])
     mean.racine<-mean( c( Y[ list.ne[[ne.L]] ],Y[ list.ne[[ne.R]] ] ))
     col.racine<-couleurs[ (1:500)[abs(YY.seq-mean.racine)==min( abs(YY.seq-mean.racine) )] ]
  }
  else{
     nbr1<-sum(Y[ list.ne[[ne.L]] ]==0 )
     nbr2<-sum(Y[ list.ne[[ne.L]] ]==1 )
     if(nbr1>nbr2)  col.L<-col.0
     if(nbr2>nbr1)  col.L<-col.1
     if(nbr1==nbr2) col.L<-"black"
     if(rectangles==F) text(x.L,y.L-1,substitute(paste(n[0]==list(a)," , ",n[1]==list(b)),list(a=nbr1,b=nbr2)),cex=1)
     nbr1<-sum(Y[ list.ne[[ne.R]] ]==0 )
     nbr2<-sum(Y[ list.ne[[ne.R]] ]==1 )
     if(nbr1>nbr2)  col.R<-col.0
     if(nbr2>nbr1)  col.R<-col.1
     if(nbr1==nbr2) col.R<-"black"
     if(rectangles==F) text(x.R,y.R-1,substitute(paste(n[0]==list(a)," , ",n[1]==list(b)),list(a=nbr1,b=nbr2)),cex=1)

     etoile<-codeSignif(anova(glm(Y[c(list.ne[[ne.L]],list.ne[[ne.R]])]~1    ,family="binomial"),
                              glm(Y[c(list.ne[[ne.L]],list.ne[[ne.R]])]~indic,family="binomial"),test="Chi")[2,5])

     nbr1<-sum(Y[ c(list.ne[[ne.R]],list.ne[[ne.L]]) ]==0 )
     nbr2<-sum(Y[ c(list.ne[[ne.R]],list.ne[[ne.L]]) ]==1 )
     if(nbr1>nbr2)  col.racine<-col.0
     if(nbr2>nbr1)  col.racine<-col.1
     if(nbr1==nbr2) col.racine<-"black"
  }
  text(x.racine,y.racine-N.ind/20*(rectangles==T),etoile,col=col.racine,cex=2)
  ne[2,racine]<-1
  ne[3,racine]<-x.racine
  ne<-as.matrix(ne[,-c(n.L,n.R)])
  texte<-texte[-c(n.L,n.R)]
  list.ne[[ne.racine]]<-c(list.ne[[ne.L]],list.ne[[ne.R]])
  points(c(x.L,x.R),c(y.L,y.R),pch=22,bg=c(col.L,col.R),cex=2)  ##noeuds
  text(x.racine,y.racine+N.ind/20,texte[racine],cex=1.5,xpd=NA)
}

if(rectangles==F){
  if(reg==T) text(x.racine,y.racine-1,substitute( paste(bar(list(a))," = ",list(b) ),list(a=nomY,b=round(mean(Y),2)) ),cex=1)   
  else       text(x.racine,y.racine-1,substitute(paste(n[0]==list(a)," , ",n[1]==list(b)),list(a=nbr1,b=nbr2)),cex=0.9,col=col.racine)
}
points(ne[3,1],N.ind,pch=22,bg=col.racine,cex=2)

###### l�gende / d�grad�

if(F) legend(locator(1),leg.text,pt.bg=c(col.1,col.0),pch=21,cex=1.5)
else {
  XX<-seq(min(ter.ne),max(ter.ne),length=500)
  for(i in 1:499) rect(XX[i],-3,XX[i+1],-2,col=couleurs[i],border=couleurs[i])
  ticks<-seq(trunc(min(Y)-1),trunc(max(Y)+1),by=leg.step )
  XX<-seq(min(ter.ne),max(ter.ne),length=length(ticks))
  for(i in 1:length(ticks)) {
    points(rep(XX[i],2),c(-3,-3.5),type="l")
    text(XX[i],-3.8,ticks[i])  
  }
  text(mean(ter.ne),-2.5,leg.text,col="white",font=2,cex=1.2)
  rect(min(ter.ne),-3,max(ter.ne),-2)
}

}