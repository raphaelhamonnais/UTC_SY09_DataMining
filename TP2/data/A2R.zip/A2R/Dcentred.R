Dcentred <- function(X,D=1){
#       D-centrage de la matrice X
#
#          Entree
# X matrice des variables
# D metrique des poids
#          Sorties
# Xc matrice deduite de X, D-centree
# Xcr matrice deduite de X, D-centree et reduite
# moy vecteur des D-moyennes
# var vecteur des D-variances

   X  <- as.matrix(X)
   n  <- nrow(X)
   p  <- ncol(X)
   n2 <- n*n
   n1 <- matrix(1,nrow=n,ncol=1)
   if(length(D)==1)  D <- diag(rep(1/n,n),nrow=n)
   if(length(D)==n)  D <- diag(D,nrow=n)
   if(length(D)==n2) D <- as.matrix(D)
   moy <- t(n1)%*%D%*%X
   Xc  <- sweep(X,2,moy)
   var <- diag(t(Xc)%*%D%*%Xc)
   ect <- sqrt(var)
   Xcr <- sweep(Xc,2,ect,FUN="/")
  return(list(Xc   = Xc,
              Xcr  = Xcr,
              moy  = moy,
              var  = var ))
}