Dcp <- function(X,Y=X,D=1){
# signification de Dcp : Diagonalcrossproduct, i.e., X'DY
# D est un vecteur des poids, par defaut 1/nrow(X)

        Y <- as.matrix(Y)
        X <- as.matrix(X)
        if(length(D)==1) DD <- rep(1/nrow(X),nrow(X)) 
        else             DD <- as.vector(D)
        for(i in 1:nrow(X)) X[i,] <- DD[i]*X[i,]
        V <- crossprod(X,Y)
        dimnames(V)<-NULL
        return(V)
}