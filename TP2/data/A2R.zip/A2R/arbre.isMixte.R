arbre.isMixte <- function(arbre){
  if(arbre.isLeaf(arbre))        return(length(arbre)>1)
  if(arbre.isMixte(arbre$left))  return(TRUE)
  if(arbre.isMixte(arbre$right)) return(TRUE)
  return(FALSE)
}