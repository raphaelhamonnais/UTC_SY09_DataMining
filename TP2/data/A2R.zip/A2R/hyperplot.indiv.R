hyperplot.indiv<-function(axes=c(1,2,3) , C , C.sup , col.ind=NULL , col.ind.sup=NULL  , COS2 , cex.lim=c(1,1) ,valp,inertiaX, xlim,ylim,zlim){
library(scatterplot3d)
XLAB<-paste("c", axes[1], " ", round(valp[axes[1]], digits = 4),
                                  "(", round(valp[axes[1]]/inertiaX * 100,
                                   digits = 2), "%)")

YLAB<-paste("c", axes[2], " ", round(valp[axes[2]], digits = 4),
                                  "(", round(valp[axes[2]]/inertiaX * 100,
                                  digits = 2), "%)")

ZLAB<-paste("c", axes[3], " ", round(valp[axes[3]], digits = 4),
                                  "(", round(valp[axes[3]]/inertiaX * 100,
                                  digits = 2), "%)")
if( is.null(C.sup) ) 	Ctot<-C
else  			Ctot<-rbind( C,C.sup )
Ctot<-Ctot[,axes] 
COS<-apply(COS2[,axes],1,sum)
N<-dim(C)[1]
nsup<-dim(C.sup)[1]
if(is.null(nsup)) nsup<-0

if( (length(col.ind)!=0)&(length(col.ind)!=1)&(length(col.ind)!=N) )                return()
if( (length(col.ind.sup)!=0)&(length(col.ind.sup)!=1)&(length(col.ind.sup)!=nsup) ) return()

col.axe<-F
if( length(col.ind)==0 ) col.axe<-T
if( length(col.ind)==1 ) col.ind<-rep(col.ind,N)

if( length(col.ind.sup)==1 ) col.ind.sup<-rep(col.ind.sup,nsup)

if(col.axe){
   sortie.couleurAXE<-couleurAXE(Ctot[,2],axe.lim=range(Ctot[,2]) )
   col.tot<-sortie.couleurAXE$col.axe
   colors <-sortie.couleurAXE$couleurs
}
else col.tot<-c( col.ind , col.ind.sup )

cex.ind<-cex.lim[1]+ (cex.lim[2]-cex.lim[1])*COS/10000
cex.ind.sup<-NULL
if(nsup!=0) cex.ind.sup<-rep(cex.lim[2],nsup)        

cex.tot<-c( cex.ind , cex.ind.sup )
if(missing(xlim)&missing(ylim)&missing(zlim) ) s3d<-scatterplot3d(Ctot, xlab = XLAB , ylab = YLAB , zlab=ZLAB,type = "n")
else                                           s3d<-scatterplot3d(Ctot, xlab = XLAB , ylab = YLAB , zlab=ZLAB,type = "n",xlim=xlim,ylim=ylim)

if(col.axe){
     cat("entrer max(x) : \n")
     xd<- scan("", numeric(), 1)
     cat("entrer min(x) : \n")
     x.min<-scan("",numeric(),1)
     cat("entrer min(y) : \n")
     y.min<- scan("", numeric(), 1)
     cat("entrer max(y) : \n")
     y.max<- scan("", numeric(), 1)
     y<- seq(y.min,y.max,length=500)
     cat("entrer min(z) : \n")
     zb<- scan("", numeric(), 1)
     xg<- xd-( xd-x.min )/8
     
     for(i in 1:500) s3d$points3d(c(xg,xd),rep(y[i],2),rep(zb,2),col=colors[i],type="l")
     s3d$points3d(c(xd,xd),range(y),c(zb,zb),type="l")
     s3d$box3d()

}
text(s3d$xyz.convert(Ctot),dimnames(Ctot)[[1]],cex=cex.tot,col=col.tot)

long<-matrix(1,N+nsup,4)
long[,1:3]<-round(Ctot,3)
long[,4]<-c(COS,rep(NA,nsup))
dimnames(long)<-list(dimnames(Ctot)[[1]],c(dimnames(Ctot)[[2]],"COS 2"))
cat("coordonn�es et COS2 des individus actifs\n")
print(long[1:N,])
if(nsup>0){
   cat("\ncoordonn�es des individus suppl�mentaires\n")
   print(long[-(1:N),1:3])

}

return(s3d)
}