white.test <- function(M,croises=F,print=T,alpha=0.05){
# test d'homosc�daticit� de White
#########
# M       : mod�le
# croises : avec les terme crois�s
# print   : bool�en (imprimer les r�sultats
# alpha   : risque de premi�re esp�ce
#########
YY<-M$y
nn<-length(YY)
dat<-M$data
res2<-M$residuals^2
dat2<-dat^2
dimnames(dat2)[[2]]<-paste(dimnames(dat2)[[2]],2,sep="")
if(croises){
  dat3<-cbind(1,dat)
  ndata<-dim(dat)[2]
  for(i in 1:ndata) for(j in i:ndata) {
     dimnam<-dimnames(dat3)[[2]]
     dat3<-cbind(dat3,dat[,i]*dat[,j])
     dimnames(dat3)[[2]]<-c(dimnam,paste(names(dat)[i],names(dat)[j],sep=""))
  }
  mod<-glm(res2~.,data=dat3)
}
else{
  mod<-glm(res2~.,data=cbind(1,dat,dat2))
}
R2<-cor(res2,mod$fitted)^2
statistic<-nn*R2
df<-mod$rank-1
p.value<-1-pchisq(statistic,df=df)

  if(print){
    cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
    cat("                 test d'homosc�dasticit� de White                 \n\n")
    if(croises) cat("avec termes crois�s\n")
    else        cat("sans termes crois�s\n")
    cat("LM      = ",round(statistic,3),"\n")
    cat("df      = ",df,"\n")
    cat("p.value = ",p.value,"\n")
    cat("diagnostic : ")
    if(p.value>alpha) cat("non rejet de l'homoscedasticit� (au risque alpha =",alpha*100,"%)\n")
    else              cat("rejet de l'homoscedasticit� (au risque alpha =",alpha*100,"%)\n")
    cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
  }
return(invisible(list(p.value=p.value,statistic=statistic)))
}