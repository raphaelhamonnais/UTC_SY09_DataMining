arbre.W <- function(arbre,diss){
indiv <- as.numeric(arbre.getNames(arbre))
diss <- diss[indiv,indiv]
diss <- diss[lower.tri(diss)]
sum(diss^2)
}