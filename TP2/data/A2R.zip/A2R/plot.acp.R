plot.acp <- function(a,                     # un objet de la classe "acp" (fonction acpxqd) 
                     bgpar       = "white", # couleur du background
                     groupes     = 1,
                     col.groupes = "black",
                     col.var     = "black", # vecteur des couleurs des variables actives
                     col.ind.sup = "black", # vecteur des couleurs des individus suppl�mentaires
                     col.var.sup = "black", # vecteur des couleurs des variables suppl�mentaires
                     cex.lim     = c(1,1),  # limites de la taille des individus et variables, par d�faut c(1,1) tous les points ont m�me taille
                                            # pour avoir une taille grosse pour les individus bien repr�sent�s cex.lim=c(0,1)
                     choix,
                     axes,
                     ellipse     = TRUE,
                     BOXP        = TRUE
                     

){

getAxes <- function(){
  parent <- parent.env(environment())
  axes   <- get("axes",parent)
  k      <- get("k",parent)
  if( (length(axes)!=2) || all(axes[1]!=1:k)|| all(axes[1]!=1:k) || (axes[1]==axes[2])){
     axespar <- rep(0,2)
     cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
     while(all(axespar[1]!=1:k)){
        cat("axe horizontal (",toString(1:k),") ?\n")
        axespar[1]   <- scan("", numeric(), 1)
     }
     cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")     
     choix.restant <- (1:k)[-axespar[1]]
     while(all(axespar[2]!=choix.restant)){
        cat("axe vertical (", toString(choix.restant), ") ?\n")
        axespar[2]   <- scan("", numeric(), 1)
     }        
  }
  else axespar <- axes
  assign("axespar",axespar,parent)
  assign("XLAB" , 
         paste("c", axespar[1], ":", round(valp[axespar[1]], digits = 4),"(", round(valp[axespar[1]]/inertiaX * 100,digits = 2), "%)"),
         parent)
  assign("YLAB",
         paste("c", axespar[2], ":", round(valp[axespar[2]], digits = 4),"(", round(valp[axespar[2]]/inertiaX * 100,digits = 2), "%)"),
         parent)  
  assign("titre",
         paste("plan ",axespar[1],"-",axespar[2]," : ",round(sum(valp[axespar]),4)," ( ",round(sum(valp[axespar])/sum(valp)*100,2)," % )",sep=""),
         parent)

}

                        nomfichX   <- a@nomfichX 
                        Xini       <- a@Xini 
                        X          <- a@X
                        Q          <- a@Q
                        D          <- a@D 
                        inertiaX   <- a@inertiaX 
                        k          <- a@k 
                        valp       <- a@valp 
                        Fa         <- a@Fa 
                        A          <- a@A 
                        C          <- a@CP 
                        CTRus      <- a@CTRus 
                        COSus      <- a@COSus 
                        CTRva      <- a@CTRva 
                        COSva      <- a@COSva 
                        As         <- a@As 
                        Cs         <- a@Cs
                        cor        <- a@cor
                        centrer    <- a@centrer
if(missing(axes)) axes <- 1

n <- nrow(X)
p <- ncol(X)
    if(all(dim(As)==c(1,1))) As <- NULL
    if(all(dim(Cs)==c(1,1))) Cs <- NULL


if(all(groupes==1))  groupes <- rep(1,n)
n.grp <- max(groupes)
if(length(col.groupes)!=n.grp){
   col.groupes <- 1:n.grp
   warning("le vecteur col.groupes a �t� r�initialis� ")
}

col.ind <- col.groupes[groupes]

if(length(col.var)==1) col.var <- rep(col.var,p)
if((!is.null(As))&&(length(col.var.sup=1))) col.var.sup <- rep(col.var.sup,nrow(As))
if((!is.null(Cs))&&(length(col.ind.sup=1))) col.ind.sup <- rep(col.ind.sup,nrow(Cs))

inside <- function(){

          if(choix==1){
                centrage <- Dcentred(Xini, D = D)
                meanX    <- matrix(centrage$moy)
                varX     <- matrix(centrage$var)
                dimnames(meanX)  <- list(dimnames(X)[[2]], "moy")
                dimnames(varX)   <- list(dimnames(X)[[2]], "var")

             cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
             if(cor == T) cat("                donnees centrees et reduites\n")
             cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
             if(centrer == T && cor == F) cat("                donnees centrees\n")
             cat("                moyenne des variables de",nomfichX,"\n")
             print(t(meanX))
             cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
             cat("                variance des variables de",nomfichX,"\n")
             print(t(varX))
          }
          if(choix==2){
             par(bg=bgpar,las=1)
             choixX <- menu(c(dimnames(X)[[2]],paste("------->c",1:k,sep="")),title="choisir variable abcisse")
             choixY <- menu(c(dimnames(X)[[2]],paste("------->c",1:k,sep="")),title="choisir variable ordonn�e")
             if(choixX>p) XXXX <- C[,choixX-p]
             else         XXXX <- X[,choixX]
             if(choixY>p) YYYY <- C[,choixY-p]
             else         YYYY <- X[,choixY]
             Rplot(XXXX,YYYY,cols=col.ind,pchs=20,noms=F,BOXP=T)             
          }
          if(choix==4){
              par(bg=bgpar,las=1)
              getAxes()
              par(mfrow = c(1, 1), pty = "s")
		          pf.plot(axespar,C,Cs,col.ind,col.ind.sup,COSus,cex.lim,valp=valp,inertiaX=inertiaX,fleches=F,BOXP=T,XLAB=XLAB,YLAB=YLAB,titre=titre)
           }
           if(choix==6){
              par(bg=bgpar,las=1,mfrow = c(1, 1), pty = "s")
              getAxes()
              pf.plot(axespar,A,As,col.var,col.var.sup,COSva,cex.lim,valp=valp,inertiaX=inertiaX,fleches=T,COR=cor,XLAB=XLAB,YLAB=YLAB,titre=titre)
          }
          if(choix==5){
             cat("_______________________________________________________________\n")
             cat("Contributions absolues des", n,"u.s. pour les", k, "premieres composantes\n")
             print(CTRus)
             cat("_______________________________________________________________\n")
             cat("Contributions relative des", n,"u.s. pour les", k, "premieres composantes\n")
             print(COSus)
          }
          if(choix==7){
             cat("_______________________________________________________________\n")
             cat("Contributions absolues des", p,"variables pour les", k, "premiers axes\n")
             print(CTRva)
             cat("_______________________________________________________________\n")
             cat("Contributions relative des", p,"variables pour les", k, "premiers axes\n")
             print(COSva)
          }
          if(choix==3){
             par(bg=bgpar,las=1)
             valtab           <- matrix(0, p, 4)
             dimnames(valtab) <- list(format(1:p), c("val.pro.", "% inert.","% cumul.", " RV"))
             valtab[, 1]      <- round(valp, digits = 4)
             valtab[, 2]      <- round(valp/inertiaX * 100, digits = 2)
             for(i in 1:p) {
                valtab[i, 3]  <- sum(valtab[1:i, 2])
                valtab[i, 4]  <- sqrt(sum(valp[1:i]^2)/sum(valp^2))
             }
             print(valtab)
             
             par(mar=c(3,2,3,1))
             plot(0,0,main="valeurs propres",xlim=c(0,100),ylim=c(0.5,p+0.5),xlab="",ylab="",axes=F)
             couleurss <- rainbow(2*p)[1:p]
             abline(v=(0:4)*25,lty=2)
             rect(xleft=rep(0,p),xright=valtab[p:1,3],ybottom=(1:p)-0.25,ytop=(1:p)+0.25,density=10)
             rect(xleft=rep(0,p),xright=valtab[p:1,3],ybottom=(1:p)-0.25,ytop=(1:p)+0.25,lwd=2)
             rect(xleft=rep(0,p),xright=valtab[p:1,2],ybottom=(1:p)-0.25,ytop=(1:p)+0.25,col=couleurss,lwd=2)
             axis(1,(0:4)*25,paste((0:4)*25,"%"))
             axis(2,1:p,p:1)
             box()
          }
          if(choix==8) {
             par(bg=bgpar,las=1)
             layout(matrix(c(1,1,2,2),nc=2),widths=c(50,50))
             getAxes()
             par(mar=c(4,4,3,1))
             ### variables
             pf.plot(axespar,A,As,col.var,col.var.sup,COSva,cex.lim,valp=valp,inertiaX=inertiaX,fleches=T,COR=cor,XLAB=XLAB,YLAB=YLAB,titre=titre)                   
             par(mar=c(4,2,3,1))
             ### individus   
	     #browser()
             pf.plot(axespar,C,Cs,col.ind,col.ind.sup,COSus,cex.lim,valp=valp,inertiaX=inertiaX,fleches=F,BOXP=BOXP ,XLAB=XLAB,YLAB="",titre=titre)                 
}
          if(choix==9){
             par(bg=bgpar,las=1)
             if(n.grp==1) stop("Un seul groupe")
             layout(matrix(c(1,1,2,2),nc=2),widths=c(50,50))
             getAxes()
             par(mar=c(4,4,3,1))
             ### variables
             pf.plot(axespar,A,As,col.var,col.var.sup,COSva,cex.lim,valp=valp,inertiaX=inertiaX,fleches=T,COR=cor,XLAB=XLAB,YLAB=YLAB,titre=titre)                   
             ### individus   
             par(mar=c(4,2,3,1))
             pf.plot(axespar,C,Cs,col.ind,col.ind.sup,COSus,cex.lim,valp=valp,inertiaX=inertiaX,fleches=F,BOXP=F ,XLAB=XLAB,YLAB="",titre=titre)                 
             moy <- centresGravite(C[,axespar],groupes)
             segments(x0=C[,axespar[1]],
                      y0=C[,axespar[2]],
                      x1=moy[groupes,1],
                      y1=moy[groupes,2],
                      col=col.ind)
             ex <- list(NULL)
             if(ellipse){
             for(i in 1:n.grp){
                XX <- C[groupes==i,axespar[1]]
                YY <- C[groupes==i,axespar[2]]
                try({ ex[[i]] <- ellipsoidhull(cbind(XX,YY));
                     #polygon(predict(ex[[i]]),lwd=1,border=col.groupes[i])
                   })
             }
             indiv <- NULL
                      XX  <- C[,axespar[1]]
                      YY  <- C[,axespar[2]]
             
             for(i in 1:(n.grp-1)) {
               for(j in (i+1):n.grp){
                   pxi <- predict(ex[[i]])
                   pxj <- predict(ex[[j]])
                   cond <- inout(pxi,pxj)
                   trace <- any(cond)
                   if(trace) {
                      pol <- pxi[cond,]
                      cond <- inout(pxj,pxi)
                      pol <- rbind(pol,pxj[cond,])
                      pol <- pol[chull(pol),]
                      indiv <- c(indiv,(1:n)[inout(cbind(XX,YY),pol)])
                      
                      polygon(pol,density=20)
                   }
               }
             }

             #points(XX[indiv],YY[indiv],cex=2,pch=21,bg=col.ind[indiv])

             for(i in 1:n.grp) polygon(predict(ex[[i]]),lwd=1,border=col.groupes[i])
             }             
             points(moy[,1],moy[,2],pch=21  ,cex=4,bg=col.groupes)
             text  (moy[,1],moy[,2],1:n.grp ,cex=1.2,font=2,col="white")
             #pf.plot(axespar,C,Cs,col.ind,col.ind.sup,COSus,cex.lim,valp=valp,inertiaX=inertiaX,fleches=F,BOXP=F,add=T)                 
          }
          if(choix==10){
             getAxes()
             dd <- kde2dw(C[,axespar[1]],C[,axespar[2]],n=50,w=c(apply(COSus[,axespar],1,sum)/10000))
             par(mar=c(2.5,1,1,1))
             Rpersp(dd$x,dd$y,dd$z,phi=20,theta=20,
                    xlab=XLAB,
                    ylab=YLAB,
                    zlab="densit�",
                    C1=acpres$C[,1],
                    C2=acpres$C[,2],
                    nlevels=20)

          }
}                        
    
if(missing(choix)) 
    repeat {
          cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
          cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~ A C P ~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
          cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
    
          choix<- menu(paste("\t",c("infos sur les variables de base",
                         "nuages de points",
                         "barplot des valeurs propres",
                         "----------> graphique pour les u.s.",
                         "aide � l'interpr�tation pour les u.s.",
                         "----------> graphique pour les variables",
                         "aide � l'interpr�tation pour les variables",
                         "----------> graphique u.s. + variables",
                         "----------> graphique (structure de groupes)",
                         "----------> graphique densit�")))
          if(choix==0) break
          inside()                         
    }
else inside()                 
# fin des graphiques
}