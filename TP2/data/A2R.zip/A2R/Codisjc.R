Codisjc<-function(X)
{
#       codage disjonctif complet de la matrice X
#
#          Entree
# X matrice (numerique) des modalites des variables qualitatives
#          Sorties
# nbmodal vecteur des nombres de modalites de chaque variable
# nbmodaltot nombre total de modalites
# U matrice du codage
# B matrice de Burt associee a U
#
   X<-as.matrix(X)
   n<-nrow(X)
   p<-ncol(X)
   U<-NULL
   nbmodal<-NULL
   nommod<-NULL
   ylab<-NULL
   nbmodaltot<-as.numeric(0)
labels<-rep(list(NULL),p)
   for(j in 1:p)
                {
                 nbmodal[j]<-max(X[,j])
                 nommod<-paste(dimnames(X)[[2]][j],(1:nbmodal[j]),sep="")
                 nbmodaltot<-nbmodaltot+nbmodal[j]
                 V<-matrix(0,n,nbmodal[j])
                 for(i in 1:n) V[i,X[i,j]]<-1
                 U<-cbind(U,V)
                 ylab<-c(ylab,nommod)
		labels[[j]]<-nommod
                }
   B<-t(U)%*%U
   nbmod<-nbmodal
   dimnames(U)<-list(dimnames(X)[[1]],ylab)
   dimnames(B)<-list(ylab,ylab)
   return(list(X      = X,
               nbmod  = nbmod,
               U      = U,
               B      = B,
               labels = labels ))
}