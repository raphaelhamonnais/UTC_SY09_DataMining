Rboxplot <- function(Y,                     # variable quantitative (� boxploter)
                     horiz=T,               # horizontal (T) ou vertival (F)
                     position=c(-0.5,0.5),  # limites de la boite
                     colpar="cornsilk",     # couleur de la boite
                     col.mean="blue",       # couleur de la moyenne
                     col.ab="red",          # couleur des points aberrants
                     cex=1,                 # taille
		     type="box",
		     colpar2 = "lavender",
		     bw = 'SJ-dpi'){           #fenetre pour l'estimation de la densité
# rajoute un boxplot � un graphique
#########
# fonction utilis�e par : plot.acp
#########

pos1    <- position[1]
pos2    <- position[2]
Y       <- Y[!is.na(Y)]

  hauteur <- strheight("o") #/ 2 
  largeur <- strwidth("o")  / 2

if(!horiz){
  largeur <- strheight("o") / 2
  hauteur <- strwidth("o")  #/ 2
}

posm    <- mean(position)
posmm   <- pos1 + hauteur
posmp   <- pos2 - hauteur
if(posmm>posmp){
  tmp <- posmm ; posmm <- posmp ; posmp <- tmp
}
if(hauteur>pos2-pos1) posmp <- posmm <- posm


boxstat <- boxplot(Y,plot=F)
boxout  <- c(mean(Y,na.rm=TRUE),boxstat$out)
boxstat <- c(boxstat$stat)

inf  <- boxstat[1]
Q25  <- boxstat[2]
med  <- boxstat[3]
medm <- med - largeur
medp <- med + largeur
Q75  <- boxstat[4]
sup  <- boxstat[5]


OK <- (largeur<=(boxstat[3]-boxstat[2]))
if(OK){
  aaa <-       c(med   , medm , Q25  , Q25  , medm , med   , med)
  bbb <-       c(posmm , pos1 , pos1 , pos2 , pos2 , posmp , posmm)  
}
else{
  aaa <-       c(med   , med)
  bbb <-       c(posmp , posmm)
}
OK <- (largeur<=(boxstat[4]-boxstat[3]))
if(OK){
  aaa <- c(aaa , med   , medp , Q75  , Q75  , medp , med   , med)
  bbb <- c(bbb , posmm , pos1 , pos1 , pos2 , pos2 , posmp , posmm)
}

aa0 <- c(inf  ,inf ,sup ,sup  )
aa1 <- c(inf  ,Q25 ,Q75 ,sup  )
bb0 <- c(pos1 ,posm,posm,pos1 )
bb1 <- c(pos2 ,posm,posm,pos2 )


if(!horiz){
  tmp <- aaa ; aaa <- bbb ; bbb <- tmp
  tmp <- aa0 ; aa0 <- bb0 ; bb0 <- tmp
  tmp <- aa1 ; aa1 <- bb1 ; bb1 <- tmp  
}
if(type=="violin"){
	if(length(bw)==1) d1 <- d2 <- density(Y,bw=bw)
	else{
		d1 <- density(Y,bw=bw[1])
		d2 <- density(Y,bw=bw[2],from=min(d1$x),to=max(d1$x))
	}
	d1$y <- d1$y / max(d1$y) * (pos2-posm)
	d2$y <- d2$y / max(d2$y) * (pos2-posm)
	
	
	imed <- c(which.min(abs(median(Y)-d1$x)),
		  which.min(abs(quantile(Y,0.25)-d1$x)),
		  which.min(abs(quantile(Y,0.75)-d1$x)),
		  which.min(abs(inf-d1$x)),
		  which.min(abs(sup-d1$x)))
	#browser()
	if(horiz){
		polygon(c(d1$x,d2$x[512:1]),posm+c(d1$y,-d2$y[512:1]),col=colpar,lwd=cex)
		polygon(c(d1$x[imed[2]:imed[3]],d2$x[imed[3]:imed[2]]),posm+c(d1$y[imed[2]:imed[3]],-d2$y[imed[3]:imed[2]]),col=colpar2,lwd=cex)
		segments(x0=d1$x[imed[1:3]],x1=d1$x[imed[1:3]],y0=posm-d2$y[imed[1:3]],y1=posm+d1$y[imed[1:3]],lwd=cex+c(1,0,0))
		segments(x0=d1$x[imed[4:5]],x1=d1$x[imed[4:5]],y0=pos1,y1=pos2,lwd=cex)
		segments(x0=d1$x[imed[c(4,4,5,5)]],x1=d1$x[imed[c(4,4,5,5)]]+strwidth("o")*c(1,1,-1,-1),y0=c(pos1,pos2,pos1,pos2),y1=c(pos1,pos2,pos1,pos2),lwd=cex)
		points(boxout,
        	   rep(posm,length(boxout)),
		   col=c(col.mean,rep(1,length(boxout))),
		   pch=c(15,rep(21,length(boxout))),
		   bg=col.ab)
	}
	else{
		polygon(posm+c(d$y,-d$y[512:1]),c(d$x,d$x[512:1]),col=colpar,lwd=cex)
		polygon(posm+c(d$y[imed[2]:imed[3]],-d$y[imed[3]:imed[2]]),c(d$x[imed[2]:imed[3]],d$x[imed[3]:imed[2]]),col=colpar2,lwd=cex)
		segments(x0=posm-d$y[imed[1:3]],x1=posm+d$y[imed[1:3]],y0=d$x[imed[1:3]],y1=d$x[imed[1:3]],lwd=cex+c(1,0,0))
		#segments(x0=pos1,x1=pos2,y0=d$x[imed[4:5]],y1=d$x[imed[4:5]],lwd=cex)
		#segments(x0=c(pos1,pos2,pos1,pos2),x1=c(pos1,pos2,pos1,pos2),y0=d$x[imed[c(4,4,5,5)]],y1=d$x[imed[c(4,4,5,5)]]+strwidth("o")*c(1,1,-1,-1),lwd=cex)
		points(rep(posm,length(boxout)),
                   boxout,
                   col=c(col.mean,rep(1,length(boxout))),
		   pch=c(15,rep(21,length(boxout))),
		   bg=col.ab)
	}
}
else{
	polygon(aaa,bbb,col=colpar,lwd=cex)
	segments(aa0,bb0,aa1,bb1,lty=c(1,2,2,1),lwd=cex)
if(horiz)   points(boxout,
                   rep(posm,length(boxout)),
                   col=c(col.mean,rep(col.ab,length(boxout))),
                   pch=c(15,rep(21,length(boxout))))

else {
            points(rep(posm,length(boxout)),
                   boxout,
                   col=c(col.mean,rep(col.ab,length(boxout))),
                   pch=c(15,rep(21,length(boxout))))
}
}


}