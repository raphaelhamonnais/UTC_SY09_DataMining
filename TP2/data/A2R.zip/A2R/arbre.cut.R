arbre.cut <- function(arbre,k=3){
   
#   a.c <- function(arbre){
#      if(arbre.isLeaf(arbre))
#   }
   
   hauteur.coupe <- mean(arbre.getHeights[c(k,k-1)])
   envir         <- environment()
   groupes       <- NULL
#   a.c(arbre)
}