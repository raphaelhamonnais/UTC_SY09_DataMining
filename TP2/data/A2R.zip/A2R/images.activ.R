images.activ<-function(X,vox,aires="aires de Brodmann",
                       titre="g�n�ration de mots",ech1=1:11,ech2=12:22,
                       leg.text=c("forts","faibles")){
# images des activations
N<-dim(X)[1]
P<-dim(X)[2]

image(1:P,1:22,t(X),col=gray((1000:1)/1000),breaks=seq(0,vox,length=1001),
      ylab="individus",xlab=aires,main=titre,axes=F)
mtext(paste("activation des",dim(X)[2],aires),line=0.5,cex=1,font=3)
abline(h=mean( c(max(ech1),min(ech2)) ))
box()
axis(2,c(mean(ech1-0.5),mean(ech2-0.5)),labels=leg.text,tick=F)


}