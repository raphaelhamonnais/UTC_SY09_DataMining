R.cluster.stats <- function (d, clustering, alt.clustering = NULL, silhouette = TRUE, 
    G2 = FALSE, G3 = FALSE,w=1) 
{
    if (silhouette)  require(cluster)
    cn <- max(clustering)
    n <- length(clustering)
    if(w==1) w <- rep(1,n)
    
    dmat <- as.matrix(d)
    diameter <- average.distance <- median.distance <- separation <- average.toother <- cluster.size <- within.dist <- between.dist <- numeric(0)
    separation.matrix <- matrix(0, ncol = cn, nrow = cn)
    di <- list()
    w.within <- NULL
    w.between <- NULL
    for (i in 1:cn) {
        cluster.size[i] <- sum(clustering == i)
        di <- as.dist(dmat[clustering == i, clustering == i,drop=F])
        within.dist <- c(within.dist, di)
        #w.within <- c(w.within,w[clustering == i])
        diameter[i] <- max(di)
        average.distance[i] <- mean(di)
        median.distance[i] <- median(di)

        bv <- numeric(0)
        for (j in 1:cn) {
            if (j != i) {
                sij <- dmat[clustering == i, clustering == j]
                bv <- c(bv, sij)
                if (i < j) {
                  separation.matrix[i, j] <- separation.matrix[j, i] <- min(sij)
                  between.dist <- c(between.dist, sij)
                  w.between <- c(w.between)
                }
            }
        }
        separation[i] <- min(bv)
        average.toother[i] <- mean(bv)
    }
    average.between <- mean(between.dist)
    average.within <- mean(within.dist)
    nwithin <- length(within.dist)
    nbetween <- length(between.dist)
    clus.avg.widths <- avg.width <- NULL
    if (silhouette) {
        sc <- summary(silhouette(clustering, dmatrix = dmat))
        clus.avg.widths <- sc$clus.avg.widths
        avg.width <- sc$avg.width
    }
    g2 <- g3 <- corrected.rand <- cn2 <- NULL
    if (G2) {
        splus <- sminus <- 0
        for (i in 1:nwithin) {
           splus  <- splus  + sum(within.dist[i]<between.dist)
           sminus <- sminus + sum(within.dist[i]>between.dist) 
        }
        g2 <- (splus - sminus)/(splus + sminus)
    }
    if (G3) {
        sdist <- sort(c(within.dist, between.dist))
        sr <- nwithin + nbetween
        dmin <- sum(sdist[1:nwithin])
        dmax <- sum(sdist[(sr - nwithin + 1):sr])
        g3 <- (sum(within.dist) - dmin)/(dmax - dmin)
    }
    if (!is.null(alt.clustering)) {
        choose2 <- function(v) {
            out <- numeric(0)
            for (i in 1:length(v)) out[i] <- ifelse(v[i] >= 2, 
                choose(v[i], 2), 0)
            out
        }
        cn2 <- max(alt.clustering)
        nij <- table(clustering, alt.clustering)
        dsum <- sum(choose2(nij))
        cs2 <- numeric(0)
        for (i in 1:cn2) cs2[i] <- sum(alt.clustering == i)
        sum1 <- sum(choose2(cluster.size))
        sum2 <- sum(choose2(cs2))
        corrected.rand <- (dsum - sum1 * sum2/choose2(n))/((sum1 + 
            sum2)/2 - sum1 * sum2/choose2(n))
    }
    hubertgamma <- cor(c(within.dist, between.dist), c(rep(0, 
        nwithin), rep(1, nbetween)))
    dunn <- min(separation)/max(diameter)
    out <- list(n = n, cluster.number = cn, cluster.size = cluster.size, 
        diameter = diameter, average.distance = average.distance, 
        median.distance = median.distance, separation = separation, 
        average.toother = average.toother, separation.matrix = separation.matrix, 
        average.between = average.between, average.within = average.within, 
        n.between = nbetween, n.within = nwithin, clus.avg.silwidths = clus.avg.widths, 
        avg.silwidth = avg.width, g2 = g2, g3 = g3, hubertgamma = hubertgamma, 
        dunn = dunn, wb.ratio = average.within/average.between, 
        corrected.rand = corrected.rand)
    out
}
