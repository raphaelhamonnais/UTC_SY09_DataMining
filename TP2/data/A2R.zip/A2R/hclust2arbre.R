hclust2arbre <- function(hclu,ff=NA){
                           
  if(length(hclu$height)<2) stop("pas assez de feuilles")

  envir            <- environment()
  top.labels       <- hclu$labels[ hclu$order ] 
  compteur.feuille <- 1 ## la premi�re feuille

  return(h2a(hclu,indice=length(top.labels)-1,envir=envir))
}
h2a <- function(hclu ,          ## arbre obtenu avec la fonction hclust (ou sous-arbre)
                indice = "" ,
                envir  = "" ){
## construit un arbre plus simple � manipuler pour faire des graphs �labor�s
#  cat(indice,"\n")

if(indice < 0) { # c'est une feuille
   arbre <- arbreFeuille(envir=envir)
}
else{            # c'est un arbre
   arbre <- list(left        = NULL , 
                 right       = NULL ,
                 height      = hclu$height[indice])

   ## construire l'arbre gauche
   indice.left       <- hclu$merge[indice,1]
   arbre$left        <- h2a(hclu , indice = indice.left  , envir=envir)

   ## construire l'arbre droit
   indice.right      <- hclu$merge[indice,2]
   arbre$right       <- h2a(hclu , indice = indice.right , envir=envir)

}
return(arbre)
}
arbreFeuille <- function(envir){
## renvoie simplement un arbre feuille

compteur <- get("compteur.feuille",envir=envir)
ff       <- get("ff",envir=envir)
if((length(ff)==1)&&(is.na(ff))) arbre    <- get("top.labels",envir=envir)[ compteur ]
else          arbre    <- which(ff==as.numeric(get("top.labels",envir=envir)[ compteur ]))
assign("compteur.feuille",compteur+1,envir=envir)
return(arbre)  
}