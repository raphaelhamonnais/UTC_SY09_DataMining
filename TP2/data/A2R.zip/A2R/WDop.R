WDop <- function(X,Y=X,Q=1,D=1){
# X,Y vecteurs ou matrices n x p, par defaut Y=X;
# operateur des produits scalaires entre individus de X et Y, XQY'D;
# Q est la metrique de l'espace des individus (par defaut Q=Ipp);Q matrice
# D est la metrique de l'espace des variables de Y:(par defaut 1/n Inn),
#                                                               D vecteur
 X <- as.matrix(X)
 Y <- as.matrix(Y)
 if(length(D)==1)  DD <- rep(1/nrow(Y),nrow(Y)) 
 else              DD <- as.vector(D)

 if(!is.matrix(Q)) W <- X%*%t(Y)
 else              W <- X%*%Q%*%t(Y)
 
 for(i in 1:ncol(W)) W[,i]<-DD[i]*W[,i]
 
 return(W)
}