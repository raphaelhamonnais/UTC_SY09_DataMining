arbre.getH <- function(arbre){

if(arbre.isLeaf(arbre)) return(0)
else return(arbre$height)
}