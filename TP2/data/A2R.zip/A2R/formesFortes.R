formesFortes <- function(x,y){
## x et y sont deux r�sultats de kmeans
if(length(x)!=length(y)) stop("x et y n'ont pas la meme longueur")

n <- length(x)
X <- cbind(x,y)
U <- unique(X)
m <- nrow(U)
groupes <- rep(0,n)

for(i in 1:n){
   groupes[i] <- which((x[i]==U[,1])&(y[i]==U[,2]))
}

return(groupes)
}