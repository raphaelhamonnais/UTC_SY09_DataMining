R.influence<-function(M,cols=1,pchs=15){
# mesures d'influence d'un mod�le de r�gression lin�aire
############
# M     : mod�le
# cols  : couleurs des individus (sert � diff�rencier une variable qualitative)
# pchs  : symboles des individus (sert � diff�recier une autre variable qualitative)
############
Y<-M$y
nn<-length(Y)
noms<-names(Y)
if(is.null(noms)) noms<-1:nn
if(length(cols)==1) cols<-rep(cols,nn)
if(length(pchs)==1) pchs<-rep(pchs,nn)

repeat{
  cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
  cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
  choix<-menu(c("--> coefficients du mod�le",
                "--> graphiques",
                "--> hypoth�ses sur les r�sidus",
                "--> influences d'observations",
                "--> colin�arit�"))
  if(choix==0) break

############ coefficients
  if(choix==1) print(summary(M))

############ graphiques
   if(choix==2){
      repeat{
        cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
        cat("~~~~~~~~~~~~~~~~~~~~~~~~ graphiques ~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
        cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")

        choix2<-menu(c("--> ajustement","--> validation crois�e"))
        if(choix2==0) break
        if(choix2==1) Rplot(Y,M$fitted,cols=cols,pchs=pchs,noms=noms,nomX="valeurs r�elles",nomY="valeurs ajust�es") 
        if(choix2==2){
          pred<-rep(NA,nn)
          for(i in 1:nn) pred[i]<-predict(glm(Y[-i]~.,data=M$data[-i,]),newdata=M$data[i,])
          Rplot(Y,pred,cols=cols,pchs=pchs,noms=noms,nomX="valeurs r�elles",nomY="valeurs pr�dites en XV")
        }
      }
    }

############ hypoth�ses sur les r�sidus
   if(choix==3){
      repeat{
        cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
        cat("~~~~~~~~~~~~~~ hypoth�ses sur les r�sidus ~~~~~~~~~~~~~~~~~~~~\n")
        cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")

        choix2<-menu(c("--> normalit�","--> homosc�dasticit�"))
        if(choix2==0) break
        if(choix2==1){
          par(ask=T)
          densite<-density(M$residuals,bw="bcv",kernel="biweight")
          xx<-seq(min(densite$x),max(densite$x),length=512)
          yy<-dnorm(xx,mean=mean(M$residuals),sd=sd(M$residuals))
          maxx<-max(c(densite$y,yy))
          plot(densite,lty=2,col=4,ylim=maxx*c(-1/10,1),type="n")
          Rboxplot(M$residuals,horiz=T,position=maxx*c(-2/100,-8/100),colpar="lightblue")
          abline(h=maxx*c(-1/10,0))
          polygon(xx,yy,col="cornsilk",border=NA)
          points(densite,lwd=2,col=4,type="l")
          rug(M$residuals)

          qqnorm(M$residuals)
          qqline(M$residuals)
          print(shapiro.test(M$residuals))
          jarquebera.test(M$residuals)
        }
        if(choix2==2){
          par(ask=T)
          white.test(M,croises=F)
          white.test(M,croises=T)
          plot(M$fitted,M$residuals,col=cols,pch=pchs,cex=1.2,xlab="valeurs ajust�es", ylab="r�sidus")
          text(M$fitted,M$residuals,noms,col=cols,pch=pchs,cex=1.2,pos=3)
          abline(h=0,col="gray",lty=3)

          for(i in 1:dim(M$data)[2]){
             plot(M$data[,i],M$residuals,col=cols,pch=pchs,xlab=dimnames(M$data)[[2]][i],ylab="r�sidus",cex=1.2)
             text(M$data[,i],M$residuals,noms,col=cols,pch=pchs,cex=1.2,pos=3)
          }
        }
      }
   }
########### influences d'observations
   if(choix==4){
      repeat{
        cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
        cat("~~~~~~~~~~~~~~~~~ influence d'observations ~~~~~~~~~~~~~~~~~~~\n")
        cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        
        choix2<-menu(c("--> distance de cook","--> r�sidus studentis�s internes","--> r�sidus studentis�s externes","--> levier H"))
        if(choix2==0) break
        if(choix2==1){
           cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
           ordre<-switch(menu(c("--> rang�s par couleurs","--> rang�s par symboles")),order(cols),order(pchs))
           dis<-cooks.distance(M)[ordre]
           for(i in 1:nn) if(is.infinite(dis[i])) dis[i]<-0
           colss<-cols[ordre]
           pchss<-pchs[ordre] 
           nomss<-noms[ordre]
           maxx<-max(c(dis,1))
           plot(dis,type="h",lwd=2,ylim=c(0,maxx*1.2),ylab="distance de cook",xlab="observations",axes=F,col=colss)
           abline(h=c(1,4/(nn-M$rank)),lty=2,lwd=2,col=2)
           text(1:nn,maxx*1.15,nomss,cex=0.9,font=2,col=colss)
           points(1:nn,rep(maxx*1.1,nn),cex=1.2,pch=pchss,col=colss)
           axis(2)
           box()
           etoile<-rep("",nn)
           for(i in 1:nn){
              if(abs(dis[i])>4/(nn-M$rank)) etoile[i]<-"<---"
              if(abs(dis[i])>1) etoile[i]<-"<<--------" 
           }
           matt<-cbind(format(round(dis,3)),format(etoile))
           dimnames(matt)[[2]]<-c("Cook","")
           print(matt,quote=F)
           cat("\nseuil : 4 / (",nn,"-",M$rank,")=",4/(nn-M$rank),"\n")
        }
        if(choix2==2){
           cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
           ordre<-switch(menu(c("--> rang�s par couleurs","--> rang�s par symboles")),order(cols),order(pchs))
           colss<-cols[ordre]
           pchss<-pchs[ordre] 
           nomss<-noms[ordre]
           dis<-rstandard(M)[ordre]

           for(i in 1:length(dis)) if(is.nan(dis[i])) dis[i]<-0
           maxx<-max(abs(min(dis)),abs(max(dis)),qt(1-0.05/2/nn,df=M$df.residual-1))
           plot(dis,type="h",lwd=2,ylim=maxx*c(-1,1.4),ylab="r�sidus studentis�s internes",xlab="observations",axes=F,col=colss)
           text(1:length(dis),maxx*1.3,nomss,cex=0.9,font=2,col=colss)
           points(1:length(dis),rep(maxx*1.2,nn),cex=1.2,pch=pchss,col=colss)
           quant1<-qt(0.975,df=M$df.residual-1)
           abline(h=quant1*c(1,-1),lty=2,lwd=2,col="orange")
           quant2<-qt(1-0.05/2/nn,df=M$df.residual-1)
           abline(h=quant2*c(1,-1),lty=2,lwd=2,col=2)
           abline(h=0)
           axis(2)
           box()

           etoile<-rep("",nn)
           for(i in 1:nn){
              if(abs(dis[i])>quant1) etoile[i]<-"<---"
              if(abs(dis[i])>quant2) etoile[i]<-"<<--------" 
           }
           matt<-cbind(format(round(dis,3)),format(etoile))
           dimnames(matt)[[2]]<-c("rstu_int","")
           print(matt,quote=F)
           cat(paste("quantile au seuil 97.5% : ",round(qt(0.975,df=M$df.residual-1),3),"\n"))
           cat(paste("quantile au seuil 1-0.05/(2 x ",nn,") : ",round(qt(1-0.05/2/nn,df=M$df.residual-1),3),"\n"))
        }

        if(choix2==3){
           cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
           ordre<-switch(menu(c("--> rang�s par couleurs","--> rang�s par symboles")),order(cols),order(pchs))
           colss<-cols[ordre]
           pchss<-pchs[ordre] 
           nomss<-noms[ordre]
           dis<-rstudent(M)[ordre]

           quant1<-qt(0.975,df=M$df.residual-2)
           quant2<-qt(1-0.05/2/nn,df=M$df.residual-2)

           for(i in 1:length(dis)) if(is.nan(dis[i])) dis[i]<-0
           maxx<-max(abs(min(dis)),abs(max(dis)),quant2)
           plot(dis,type="h",lwd=2,ylim=maxx*c(-1,1.4),ylab="r�sidus studentis�s externes",xlab="observations",axes=F,col=colss)
           text(1:length(dis),maxx*1.3,nomss,cex=0.9,font=2,col=colss)
           points(1:length(dis),rep(maxx*1.2,nn),cex=1.2,pch=pchss,col=colss)
           abline(h=quant1*c(1,-1),lty=2,lwd=2,col="orange")
           abline(h=quant2*c(1,-1),lty=2,lwd=2,col=2)
           abline(h=0)
           axis(2)
           box()
           etoile<-rep("",nn)
           for(i in 1:nn){
              if(abs(dis[i])>quant1) etoile[i]<-"<---"
              if(abs(dis[i])>quant2) etoile[i]<-"<<--------" 
           }    
           matt<-cbind(format(round(dis,3)),format(etoile))
           dimnames(matt)[[2]]<-c("rstu_ext","")
           print(matt,quote=F)
           
           cat(paste("quantile au seuil 97.5% : ",round(quant1,3),"\n"))
           cat(paste("quantile au seuil 1-0.05/(2 x ",nn,") : ",round(quant2,3),"\n"))
        }
        if(choix2==4){
           cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
           ordre<-switch(menu(c("--> rang�s par couleurs","--> rang�s par symboles")),order(cols),order(pchs))
           colss<-cols[ordre]
           pchss<-pchs[ordre] 
           nomss<-noms[ordre]
           dis<-lm.influence(M)$hat[ordre]
           maxx<-max(c(dis,2*M$rank/length(dis)))
           plot(dis,type="h",lwd=2,ylim=maxx*c(0,1.4),ylab="r�sidus studentis�s externes",xlab="observations",axes=F,col=colss)
           text(1:length(dis),maxx*1.3,nomss,cex=0.9,font=2,col=colss)
           points(1:length(dis),rep(maxx*1.2,nn),cex=1.2,pch=pchss,col=colss)
           box()
           abline(h=2*M$rank/length(dis),lty=2,lwd=2,col=2)
           abline(h=0)
           
        }
     }
      
   }
################ colin�arit�
   if(choix==5){
     repeat{
       cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
       cat("~~~~~~~~~~~~~~~~~~~~~~~ colin�arit� ~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
       cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
       choix2<-menu(c("--> VIF","--> COLLIN"))
       if(choix2==0) break
       if(choix2==1){
          pp<-dim(M$data)[2]
          VIF<-rep(NA,pp)
          for(i in 1:pp) VIF[i]<- 1/( 1 - cor(glm(M$data[,i]~.,data=M$data[,-i])$fitted,M$data[,i])^2) 
          matt1<-summary(M)$coeff
          etoile<-rep("",length(VIF))
          for(i in 1:length(VIF)) if(VIF[i]>10) etoile[i]<-"<----"
          matt<-cbind(format(matt1)[,1],format(matt1[,2]),format(matt1[,3]),format(matt1[,4]),"|",format(c(0,round(VIF,2))),"|",format(c("",etoile)) )
          dimnames(matt)[[2]]<-c(dimnames(summary(M)$coeff)[[2]],"|","VIF","|","")
          print(matt,quote=F)
       }
       if(choix2==2){
          XX<-as.matrix(cbind(1,M$data))
          XpX<-t(XX)%*%XX
          DD<-solve(diag(sqrt(diag(XpX))))
          lambda<-eigen(DD%*%XpX%*%DD)$values
          CN<-sqrt(lambda[1]/lambda)
          etoile<-rep("",length(CN))
          for(i in 1:length(CN)) if(CN[i]>100) etoile[i]<-"<----"
          matt<-cbind(format(lambda),"|",format(CN),"|",etoile)
          dimnames(matt)<-list(1:length(lambda),c("valeurs propres","|","condition number","|",""))
          print(matt,quote=F)
       }
               
     }
   }
}### endrepeat
}