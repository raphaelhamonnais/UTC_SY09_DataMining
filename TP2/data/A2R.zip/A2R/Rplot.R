Rplot <- function(X,Y,cols=1,pchs=20,cex=1.2,noms="",BOXP=FALSE){
# nuage de points
###########
# X     : abcisses
# Y     : ordonn�es
# cols  : couleurs
# pchs  : symbols
# cex   : tailles
# noms  : noms des individus
# BOXP  : bool�en (mettre des boxplots ?)
###########
nomX <- deparse(substitute(X))
nomY <- deparse(substitute(Y))
nn<-length(X)
if(noms==F) noms<-rep("",nn)
if(length(cols)==1) cols<-rep(cols,nn)
if(length(pchs)==1) pchs<-rep(pchs,nn)
xlim<-range(X)
ylim<-range(Y)
espX<-xlim[2]-xlim[1]
espY<-ylim[2]-ylim[1]
ylim<-c(ylim[1],ylim[2]+espY/25)
if(BOXP){
   xlim<-xlim-c(espX/10,0)
   ylim<-ylim-c(espY/10,0)   
}
plot(X,Y,col=cols,pch=pchs,cex=cex,xlab=nomX,ylab=nomY,ylim=ylim,xlim=xlim)
abline(lm(Y~X),lty=2,lwd=1)
points(X,Y,pch=pchs,col=cols,cex=cex)
text(X,Y+(max(Y)-min(Y))/25,noms,col=cols,font=2,cex=1)
title(substitute(hat(rho)(list(a),list(b))==list(c),list(a=nomX,b=nomY,c=round(cor(X,Y),3))))
if(BOXP){
   Rboxplot(X,horiz=T,position=c(ylim[1],ylim[1]+espY/15),colpar="lavender")
   Rboxplot(Y,horiz=F,position=c(xlim[1],xlim[1]+espX/15),colpar="lavender")
}
ppp<-cor.test(X,Y)$p.value
if(ppp<0.0001) textee<-paste("p.value < 0.0001")
else           textee<-paste("p.value =" ,round(ppp,digits=4))
mtext(textee,line=0.5,cex=0.8)
}