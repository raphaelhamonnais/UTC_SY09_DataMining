indice.var<-function(MOD,data,data.intercept=F){
## data.intercept -- T si l'intercept fait partie des variables de data
##################### sorties :
## indice    -- les indices des variables du mod�le MOD dans le data frame data
## intercept -- T si ya un intercept dans le mod�le MOD 
data<-as.data.frame(data)
var.mod<-dimnames(summary(MOD)$coefficients)[[1]]
if(data.intercept==F){
  intercept<-F
  if(is.null(var.mod)) indice<-NULL
  else{ 
    if(var.mod[1]=="(Intercept)") {
       var.mod<-var.mod[-1]
       intercept<-T
    }
    if(length(var.mod)==0) indice<-NULL
    else{
       indice<-rep(0,length(var.mod))
       for(i in 1:length(var.mod)) indice[i]<-(1:dim(data)[2])[(dimnames(data)[[2]]==var.mod[i])]
    }
  }
  return(invisible(list(indice=indice,intercept=intercept)))
}
else{
  if(is.null(var.mod)) indice<-NULL
  else{
    indice<-rep(0,length(var.mod))
    for(i in 1:length(var.mod)) indice[i]<-(1:dim(data)[2])[(dimnames(data)[[2]]==var.mod[i])]
  }  
  return(invisible(indice))
}
}