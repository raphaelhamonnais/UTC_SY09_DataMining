arbre.isLeaf <- function(arbre # un arbre
                         ){
#retrourne TRUE si l'arbre est une feuille, FALSE sinon
return(is.null(arbre$left))
}