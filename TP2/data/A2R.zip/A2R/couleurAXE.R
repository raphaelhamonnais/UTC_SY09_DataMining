couleurAXE<-function(Axe,axe.lim){
# d�grad� de couleurs
################
# entr�es :
# Axe     -- valeurs
# axe.lim -- �tendue du d�grad�
################
# sorties :
# couleurs -- les 500 couleurs du d�grad�
# col.axe  -- les couleurs correspondant aux valeurs (Axe)
couleurs<-rainbow(1000)[501:1000]
y<-seq(axe.lim[1],axe.lim[2],length=500)
N<-length(Axe)
couleur.axe<-rep(0,N)
for(i in 1:N) couleur.axe[i]<-couleurs[ order(abs(Axe[i]-y))[1] ]
return (list(couleurs=couleurs,col.axe=couleur.axe))
}