xy.val <- function(XY, taille = 1,...)
{
#
#          Graphique plan et representation d'une variable en z
#
#     Entrees
#
# XY matrice des coordonnees des points
#
#                               R.Sabatier revu par JFD!!!
# lecture des donnees
        nomfichXY <- deparse(substitute(XY))
        if(!is.matrix(XY))
                stop("XY n'est pas une matrice")
        XY <- as.matrix(XY)
        #if(length(c(which.inf(XY), which.na(XY))))
        #        stop("valeurs manquantes ou infinies dans XY")
        n <- nrow(XY)
        k <- ncol(XY)
        if(k < 3)
                return()        # verification du graphisme
        if(!exists(".Device", frame = 0)) {
                cat("Initialisez le graphique !!!\n")
                return()
        }
# trace des graphiques
        {
                cat("_______________________________________________________________\n"
                        )
                repeat {
                        cat("graphique pour les u.s. (o/n) ?\n")
                        pltc <- scan("", character(), 1)
                        if((length(pltc) == 0) | (pltc == "n"))
                                break
                        else {
# choix des numeros axes et de la variable en z
                                cat("axe horizontal (<=", k, ") ?\n")
                                pltch <- scan("", numeric(), 1)
                                cat("axe vertical (<=", k, ") ?\n")
                                pltcv <- scan("", numeric(), 1)
                                cat("numero de la var. en Z (<=", k, ") ?\n")
                                pltcz <- scan("", numeric(), 1)
        # calcul de la taille des cercles et carres
                                minxXY <- min(XY[, pltch])
                                maxxXY <- max(XY[, pltch])
                                minyXY <- min(XY[, pltcv])
                                maxyXY <- max(XY[, pltcv])
                                minzXY <- min(XY[, pltcz])
                                maxzXY <- max(XY[, pltcz])
                                minxp <- minxXY - taille * abs(max(XY[, pltcz])
                                  )
                                maxxp <- maxxXY + taille * abs(max(XY[, pltcz])
                                  )
                                minyp <- minyXY - taille * abs(max(XY[, pltcz])
                                  )
                                maxyp <- maxyXY + taille * abs(max(XY[, pltcz])
                                  )     # trace
                                axespar <- c(pltch, pltcv)
                                par(mfrow=c(1,1),pty="s")
                                plot(XY[, axespar], xlab = paste("c", axespar[1
                                  ]), ylab = paste("c", axespar[2]), type = "p",
                                  pch = 4, xlim = c(minxp, maxxp), ylim = c(
                                  minyp, maxyp), type = "n",col=1)

                                abline(h = 0,col=1)
                                abline(v = 0,col=1)
                                r <- XY[, pltcz]
                                XYp <- matrix(nrow = n, ncol = 2, NA)
                                XYn <- matrix(nrow = n, ncol = 2, NA)
                                rp <- matrix(nrow = n, ncol = 1, NA)
                                rn <- matrix(nrow = n, ncol = 1, NA)
                                iip <- 1
                                iin <- 1
                                for(i in 1:n) {
                                  if(r[i] > 0) {
                                    rp[iip] <- sqrt(r[i])
                                    XYp[iip, 1] <- XY[i, pltch]
                                    XYp[iip, 2] <- XY[i, pltcv]
                                    iip <- iip + 1
                                  }
                                  if(r[i] < 0) {
                                    rn[iin] <- sqrt( - r[i])
                                    XYn[iin, 1] <- XY[i, pltch]
                                    XYn[iin, 2] <- XY[i, pltcv]
                                    iin <- iin + 1
                                  }
                                }

if(any(XY[,pltcz]>=0)){
symbols(XYp[, 1], XYp[, 2], circles =
                                  taille * rp, inches = F, add = T, xpd = T,
                                  smo = 0, col = 2)
                              text(XY[XY[, pltcz]>=0, axespar], dimnames(XY)[[1]][XY[, pltcz]>=0], col = 2,...)
}
if(any(XY[,pltcz]<0)){
symbols(XYn[, 1], XYn[, 2], squares =
                                  1.77*taille * rn, inches = F, add = T, xpd = T, col=7 )
                      text(XY[XY[, pltcz]<0, axespar], dimnames(XY)[[1]][XY[, pltcz]<0], col = 7,...)
                        }

                        }
                }
        }
}