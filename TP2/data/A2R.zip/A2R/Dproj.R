Dproj <- function(X,Y,D=1,eps=1e-06,inv=T){
# D-proj de Y sur X
# sortie du residu Yres=Y-P Y  de Yhat=P Y et des coef. beta
#                          X            X
        X <- as.matrix(X)
        Y <- as.matrix(Y)
        if(inv) R <- solve(Dcp(X,D=D))
	      else    R <- invgene(Dcp(X,D=D),eps=eps)
        Yhat <- WDop(X,Q=R,D=D)%*%Y
        Yres <- Y-Yhat
        beta <- R%*%Dcp(X,Y,D=D)

return(list(Yhat  = Yhat,
            Yres  = Yres,
            beta  = beta))
}
