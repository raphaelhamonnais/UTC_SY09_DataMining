posmultclas<-function(X, D = 1, dissim = T, k = 3, impres = T, graph = T, aideus = 1)
{
#
#                Positionement Multidimensionnel Classique
#
#    Entrees
#
# X matrice des similarites ou dissimilarites
# D metrique des variables, si D=1 alors 1/nIdn, si D est un vecteur alors D=diag(vecteur), sinon D=matrice
# dissim=T la matrice est de dissimilarite, sinon dissim=F c'est une dissimilarite
# k nombre de composantes retenues, par defaut 3
# impres impression des resultats si T, si F rien
# graph trace des graphiques si T, si F pas de trace
# aideus=1 aides a l'interpretation pour les u.s., CTR et COS, pour les k premiers axes, sinon aideus=0
#
#    Sorties
#
# nomfichX nom du fichier X
# Xini tableau initial
# X tableau apres eventuel centrage et/ou reduction
# D metrique des u.s.
# W matrice de Torgerson
# inertiaX inertie du triplet
# k rang de la DSD retenue
# valp vecteur de toute les valeurs propres
# C matrice des k premieres composantes principales de la DSD
# CRTus et COSus contributions absolues et relatives des u.s. pour les k premieres composantes
#
# lecture des donnees
        nomfichX <- deparse(substitute(X))
        if(!is.matrix(X))
                stop("X n'est pas une matrice")
        X <- as.matrix(X)
        if(length(c(which.inf(X), which.na(X))))
                stop("valeurs manquantes ou infinies dans X")
        n <- nrow(X)
        if(is.null(dimnames(X)))
                dimnames(X) <- list(paste("i", 1:n, sep = ""), paste("v", 1:n,
                        sep = ""))
        if(length(dimnames(X)[[1]]) == 0)
                dimnames(X)[[1]] <- paste("i", 1:n, sep = "")
        if(length(dimnames(X)[[2]]) == 0)
                dimnames(X)[[2]] <- paste("i", 1:n, sep = "")
        Xini <- as.matrix(X)
        if(n < 2)
                return()
        if(impres == F)
                graph <- F
        if(impres == T) {
                if(!exists(".Device", frame = 0)) {
                        cat("Initialisez le graphique !!!\n")
                        return()
                }
        }
        n2 <- n * n
        Cs <- NULL
        CTRus <- NULL
        COSus <- NULL
        if(length(D) > n) aideus <- 0   # calcul de la metrique D
        if(length(D) == 1)
                D <- diag(rep(1/n, n), nrow = n)
        if(length(D) == n)
                D <- diag(D, nrow = n)
        if(length(D) == n2) D <- as.matrix(D)   # transformation en -.5*d^2
        if(dissim == F) {
                ma <- max(X)
                diag(X) <- ma
                X <- ma - X
        }
        X <- (-0.5 * X * X)
        if(impres) {
                if(dissim == F) {
                        cat("            - Positionement Multidimensionnel d'une matrice de similarite -\n"
                                )
                        cat("            ---------------------------------------------------------------\n"
                                )
                        cat("___________________________________________________________________________\n"
                                )
                }
                if(dissim == T) {
                        cat("            - Positionement Multidimensionnel d'une matrice de dissimilarite -\n"
                                )
                        cat("            ------------------------------------------------------------------\n"
                                )
                        cat("______________________________________________________________________________\n"
                                )
                }
        }
# initialisation
        valp <- NULL    # vecteur des valeurs propres
        C <- NULL       # matrice des composantes principales
# calcul du W
        un <- matrix(1, nrow = n, ncol = 1)
        P <- diag(n) - un %*% t(un) %*% D
        W <- P %*% X %*% t(P)   # decomposition de Choleski de D
        Dhalf <- chol(round(D, 6), pivot = T)
        Dhalf <- Dhalf[, order(attr(Dhalf, "pivot"))]
        Y <- Dhalf %*% W %*% Dhalf      # diagonalisation
        eg <- eigen(Y, symmetric = T)
        valp <- eg$values
        vpos <- sum(valp > 1e-07)
        vnul <- sum(abs(valp) <= 1e-07)
        vneg <- sum(valp < (-1e-07))
        inertiaX <- sum(valp[1:vpos])
        # impression de l'histogramme des valeurs propres
        if(impres) {
                cat(paste("Inertie totale =", format(inertiaX), "\n"))
                cat("histogramme des valeurs propres (o ou n) ?\n")
                plth <- scan("", character(), 1)
                if(length(plth) == 0)
                        plth <- "n"
                if(plth == "o" || plth == "O") {
                        par(mfrow = c(1, 1))
                        barplot(valp, space = 2, names = paste("v. p.", 1:n))
                        title("valeurs propres")
                }
#  choix du nombre d'axes si non donne en argument
                cat("__________________________________________________________________\n"
                        )
                valtab <- matrix(0, n, 3)
                dimnames(valtab) <- list(format(1:n), c("val.pro.", "% inert.",
                        "% cumul."))
                valtab[, 1] <- round(valp, digits = 4)
                valtab[, 2] <- round(valp/inertiaX * 100, digits = 2)
                for(i in 1:n)
                        valtab[i, 3] <- sum(valtab[1:i, 2])
                print(valtab)
                if(k == 0) {
                        repeat {
                                cat("Combien d'axes voulez-vous ? (<=", n,
                                  ")\n")
                                k <- scan("", n = 1)
                                if(k != 0)
                                  break
                        }
                }
        }
# calcul des composantes principales
        Dhinv <- invgene(Dhalf)
        Cent <- Dhinv %*% eg$vectors[, 1:vpos]
        C <- Dhinv %*% eg$vectors[, 1:k]
        for(j in 1:k)
                C[, j] <- C[, j] * sqrt(valp[j])
        for(j in 1:vpos)
                Cent[, j] <- Cent[, j] * sqrt(valp[j])
        if(k == 1)
                C <- as.matrix(C)
        dimnames(C) <- list(dimnames(X)[[1]], paste("c", format(1:k), sep = "")
                )       # calcul et impression des aides a l'interpretation
        if(aideus == 1) {
                CTRus <- matrix(NA, nrow = n, ncol = k)
                COSus <- CTRus
                for(i in 1:n)
                        for(j in 1:k)
                                CTRus[i, j] <- round((D[i, i] * C[i, j]^2)/valp[
                                  j] * 10000, digits = 0)
                dimnames(CTRus) <- list(dimnames(X)[[1]], paste("CTR", format(1:
                        k), sep = ""))
                for(i in 1:n) {
                        ss <- 0
                        for(j in 1:vpos)
                                ss <- ss + Cent[i, j]^2
                        for(j in 1:k)
                                COSus[i, j] <- round(Cent[i, j]^2/ss * 10000,
                                  digits = 0)
                }
                dimnames(COSus) <- list(dimnames(X)[[1]], paste("COS", format(1:
                        k), sep = ""))
        }
        if((impres == T) | aideus == 1) {
                cat("_______________________________________________________________\n"
                        )
                cat("aides a l'interpretation pour les u.s. (o/n) ?\n")
                plta <- scan("", character(), 1)
                if(length(plta) == 0)
                        plta <- "n"
                if(plta == "o" || plth == "O") {
                        cat("Contributions absolues des", n, "u.s. pour les", k,
                                "premieres composantes\n")
                        print(CTRus)
                        cat("Contributions relative des", n, "u.s. pour les", k,
                                "premieres composantes\n")
                        print(COSus)
                }
        }
# trace des eventuels graphiques
        if(graph == T) {
                cat("_______________________________________________________________\n"
                        )
                repeat {
                        cat("graphique pour les u.s. (o/n) ?\n")
                        pltc <- scan("", character(), 1)
                        if((length(pltc) == 0) | (pltc == "n"))
                                break
                        else {
                                cat("axe horizontal (<=", k, ") ?\n")
                                pltch <- scan("", numeric(), 1)
                                cat("axe vertical (<=", k, ") ?\n")
                                pltcv <- scan("", numeric(), 1)
                                par(mfrow = c(1, 1), pty = "s")
                                axespar <- c(pltch, pltcv)
                                plot(C[, axespar], xlab = paste("c", axespar[1],
                                  " ", round(valp[axespar[1]], digits = 4), "(",
                                  round(valp[axespar[1]]/inertiaX * 100, digits
                                   = 2), "%)"), ylab = paste("c", axespar[2],
                                  " ", round(valp[axespar[2]], digits = 4), "(",
                                  round(valp[axespar[2]]/inertiaX * 100, digits
                                   = 2), "%)"), type = "n")
                                abline(h = 0)
                                abline(v = 0)
                                text(C[, axespar], dimnames(C)[[1]])
                        }
                }
# fin des graphiques
        }
        return(list(nomfichX  = nomfichX, 
                    Xini      = Xini, 
                    X         = X, 
                    D         = D, 
                    W         = W, 
                    inertiaX  = inertiaX, 
                    k         = k, 
                    valp      = valp, 
                    C         = C, 
                    CTRus     = CTRus, 
                    COSus     = COSus))
}