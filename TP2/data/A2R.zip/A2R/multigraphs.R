multigraphs <- function(graphit,height=500,width=900,namefile="file",dir=getwd()){

for(i in c("ps","pdf")) if(!file.exists(paste(dir,i,sep="/"))) dir.create(paste(dir,i,sep="/"))


if(missing(graphit)) error("La fonction de graphique n'existe pas\n")

jpeg(      paste(dir,"/"    ,namefile,".jpg",sep=""),height=height,width=width,quality=100)
graphit()
dev.off()

postscript(paste(dir,"/ps/" ,namefile,".ps" ,sep=""),height=height/72,width=width/72)
graphit()
dev.off()

pdf(       paste(dir,"/pdf/",namefile,".pdf",sep=""),height=height/72,width=width/72)
graphit()
dev.off()
wd.ori <- getwd()
setwd(paste(dir,"pdf",sep="/"))
  system(paste("ebb ",namefile,".pdf",sep=""),invisible=T)
setwd(wd.ori)

}
