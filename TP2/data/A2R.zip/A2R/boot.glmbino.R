boot.glmbino<-function(Y,X,poids,MOD,k=1000,intercept=T){
# genre de bootstrap glm
# Y           -- variable � expliquer
# X           -- dataframe des pr�dicteurs
# poids       -- !!
# MOD         -- le mod�le
# k           -- nombre de r�p�titions
# intercept   -- !!
#####################
#   sorties
# vecteur des pourcentage de bien ajust�s
#####################
X<-as.data.frame(X)
N<-length(Y)
if(missing(poids)) poids<-rep(1,N)
if(missing(MOD)){
  if(intercept) MOD<-glm(Y~.,data=X,family="binomial")
  else          MOD<-glm(Y~.-1,data=X,family="binomial")
}
else{
  a<-indice.var(MOD,X)
  intercept<-a$intercept
  indice<-a$indice
  nomsvar<-dimnames(X)[[2]][indice]
  X<-as.data.frame(X[,indice])
  dimnames(X)[[2]]<-nomsvar  
}
bien.ajust<-rep(NA,k)
if(intercept){
  for(i in 1:k){
    a<-trunc(runif(N,min=1,max=N+1))
    MODi<-glm(Y[a]~.,data=X[a,],family="binomial")
    bien.ajust[i]<-sum(round(predict(MODi,newdata=X,type="response"))==1*(Y==1))/N*100
  }
}
else{
  for(i in 1:k){
    a<-trunc(runif(N,min=1,max=N+1))
    MODi<-glm(Y[a]~.-1,data=X[a,],family="binomial")
    bien.ajust[i]<-sum(round(predict(MODi,newdata=X,type="response"))==1*(Y==1))/N*100
  }
}
return(bien.ajust)
}