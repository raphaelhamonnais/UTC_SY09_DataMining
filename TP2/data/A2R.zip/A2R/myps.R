myps <- function(file,largeur=6,hauteur=6,horizpar=F,devicepar=windows)
{
#                 cr�ation d'un fichier postscript d'une image R
#
#file chaine de caracteres, nom du fichier postscript
#devicepar chaine de caract�res, nom du device de l'image source, windows ou X11
#
#               Pour visualiser et/ou imprimer le fichier postscript utiliser ghostview
#                      cr�ation de J.F. Durand, le 17/03/2001
#
dev.copy(device=devicepar)
dev.print(device=postscript,file=paste(file,".ps",sep=""),width=largeur,height=hauteur,horizontal=horizpar)
dev.off(dev.prev())
}