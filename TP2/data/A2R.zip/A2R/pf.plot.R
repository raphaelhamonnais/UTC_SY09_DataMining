pf.plot <- function( axes=c(1,2) , 
                     C , 
                     C.sup , 
                     col.ind=NULL , 
                     col.ind.sup=NULL  , 
                     COS2 , 
                     cex.lim=c(1,1) ,
                     valp,
                     inertiaX, 
                     fleches=F,
                     COR=F,
                     BOXP=F,
                     add=F,
                     XLAB,
                     YLAB,
                     titre=""){



palette("default")
if(missing(XLAB)) XLAB <- paste("c", axes[1], " ", round(valp[axes[1]], digits = 4),"(", round(valp[axes[1]]/inertiaX * 100,digits = 2), "%)")

if(missing(YLAB)) YLAB <- paste("c", axes[2], " ", round(valp[axes[2]], digits = 4),"(", round(valp[axes[2]]/inertiaX * 100,digits = 2), "%)")
 
if( missing(C.sup) ) 	Ctot<-C
else 			Ctot<-rbind( C,C.sup )


Ctot<- Ctot[,axes] 
COS <- COS2[,axes[1]] + COS2[,axes[2]]			
N   <- dim(C)[1]
nsup<- dim(C.sup)[1]
if(is.null(nsup)) nsup<-0

if( (length(col.ind)!=0)&(length(col.ind)!=1)&(length(col.ind)!=N) ) return()
if( (length(col.ind.sup)!=0)&(length(col.ind.sup)!=1)&(length(col.ind.sup)!=nsup) ) return()
if( length(col.ind)==0 ) col.ind<-rep(1,N)
if( length(col.ind)==1 ) col.ind<-rep(col.ind,N)
if( length(col.ind.sup)==0 ) col.ind.sup<-rep(2,nsup)
if( length(col.ind.sup)==1 ) col.ind.sup<-rep(col.ind.sup,nsup)
col.tot <- c( col.ind , col.ind.sup )

cex.ind <- cex.lim[1]+ (cex.lim[2]-cex.lim[1])*COS/10000
cex.ind.sup <- NULL
if(nsup!=0) {
      cex.ind.sup<-rep(cex.lim[2],nsup)        
}
cex.tot<- c( cex.ind , cex.ind.sup )
if(COR) xlim <- ylim <- c(-1,1)
else {
     xlim <- range(c(0,Ctot[,1]))
     ylim <- range(c(0,Ctot[,2]))
}
if(BOXP){
    espX<- xlim[2]   - xlim[1]
    espY<- ylim[2]   - ylim[1]
    xlim<- c(xlim[1] - espX / 10,xlim[2])
    ylim<- c(ylim[1] - espY / 10,ylim[2])
}

if(!add) plot(Ctot, xlab = XLAB , ylab = YLAB , type = "n",xlim=xlim,ylim=ylim)

abline(h = 0)
abline(v = 0)
text(Ctot, dimnames(Ctot)[[1]],col=col.tot,cex=cex.tot)
if(fleches) arrows(0,0,0.9*Ctot[,1],0.9*Ctot[,2],col=col.tot,lty=c( rep(1,N),rep(2,nsup) ))
if(COR) {
   x <- seq(0,2*pi,length=5000)
   points(cos(x),sin(x),type="l")
}
if(BOXP){
   Rboxplot(C[,axes[1]],horiz=T,position=c(ylim[1],ylim[1]+espY/15),type="violin")
   Rboxplot(C[,axes[2]],horiz=F,position=c(xlim[1],xlim[1]+espX/15),type="violin")
}
title(titre)
}