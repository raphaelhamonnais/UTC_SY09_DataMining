invgene <- function(A,eps=1e-06){
# inverse generalisee de A

A <- as.matrix(A)
# decomposition valeurs singulieres de A et calcul de son inverse dans RR
        valsin <- svd(A)
        diago  <- valsin$d[valsin$d>eps]
        if(length(diago) == 0){
          RR<-matrix(0,ncol(A),nrow(A))
          return(RR)
        }
        if(length(diago)==1) RR <- as.matrix(valsin$v[, 1:length(diago)])%*%t(as.matrix(valsin$u[, 1:length(diago)]))/diago
        else                 RR <- valsin$u[,1:length(diago)]%*%diag(1/diago)%*%t(valsin$u[,1:length(diago)])
#if(length(RR)==1)RR<-as.numeric(RR)
return(RR)
}