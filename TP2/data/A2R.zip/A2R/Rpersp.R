Rpersp <- function(x,
                   y,
                   z,
                   ncol=50,
                   zlim=c(0,max(z)),
                   C1=NULL,
                   C2=NULL,
                   nlevels=20,
                   defpar=TRUE,...){

nrz <- nrow(z)
ncz <- ncol(z)

couleurs   <- tail(topo.colors(trunc(1.4 * ncol )),ncol)
fcol       <- couleurs[trunc(z/zlim[2]*(ncol-1))+1]
dim(fcol)  <- c(nrz,ncz)
fcol       <- fcol[-nrz,-ncz]
couleurs   <- head(couleurs,floor(ncol*max(z)/zlim[2])) 


if(defpar) par(mfrow=c(1,2))
persp(x,y,z,col=fcol,zlim=zlim,...)

image(x,y,z,col=couleurs,...)
if(!any(is.null(C1),is.null(C2))) points(C1,C2,col="black",cex=0.7,pch=20)
contour(x,y,z,add=T,...)
box()

}