Dvar <- function(X,D=1,cor=F){
# VALUE:
# V: matrice des D-variances de X si cor=F, sinon matrice des D-correlations
# U: matrice D-centree de X si cor=F, sinon matrice D-centree reduite
# mean: vecteur des D-moyennes
# var: vecteur des D-variances

mat <- FALSE
if(is.matrix(X)) mat<-TRUE
X        <- as.matrix(X)
centrage <- Dcenter(X,D=D)
Y        <- centrage$X
mean     <- centrage$mx
V        <- VQop(Y,D=D)
var <- diag(V)
if(cor==F) U<-Y
else {
  ect<-sqrt(var)
  U<-sweep(Y,2,ect,FUN="/")
  V<-VQop(U,D=D)
}
if(mat){
  dimnames(V) <- list(dimnames(X)[[2]],dimnames(X)[[2]])
  dimnames(U) <- dimnames(X)
}
return(list(V    = V,
            U    = U,
            mean = mean,
            var  = var ))
}