RVop <- function(X,Y,D=1){

if(nrow(X)!=ncol(X))return()
if(nrow(Y)!=ncol(Y))return()
if(nrow(X)!=nrow(Y))return()

        X <- as.matrix(X)
        Y <- as.matrix(Y)
        if(length(D)==1) DD <- rep(1/nrow(Y),nrow(Y)) else DD <- as.vector(D)
        A<-as.matrix(DD*X)
        B<-as.matrix(DD*Y)
        if(sum(A-t(A))!=0)return()
        if(sum(B-t(B))!=0)return()
        num <- sum(X*Y)
        den <- sum(X*X)*sum(Y*Y)
RV <- num/sqrt(den)
return(RV)
}