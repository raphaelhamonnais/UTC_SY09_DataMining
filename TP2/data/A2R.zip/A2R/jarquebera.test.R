jarquebera.test<-function(X,print=T,alpha=0.05){
# test de normalit� de jarque bera
#########
# X     : vecteur quantitatif
# print : bool�en (? imprimer les r�sultats)
# alpha : risque de premi�re esp�ce 
nn<-length(X)
mu1<-mean(X)
mu2<-sum((X-mu1)^2)/nn
mu3<-sum((X-mu1)^3)/nn
mu4<-sum((X-mu1)^4)/nn

statistic<-nn*((mu3^2)/((mu2^3)*6)+mu4/((mu2^2)*24))
p.value  <-1-pchisq(statistic,df=2)

if(print){
  cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
  cat("             test de normalit� de Jarque Bera                 \n\n")
  cat("S =",round(statistic,3),", p.value =",p.value,"\n")
  cat("diagnostic : ")
  if(p.value>alpha) cat("non rejet de la normalit� (au risque alpha =",alpha*100,"%)\n")
  else              cat("rejet de la normalit� (au risque alpha =",alpha*100,"%)\n")
  cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
}
return(invisible(list(p.value=p.value,statistic=statistic)))
}