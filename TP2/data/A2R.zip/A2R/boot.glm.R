boot.glm<-function(Y,X,poids,MOD,intercept=T,k=1000){

N<-length(Y)
X<-as.data.frame(X)
if(missing(poids)) poids<-rep(1,N)
if(missing(MOD)){
  if(intercept) MOD<-glm(Y~.  ,data=X,weights=poids)
  else          MOD<-glm(Y~.-1,data=X,weights=poids)
}
else{
  a<-indice.var(MOD,X)
  intercept<-a$intercept
  indice<-a$indice
  nomsvar<-dimnames(X)[[2]][indice]
  X<-as.data.frame(X[,indice])
  dimnames(X)[[2]]<-nomsvar
}
EQMP<-rep(NA,k)

if(intercept){
  for(i in 1:k){
     a<-trunc(runif(N,min=1,max=N+1))
     MODi<-glm(Y[a]~.,data=X[a,],weights=poids)
     EQMP[i]<-sum(poids*(Y-predict(MODi,newdata=X,type="link"))^2)/sum(poids)
  }
}
else{
  for(i in 1:k){
     a<-trunc(runif(N,min=1,max=N+1))
     MODi<-glm(Y[a]~.-1,data=X[a,],weights=poids)
     EQMP[i]<-sum(poids*(Y-predict(MODi,newdata=X,type="link"))^2)/sum(poids)
  }
}
return(EQMP)

}