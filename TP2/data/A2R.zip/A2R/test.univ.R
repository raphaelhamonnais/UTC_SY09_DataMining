test.univ<-function(X,Y,poids,ech1=1:11,ech2=12:22){

X<-as.data.frame(X)
noms<-dimnames(X)[[2]]

A<-signif<-matrix(0,nr=dim(X)[2],nc=7)
dimnames(A)<-list(noms,c("shapiro1","shapiro2","fisher","student","welch","wilcox","glmF"))
for(i in 1:dim(X)[2]){
   if(sum(X[ech1,i])==0) A[i,1]<-0
   else                  A[i,1]<-shapiro.test(X[ech1,i])$p.value
   if(sum(X[ech2,i])==0) A[i,2]<-0
   else                  A[i,2]<-shapiro.test(X[ech2,i])$p.value
   A[i,3]<-var.test(X[ech1,i],X[ech2,i])$p.value                                      ## test de fisher
   A[i,4]<-t.test(X[ech1,i],X[ech2,i],var.equal=T)$p.value                            ## student
   A[i,5]<-t.test(X[ech1,i],X[ech2,i],var.equal=F)$p.value                            ## welch
   A[i,6]<-wilcox.test(X[ech1,i],X[ech2,i],exact=F)$p.value                           ## wilcoxon
   A[i,7]<-anova(glm(Y~X[,i],weights=poids),glm(Y~1,weights=poids),test="F")$P[2]     ## fisher glm
   for(j in 1:7) signif[i,j]<-codeSignif(A[i,j])
}
B<-round(A,4)
B[B==0]<-"<0.001"

for(i in 1:dim(X)[2]){
   if((A[i,1]<0.05)|(A[i,2]<0.05)) B[i,3]<-signif[i,3]<-B[i,4]<-signif[i,4]<-B[i,5]<-signif[i,5]<-""
   else{
      B[i,6]<-signif[i,6]<-""
      if(A[i,3]<0.05) B[i,4]<-signif[i,4]<-""
      else            B[i,5]<-signif[i,5]<-""
   }
}


write.table(cbind(format(noms),
                  format(c("0.0000",B[,1]))[-1],format(c("***",signif[,1]))[-1],
                  format(c("0.0000",B[,2]))[-1],format(c("***",signif[,2]))[-1],
                  format(c("0.0000",B[,3]))[-1],format(c("***",signif[,3]))[-1],
                  format(c("0.0000",B[,4]))[-1],format(c("***",signif[,4]))[-1],
                  format(c("0.0000",B[,5]))[-1],format(c("***",signif[,5]))[-1],
                  format(c("0.0000",B[,6]))[-1],format(c("***",signif[,6]))[-1],rep("|",dim(X)[2]),format(noms),
                  format(c("0.0000",B[,7]))[-1],format(c("***",signif[,7]))[-1])
            ,quote=F,sep="  ",col.names=c("zone","shapiro1","","shapiro2","","fisher","","student","","welch","","wilcox","","|","zone","glmF",""),row.names=F)

return(invisible(A))
}