truc <- function(Y,cols,symb,nat=c("U","F","I","D","GB","J"),fin=c("M","B","TB"),cexpar=2,roundpar=0){
#
# trace un boxplot d'une variable quantitative et montre les valeurs de cette variable 
# contre les modalit�s de deux variables qualitatives
########## 
# Y        : variable quantitative
# cols     : couleurs (diff�rencie une variable qualitative)
# symb     : symboles (diff�rencie l'autre variable qualitative)
# nat      : noms des modalit�s de la premi�re variable qualitative
# fin      : noms des modalit�s de la seconde variable qualitative
# cexpar   : parama�tre de taille pour le texte sur le graph
# roundpar : param�tre d'arrondi (---> round )
###########
# fonctions ext�rieures utilis�es : truc
###########
boxstat<-boxplot(Y,plot=F)$stats
colsf<-cols
symbf<-symb
cols<-factor(cols)
symb<-factor(symb)
ncols<-length(levels(cols))
nsymb<-length(levels(symb))
plot(0,0,type="n",xlim=c(-ncols,nsymb),ylim=range(Y),axes=F,xlab="",ylab="")
rect(xleft=-ncols-5,xright=nsymb+5,ybottom=boxstat[2],ytop=boxstat[4],col=gray(0.95),border=NA)
abline(h=boxstat,lty=3)
if(max(Y)>boxstat[5]){
  abline(h=max(Y),lty=3)
  axis(2,max(Y),las=1)
}
if(min(Y)<boxstat[1]){
  abline(h=min(Y),lty=3)
  axis(2,min(Y),las=1)
}
Rboxplot(Y,F,c(-0.5,0.5))
for(i in 1:ncols){
  aa<-(1:length(Y))[cols==levels(cols)[[i]]]
  points(rep(-i,length(aa)),Y[aa],col=colsf[aa],pch=symbf[aa],cex=cexpar*0.75)
}
for(i in 1:nsymb){
  aa<-(1:length(Y))[symb==levels(symb)[[i]]]
  points(rep(i,length(aa)),Y[aa],col=colsf[aa],pch=symbf[aa],cex=cexpar*0.75)
}
axis(1,c(1:nsymb),fin)
axis(1,c(-1:-ncols),nat)
axis(2,round(boxstat,roundpar),las=1)
}