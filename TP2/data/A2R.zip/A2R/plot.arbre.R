plot.arbre <- function(arbre,           ## un arbre (cr�� par hclust2arbre)
                       main="arbre de classification",
                       k=3,
                       col.top="black",
                       col.groupes=c("red","green","blue"),
                       lty.top=2,
                       lty.groupes=1,
                       lwd.top=1,
                       lwd.groupes=2,
                       superviseur.quali,
                       nom.sup.quali="etat",
                       superviseur.quanti,
                       nom.sup.quanti="C1",
                       col.highlight = "white",
                       nom.indiv    = "individus",
                       type         = "r",
                       print        = TRUE,
                       critere,      # vecteur critere de choix du nombre de clusters (fonction arbreCritere)
                       name.crit    = "",# nom du critere
                       line.cut     = TRUE,
                       height.F     ,
                       diss,
                       p){              
                       
     if(length(col.groupes)!=k) {
        warning(paste("le vecteur col.groupes n'avait pas",
                      "\nles bonnes dimensions :",k,
                      "\nil a �t� r�initialis�\n"),call.=FALSE)
        col.groupes <- 2 : (k+1)
     }
     if(missing(height.F)) height.F <- arbre.getH(arbre)*2
     if(!missing(diss)) diss <- as.matrix(diss)
     
     names.leaf <- arbre.getNames(arbre)
     n.indiv    <- length(names.leaf)
     
     if( max(nchar(names.leaf)) > 5 ){
        warning(paste("Les noms des individus sont trop longs",
                      "\nIls ont �t� coup�s � 5 caract�res"),call.=FALSE)
        names.leaf <- toupper(substr(names.leaf,1,5))
     }
     
     if( missing(superviseur.quali) == FALSE )
        if(! is.factor(superviseur.quali) ) {
           warning(paste("Le parametre superviseur.quali a �t� factoris� automatiquement"),call.=FALSE)
           superviseur.quali <- as.factor(superviseur.quali)
        }
        
     height.cut <- arbre.getHeights(arbre)  
     if(k==1) height.cut <- tail(height.cut,1)+1
     else{
       ll         <- length(height.cut)
       height.cut <- mean(height.cut[c(ll-k+2,ll-k+1)])
     }
  
  envir  <- environment()
  compteur  <- 0
  feuilles  <- 0
  
  col.labels <- NULL
  
  ##############################################################################
  ### pr�paration du layout
  tmp        <- toString(sum(c(missing(superviseur.quali),missing(superviseur.quanti)))) 
  heights    <- switch(tmp,
                    "2" = c(90,10),
                    "1" = c(80,10,10),
                    "0" = c(70,10,10,10))
  mat.layout <- switch(tmp,
                    "2" = matrix(c(3,4,1,2),nc=2),
                    "1" = matrix(c(3,4,6,1,2,5),nc=2),
                    "0" = matrix(c(3,4,6,8,1,2,5,7),nc=2))
  rm(tmp)
  layout(mat.layout,heights = heights , widths = c(10,90) )


  ##########################################################################
  # L'ARBRE
  par(mar=c(0,0,2,0))
  xlim <- arbre.getXlim(arbre)
  cex.names <- min(1.5,max(50 / xlim[2],0.75))
  if(arbre.isMixte(arbre)) ylimA <- arbre$height*c(-.1,1)
  else                     ylimA <- c(0,arbre$height)  
  plot(0,0,type="n",axes=FALSE,xlab="",ylab="",ylim = ylimA,xlim=xlim , main=paste(main,"(",k,"groupes )"))
  ticks <- axTicks(2)
  par(srt=0)
  if(line.cut) abline(h=height.cut,lty=2,col=gray(.5))
  text(0,ticks,ticks)
  p.a(arbre,envir,height.cut,col=col.top,lwd=lwd.top,lty=lty.top,type=type) 
  box()


  #########################################################################
  # LE NOM DE CHAQUE INDIVIDU  
  par(mar=c(0,0,0,0),srt=90)
  plot(0,0,type="n",axes=FALSE,xlab="",ylab="",ylim = c(0,1),xlim = xlim )
  text( xlim[1] : xlim[2] , 0.5 , format(names.leaf) , col = col.labels  , cex = cex.names)
  box()

  ########################################################################
  # CRITERE DE SELECTION
  if(missing(critere)) plot(1,type="n",xlab="",ylab="",axes=F)
  else{
        par(mar=c(0,0,2,0))
        plot(0,0,type="n",axes=FALSE,xlim=range(critere),ylim=ylimA,main=name.crit)
         critere      <- as.matrix(critere)
         k.max        <- nrow(critere)
         hauteurs.tmp <- tail(arbre.getHeights(arbre),k.max+1)
         hauteurs     <- rep(0,k.max)
         ticks <- axTicks(1)
         for(i in 1:k.max) hauteurs[i] <- mean(hauteurs.tmp[c(i,i+1)])
         segments(x0=ticks,x1=ticks,y0=rep(0,length(ticks)),y1=mean( c(hauteurs[k.max],hauteurs.tmp[k.max+1])),col="gray")
         par(srt=90)
         #text(ticks,hauteurs.tmp[k.max]+(hauteurs.tmp[k.max+1]-hauteurs.tmp[k.max])*0.8 ,ticks)
         if(line.cut) abline(h=height.cut,lty=2,col=gray(.5))
  
         text(ticks,0,ticks)
         par(srt=0)
         for(i in 1:ncol(critere)){
           opti <- which.max(critere[,i])
           #text(mean(range(critere[,i])),arbre$height,paste("opt =",opti+1,"clusters"))
           points( critere[k.max:1,i] , hauteurs , type="o"    , pch=14+i , col=1+i)
           points( critere[opti,i]    , hauteurs[k.max-opti+1] , pch=14+i , cex=1.8 , col=1+i )
         }
         box()
  }


  #########################################################################
  ### TYPES D'INDIVIDUS
      par(mar=c(0,0,0,0),srt=0)   
      plot(0,0,type="n",xlab="",ylab="",axes=F)
      text(0,0,paste(nom.indiv,"\n(n=",length(names.leaf),")",sep=""))     
      box()

  #########################################################################
  ### "SUPERVISEUR" QUALITATIF
  colorie <- function(){
     tmp <- seq(0,xlim[2])+0.5
     tmp[1]       <- - n.indiv
     tmp[n.indiv] <- n.indiv * 2
     rect(xleft   = head(tmp,n.indiv),
          xright  = tail(tmp,n.indiv),
          ytop    = rep (ylim[2]+diff(ylim),n.indiv),
          ybottom = rep (ylim[1]-diff(ylim),n.indiv),
          col     = col.labels,
          border  = NA)  
  }
  if(!missing(superviseur.quali)){
     par(mar=c(0,0,0,0),srt=0)  
     ylim <-  c(0.5,0.5 + length(levels(superviseur.quali)))
     plot(0,0,type="n",axes=FALSE,xlab="",ylab="",ylim = ylim , xlim = xlim )
     colorie()
     for(i in levels(factor(col.labels))){
        indicess    <- which(col.labels==i)
        colss       <- rep("black",length(indicess))
        dominant    <- levels(superviseur.quali)[ which.max(summary(superviseur.quali[indicess])) ]
        colss[ superviseur.quali[indicess] == dominant ] <- col.highlight
        points( xlim[1] +indicess - 1 , superviseur.quali[indicess] , pch = 14 + c(superviseur.quali[indicess]) , col=colss , cex = 1.5)
     }
     box()          
     niv.sup     <- levels(superviseur.quali)
     tablo.quali <- table(superviseur.quali,col.labels)
     chi2        <- chisq.test(tablo.quali,simulate.p.value=T,B=50000)
     if(print){
       print(tablo.quali)
       print(chi2)
       cat("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
     }
     plot(0,0,type="n",axes=FALSE,xlim=c(0,5),ylim=c(0.5,0.5 + length(niv.sup)) )
     par(srt=0)
     pval <- round(chi2$p.value,3)
     if(pval == 0 ) pval <- " <.001"
     else           pval <- paste("=",pval,sep=" ")
     expre <- paste(nom.sup.quali,"\nChi� =",round(chi2$statistic,2),"\np",pval)
     text( 0 , 0.5 + length(niv.sup)/2 , expre,pos=4)
     text( 5   , 1:length(niv.sup)       , niv.sup       , pos=2 )
     box()
  }


  ####################################################################################
  ### SUPERVISEUR QUANTITATIF  
  if(!missing(superviseur.quanti)){
     par(mar=c(0,0,0,0),srt=0)  
     ylim <- range(superviseur.quanti)
     plot(0,0,type="n",axes=FALSE,xlab="",ylab="", ylim = ylim , xlim = xlim )
     colorie()
     points( xlim[1] : xlim[2] , superviseur.quanti , pch="+" , col="black" , cex = 1.5)

     for(i in levels(factor(col.labels))){
        indicess <- which(col.labels==i)
        lines(x=range(indicess)+c(-0.5,0.5) , y = rep(mean(superviseur.quanti[indicess]),2) , col=col.highlight,lwd=2)
     }
     anov <- anova(glm(superviseur.quanti~factor(col.labels)),glm(superviseur.quanti~1),test="F")
     print( anov )
     box()
     plot(0,0,type="n",axes=FALSE,xlim=c(0,1),ylim=c(0,1))
          pval <- round(anov$P[2],3)
          if(pval == 0 ) pval <- " <.001"
          else           pval <- paste("=",pval,sep=" ")
          text(0,0.5,paste(nom.sup.quanti,"\nF =",round(anov$F[2],2),"\np",pval),pos=4)
     box()        
  }
  return(invisible(col.labels))
}




p.a <- function(arbre,envir,height.cut,col,lty,lwd,type="r"){
  
   
  if(arbre.isLeaf(arbre)){
     feuilles <- get("feuilles",envir=envir)
     taille <- length(arbre)
     assign("col.labels",c( get("col.labels",envir=envir) , rep(col,taille )),envir=envir)
          
          ybot   <- get("ylimA",envir=envir)[1]          
          sortie   <- feuilles + ( taille + 1 ) / 2
#          segments(x0=feuilles+1:taille,y0=rep(ybot,taille),x1=rep(sortie,taille),y1=rep(0,taille),col=col,lwd=lwd,lty=lty)
          polygon(c(feuilles+1,feuilles+taille,sortie),c(ybot,ybot,0),col=col,lwd=lwd,lty=lty,border=col)
          assign("feuilles",feuilles+taille,envir=envir)
          return(sortie)

  }
  if(!arbre.isLeaf(arbre)){ # c'est un arbre
     
     dopvalue <- FALSE #(arbre.getH(arbre) > get("height.F",envir=envir))
     if(dopvalue) {

         W1 <- arbre.W(arbre     ,get("diss",envir=envir))
         W2 <- arbre.W(arbre$left,get("diss",envir=envir)) + arbre.W(arbre$right,get("diss",envir=envir))

         m  <- arbre.getN(arbre)
         p  <- get("p",envir=envir)

#browser()
         pvalue <- 1- pf( ((W1 - W2) / W2 ) / 
                          (((m-1)/(m-2))*2^(2 / p) - 1 ) , p , (m-2)*p)     
         pvalueDH <- 1 - pnorm( (1 - 2 / (pi * p) - W1/W2 ) /
                     (((2-16/(pi^2 * p))/ (m * p ) )^(1/2)))
         pvalueDH <- codeSignif(pvalueDH)
         
         cat("hauteur =",arbre.getH(arbre),
             "\n\t\tDH=",(1 - 2 / (pi * p) - W1/W2 ) /
                     (((2-16/(pi^2 * p))/ (m * p ) )^(1/2)),
             "\n\tF =",((W1 - W2) / W2 ) / (((m-1)/(m-2))*2^(2 / p) - 1 ),
             "\n\tW1=",W1,
             "\n\tW2=",W2,
             "\n\tm=",m,
             "\n\tp=",p,
             "\n\tquantile=",qf(0.95,p,(m-2)*p),
             "\n\tpvalue=",pvalue,"\n")
         pvalue <- codeSignif(pvalue)
     }
     
     
     left.middle <- right.middle <- middle <- 0
     ### passage des param�tres au fils gauche         
     if(arbre$height > height.cut){   ## le pere est > au seuil
        if(arbre.getH(arbre$left) > height.cut ){ ## le fils gauche est aussi > seuil
           left.middle <- p.a(arbre$left ,envir , height.cut , col = col , lty = lty , lwd = lwd ,type=type )
        }
        else{                                ## le fils gauche est <= seuil
           compteur <- get("compteur",envir=envir) + 1
           assign("compteur",compteur,envir=envir)
           col.left      <- get("col.groupes",envir=envir)[compteur]
           lty.left      <- get("lty.groupes",envir=envir)
           lwd.left      <- get("lwd.groupes",envir=envir)
           left.middle <- p.a(arbre$left , envir , height.cut , col = col.left , lty = lty.left , lwd = lwd.left,type=type)
        }
     }
     else{                            ## le pere est <= seuil
        left.middle <- p.a(arbre$left , envir , height.cut , col = col , lty = lty , lwd = lwd,type=type)
     }
     
     
              
     ### passage des param�tres au fils droit         
     if(arbre$height > height.cut){   ## le pere est > au seuil
        if(arbre.getH(arbre$right) > height.cut ){ ## le fils droit est aussi > seuil
           right.middle <- p.a(arbre$right ,envir , height.cut , col = col , lty = lty , lwd = lwd,type=type )
        }
        else{                                ## le fils droit est <= seuil
           compteur <- get("compteur",envir=envir) + 1
           assign("compteur",compteur,envir=envir)
           col.right      <- get("col.groupes",envir=envir)[compteur]
           lty.right      <- get("lty.groupes",envir=envir)
           lwd.right      <- get("lwd.groupes",envir=envir)
           right.middle <- p.a(arbre$right , envir , height.cut , col = col.right , lty = lty.right , lwd = lwd.right,type=type)
        }
     }
     else{                            ## le pere est <= seuil
        right.middle <- p.a(arbre$right , envir , height.cut , col = col , lty = lty , lwd = lwd,type=type)
     }         
     
     middle <- ( left.middle + right.middle ) / 2
     
     if(type=="r"){    
     segments(x0  = c( left.middle , left.middle  , right.middle),
              x1  = c( left.middle , right.middle , right.middle),
              y0  = c( arbre.getH(arbre$left) , arbre$height       , arbre.getH(arbre$right)),
              y1  = c( arbre$height      , arbre$height       , arbre$height      ),
              col = col , lty = lty , lwd = lwd)
     }
     else if(type=="t"){
              segments(x0  = c(left.middle , right.middle),
                       x1  = c( middle      , middle      ),
                       y0  = c( arbre.getH(arbre$left) , arbre.getH(arbre$right)),
                       y1  = c( arbre$height      , arbre$height      ),
                       col = col , lty = lty , lwd = lwd)     
          }
  }
  if(dopvalue) {
    text(middle,arbre$height-strheight("o")/2,pvalue)
    text(middle,arbre$height-strheight("o")  ,pvalueDH)
    
  }
  return(middle)
}