star.graph <- function(XY, Gr, D = 1, taille = 0.1)
{
#
#          Graphique en etoile
#
#    Entrees
#
# XY matrice des coordonnees des points
# Gr matrice des modalites d'appartenance des points
# D metrique des variables, si D=1 alors 1/nIdn, si D est un vecteur alors D=diag(vecteur), sinon D=matrice
# taille dimension en 'inches' des noms des classes sur les graphiques
#
#    Sorties
#       Aucune
#
#    Fonctions exterieures appelees
#       Aucune.
#
#                               R.Sabatier
#                               MAJ 03/04/97
#
        nomfichXY <- deparse(substitute(XY))
        XY <- as.matrix(XY)
        n <- nrow(XY)
        if(length(dimnames(XY)[[1]]) == 0)
                dimnames(XY)[[1]] <- paste("i", 1:n, sep = "")
        Gr <- as.matrix(Gr)
        q <- ncol(Gr)
        if(length(dimnames(Gr)[[2]]) == 0)
                dimnames(Gr)[[2]] <- paste("Var", 1:q, sep = "")
        n2 <- n * n
        k <- ncol(XY)
        if(k < 2)
                return()
        if(n != nrow(Gr)) return()      # calcul de la metrique D
        if(length(D) == 1)
                D <- diag(rep(1/n, n), nrow = n)
        if(length(D) == n)
                D <- diag(D, nrow = n)
        if(length(D) == n2) D <- as.matrix(D)   # verification du graphisme
        if(!exists(".Device", frame = 0)) {
                cat("Initialisez le graphique !!!\n")
                return()
        }
# trace des graphiques
        {
                cat("_______________________________________________________________\n"
                        )
                repeat {
                        cat("graphique pour les u.s. (o/n) ?\n")
                        pltc <- scan("", character(), 1)
			if(length(pltc) == 0)pltc<-"n"
                        if((pltc == "n"))
                                break
                        else {
# choix des numeros axes et de la variable qualitative
                                cat("axe horizontal (<=", k, ") ?\n")
                                pltch <- scan("", numeric(), 1)
                                cat("axe vertical (<=", k, ") ?\n")
                                pltcv <- scan("", numeric(), 1)
                                cat("numero de la var. qual. (<=", q, ") ?\n")
                                pltvqual <- scan("", numeric(), 1)
        # calcul des moyennes par classe
                                nbmodal <- max(Gr[, pltvqual])
                                Cs <- matrix(nrow = nbmodal, ncol = k, 0)
                                if(nbmodal <= 1)
                                  return()
                                poicla <- matrix(ncol = 1, nrow = nbmodal, 0)
                                for(i in 1:n)
                                  poicla[Gr[i, pltvqual]] <- poicla[Gr[i,
                                    pltvqual]] + D[i, i]
                                for(i in 1:n) {
                                  cl <- Gr[i, pltvqual]
                                  poi <- D[i, i]
                                  x <- XY[i, pltch]
                                  y <- XY[i, pltcv]
                                  Cs[cl, pltch] <- Cs[cl, pltch] + x * poi
                                  Cs[cl, pltcv] <- Cs[cl, pltcv] + y * poi
                                }
                                for(i in 1:nbmodal) {
                                  no <- poicla[i]
                                  Cs[i, pltch] <- Cs[i, pltch]/no
                                  Cs[i, pltcv] <- Cs[i, pltcv]/no
                                }
                                dimnames(Cs) <- list(c(1:nbmodal), dimnames(XY)[[
                                  2]])
                                par(mfrow = c(1, 1), pty = "s")
                                axespar <- c(pltch, pltcv)
                                Ctot <- rbind(XY, Cs)
                                plot(Ctot[, axespar], xlab = paste("c", axespar[
                                  1]), ylab = paste("c", axespar[2]), main =
                                  dimnames(Gr)[[2]][pltvqual], type = "p", pch
                                   = 18)
                                for(i in 1:n) {
                                  cl <- Gr[i, pltvqual]
                                  segments(Cs[cl, pltch], Cs[cl, pltcv], XY[i,
                                    pltch], XY[i, pltcv], col = 7)
                                }
                                abline(h = 0)
                                abline(v = 0)
                                points(Cs[, axespar[1]], Cs[, axespar[2]], pch
                                   = 16, mkh = (taille + 0.09), col = 0)
                                points(Cs[, axespar[1]], Cs[, axespar[2]], pch
                                   = 1, mkh = (taille + 0.09), col = 1)
                                text(Cs[, axespar[1]], Cs[, axespar[2]],
                                  dimnames(Cs)[[1]], csi = taille, col = 3)
                        }
                }
        }
}