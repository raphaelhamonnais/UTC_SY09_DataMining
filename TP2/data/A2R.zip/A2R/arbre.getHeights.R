arbre.getHeights <- function(arbre){

if(arbre.isLeaf(arbre)) return(0)
return( sort( c(arbre$height , arbre.getHeights(arbre$left) , arbre.getHeights(arbre$right) )) )

}