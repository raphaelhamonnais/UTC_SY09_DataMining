STATIS <- function(X,D=1){

if(!is.list(X))return()
k <- length(X)
Y <- list(NULL)
WD<- list(NULL)
n <- nrow(X[[1]])
for(i in 1:k){
  Y[[i]]<-Dcenter(X[[i]],D=D)$X
  WD[[i]]<-WDop(Y[[i]],D=D)
}
R <- matrix(1,k,k)
for(i in 1:(k-1))
  for(j in (i+1):k){
     R[i,j]<-RVop(WD[[i]],WD[[j]],D=D)
     R[j,i]<-R[i,j]
  }
diag <- eigen(R,symmetric=T)
valp <- diag$values
vect <- diag$vectors
alpha<- as.vector(abs(diag$vectors[,1]))
WDC <- matrix(0,n,n)
for(i in 1:k) WDC <- WDC+alpha[i]*WD[[i]]
return(list(R     = R,
            valp  = valp,
            alpha = alpha,
            vect  = vect,
            WDC   = WDC,
            D     = D))
}