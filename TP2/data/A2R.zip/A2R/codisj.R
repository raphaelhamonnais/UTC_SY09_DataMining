codisj<- function(x){

                x       <- as.vector(x)
                nbmodal <- max(x)
                X       <- matrix(0,length(x),nbmodal)
                for(i in 1:length(x)) X[i,x[i]]<-1
                return(X)
}