Dcenter <- function(X,D=1){
#D-centrage de la matrice X
X <- as.matrix(X)
if(all(!is.na(X))){
  if(length(D)==1) mx <- apply(X,2,"mean")
  else {
    idx <- D*X
    mx  <- apply(idx,2,"sum")
  }
  X <- sweep(X,2,mx)
}
else {
  mx<-rep(0,ncol(X))
  if(length(D)==1)  for(i in 1:ncol(X)) mx[i]<-mean(X[,i][!is.na(X[,i])])
  else {
    idx<-D*X
    mx<-apply(idx,2,"sum")
  }
  X <- sweep(X,2,mx)
}

return(list(X  = X,
            mx = mx ))
}