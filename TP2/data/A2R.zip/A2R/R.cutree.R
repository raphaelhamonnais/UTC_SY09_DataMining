R.cutree<- function(hclu, # hclu : sortie de hclust
                    k=3){ 

coupe <- cutree(hclu,k=k)

coupe.or <- coupe[hclu$order]
coupe.out<- rep(NA,length(coupe))
j <-  1 #
k <-  coupe.or[1]
for(i in 1:length(coupe)){
   if(coupe.or[i]==k) next
   else{
      coupe.out[which(coupe==k)] <- j
      j <- j + 1
      k <- coupe.or[i]
   }
}
coupe.out[is.na(coupe.out)] <- j
return(coupe.out)
}