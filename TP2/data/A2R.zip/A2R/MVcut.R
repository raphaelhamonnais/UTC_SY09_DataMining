MVcut<-function(X,qual,nbmod=3,equibreaks=F,breaks,labelsquant,labelsqual)
{
#            d�coupage  MultiVariables de variables quantitatives
#       codage disjonctif complet de variables quantitatives et qualitatives plac�es en dernier
#ENTREES
# X matrice de variables quantitatives + d'�ventuelles variables qualitatives (booleennes ou enti�res)
#qual, entier numero de la premi�re colonne qualitative (les autres suivent)
#nbmod vecteur entiers, nombre de modalit�s de chaque variable quantitative
#equibreaks vecteur booleen, si T s�parateurs internes equidistants si F  aux nbmod quantiles
#breaks liste, liste des vecteurs de separateurs interieurs a chaque variable quantitative
#labelsquant liste des noms des modalit�s des variables quantitatives
#labelsqual liste des noms des modalit�s des variables qualitatives
#SORTIES
#X matrice d'entiers des modalites
#U matrice du codage disjonctif complet
#B tableau de Burt
#nbmod vecteur du nb de modalit�s
#breaks liste des vecteurs des s�parateurs int�rieurs + le max de la variable quantitavive
#labels liste des noms des modalit�s des variables
#EXEMPLE
#
# stateafcm<-MVcut(cbind(state.x77,Region=codes(state.region)),qual=ncol(state.x77)+1,labelsqual=sort(levels(state.region)))
# ou bien
# stateafcm<-MVcut(cbind(state.x77,Region=as.numeric(state.region)),qual=ncol(state.x77)+1,labelsqual=levels(state.region))
# afc(stateafcm,AFCM=T)
# pour l'afcm du tableau des var quantitatives + la var qualitative des 4 modalit�s r�gion
#
#
		X<-as.matrix(X)
		n<-nrow(X)
		pX<-ncol(X)
		if(!missing(qual)){
		if(qual>1){
		Xquant<-X[,1:(qual-1),drop=F]
			  }
		else {
		Xquant<-NULL
		U<-NULL
		     }
		Xqual<-X[,qual:pX,drop=F]
		}
		else
		{
		Xquant<-X
		Xqual<-NULL
		}
		if(is.matrix(Xquant))
		{#
		p<-ncol(Xquant)
		if(length(nbmod)==1) nbmod<-rep(nbmod,p)
		if(length(equibreaks)==1)equibreaks<-rep(equibreaks,p)
		if(missing(breaks))
		{
		breaks<-rep(list(NULL),p)
		for(i in 1:p)
			{if(equibreaks[i])
				{etend<-range(Xquant[,i])
				hh<-diff(etend)/nbmod[i]
				for(j in 1:(nbmod[i]))
				breaks[[i]][j]<-etend[1]+j*hh
				}
			else    {
				breaks[[i]]<-quantile(Xquant[,i],probs=(1:nbmod[i])/nbmod[i])
				}
			}
		}
		else
		{nbmod<-rep(0,p)
		for(i in 1:p) {breaks[[i]]<-c(breaks[[i]],max(Xquant[,i]))
				nbmod[i]<-length(breaks[[i]])
				}		
		}
                if(missing(labelsquant)){
			labelsquant<-rep(list(NULL),p)
			for(i in 1:p)
			labelsquant[[i]]<-paste(dimnames(Xquant)[[2]][i],format(1:nbmod[i]),sep="")
		                 	}	
		mat<-Xquant
		for(i in 1:p)
		mat[,i]<-cut(Xquant[,i],breaks=c(min(Xquant[,i])-1,breaks[[i]]),labels=F)
		codage<-Codisjc(mat)
		X<-mat
		U<-codage$U		
	}#
if(is.matrix(Xqual))
		{##
		cat("variables Enti�res ou Codage disjonctif complet?(E ou C)\n")
		pltc <- scan("", character(), 1)
		if((pltc=="E")|(pltc=="e"))
			{codage1<-Codisjc(Xqual)
			V<-codage1$U
			if(missing(labelsqual))
			labelsqual<-codage1$labels
                        else dimnames(V)[[2]]<-labelsqual
			U<-cbind(U,V)
                        nbmodqual<-codage1$nbmod
			}
		else 
		{
		pqual<-sum(Xqual[1,])
		if(pqual==1)cat("rentrez le nombre de modalit�s de cette variable\n")
		else
		cat("Rentrez le nombre de modalit�s pour chacune des",pqual,"variables\n")
		nbmodqual<-scan("",numeric(),pqual)
		U<-cbind(U,Xqual)
		if(missing(labelsqual))
		labelsqual<-dimnames(Xqual)[[2]]
		}
		}##
		B<-t(U)%*%U
	if((is.matrix(Xquant))&(is.matrix(Xqual))) {
					if((pltc=="E")|(pltc=="e"))
					X<-cbind(mat,Xqual)
					labels<-c(labelsquant,labelsqual)
					nbmod<-c(nbmod,nbmodqual)
						}
	if((!is.matrix(Xquant))&(is.matrix(Xqual))) {
					labels<-labelsqual
					nbmod<-nbmodqual
						}
        if((is.matrix(Xquant))&(!is.matrix(Xqual))) labels<-labelsquant
if(is.matrix(Xquant)) return(list(X      = X,
                                  U      = U,
                                  B      = B,
                                  nbmod  = nbmod,
                                  labels = labels,
                                  breaks = breaks))
else return(list(U      = U,
                 B      = B,
                 nbmod  = nbmod,
                 labels = labels))
}