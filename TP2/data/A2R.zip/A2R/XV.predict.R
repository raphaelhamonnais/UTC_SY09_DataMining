XV.predict<-function(Y,X,poids,family="gaussian",type="link",MOD,xlab="CP1 : valeurs r�elles",
                     ylab="CP1 : valeurs pr�dites",leg.text=c("forts","faibles"),leg.col=c(2,4),
                     col=c(rep(2,11),rep(4,11)),trace=T  ){
################## pr�dictions par validation crois�e
#          entr�es :
# Y                -- variable � expliquer
# X                -- dataframe des pr�dicteurs
# poids            -- les poids eventuels
# type             -- type de pr�dictions (voir predict.glm : base)
# MOD              -- le mod�le � tester par XV ( les variables de ce mod�les
#                     doivent etre dans X, si MOD est absent le mod�le utilis�
#                     est glm(Y~.,data=X,....)
# trace            -- T pour afficher les r�sultats et produire les graphs
####################
#          sorties :
# valeurs des pr�dictions

N<-dim(X)[1]
noms.variables<-c("(Intercept)",dimnames(X)[[2]])
X<-as.data.frame(cbind(rep(1,N),X))
dimnames(X)[[2]]<-noms.variables
noms<-dimnames(X)[[1]]

P<-dim(X)[2]

if(missing(poids)) poids<-rep(1,N)
if(missing(MOD)) stop("il faut donner un mod�le\n")

indice<-indice.var(MOD,X,data.intercept=T)
if(is.null(indice)) stop("aucune variable dans le modele\n")
X<-X[,indice]
noms.variables<-noms.variables[indice]
predictions<-rep(NA,N)

for(i in 1:N){
  YY<-Y[-i]
  XX<-as.data.frame(as.data.frame(X)[-i,])
  
  dimnames(XX)[[2]]<-noms.variables
  MODi<-glm(YY~.-1,data=XX,family=family,weights=poids[-i])
  dataf<-as.data.frame(as.data.frame(X)[i,])
  dimnames(dataf)[[2]]<-noms.variables
  predictions[i]<-predict(MODi,newdata=dataf,type=type)
}
if(trace){
  cat("----------------------- mod�le ---------------------------------\n")
  R.summary(MOD)
}
if(family=="binomial"){
  bien.pred<-matrix("",nr=N,nc=11)
  dimnames(bien.pred)<-list(1:N,c("proba","|","Bien ajust�s","|","Mal ajust�s","||","proba","|","Bien Pr�dits","|","Mal pr�dits"))
  
  for(i in 1:N){
    ajust.mod<-(round(MOD$fitted)==Y)
    if(ajust.mod[i]) bien.pred[i,3]<-noms[i]
    else             bien.pred[i,5]<-noms[i]
    if(round(predictions[i])==Y[i]) bien.pred[i,9]<-noms[i]
    else                            bien.pred[i,11]<-noms[i]
    bien.pred[i,c(2,4,8,10)]<-"|"
    bien.pred[i,6]<-"||"
  }
  bien.pred[,1]<-round(MOD$fitted,2)
  bien.pred[,7]<-round(predictions,2)
  ajus.p<-sum(ajust.mod)/N*100
  pred.p<-sum(round(predictions)==Y)/N*100
  if(trace){
     cat("--------------- ajustement -----------||----- validation crois�e(1out)--------\n")
     print(bien.pred,quote=F) 
     cat("------------------------------------------------------------------\n")
     cat("pourcentage de biens ajust�s                              :",round(ajus.p ,2),"%\n")
     cat("pourcentage de biens pr�dits en validation crois�e(1 out) :",round(pred.p ,2),"%\n")
     cat("------------------------------------------------------------------\n")
  }

}
if(family=="gaussian"){
  Yhat     <-MOD$fitted
  meanY    <-sum(poids*Y)/sum(poids)
  varY     <-sum(poids*((Y-meanY)^2) )
  meanYhat <-sum(poids*Yhat)/sum(poids)
  varYhat  <-sum(poids*((Yhat-meanYhat)^2) )
  covar    <-sum(poids*(Y-meanY)*(Yhat-meanYhat))
  
  PRESS<-sum(poids*(Y-predictions)^2) / varY
  R2   <-abs(covar) / sqrt( varY * varYhat )
  if(trace){
     plot(Y,predictions,type="n",xlab=xlab,ylab=ylab,main=paste("validation crois�e(1 out) , PRESS = ",round(PRESS,4)))
     abline(a=0,b=1,col="gray")
     text(Y,predictions,noms,cex=poids*1.2,col=col)
     legend(locator(1),leg.text,pch=22,pt.bg=leg.col,bg="lavender",cex=1.4)
   }

}
if(family=="gaussian") return(invisible(list(predictions=predictions,PRESS=PRESS,R2=R2)))
if(family=="binomial") return(invisible(list(predictions=predictions,ajus.p=ajus.p,pred.p=pred.p)))
}