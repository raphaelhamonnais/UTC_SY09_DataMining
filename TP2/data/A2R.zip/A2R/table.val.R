table.val<-function(N, fl = 1, fc = 1, ptypar = "s", type = 1, taille = 0.6, ...)
{
#
#          Graphique plan d'un tableau de contingence
#
#    Entrees
#
# N tableau de contingence
# type  forme du graphique : 1 on represente le tableau de contingence
#                            2 on represente les profils lignes
#                            3 on represente les profils colonnes
#                            4 on represente nij/ni.n.j - 1
# taille facteur de proportionalite pour les graphiques
#
#                               R.Sabatier revu par JFD ....
# lecture des donnees
        nomfichN <- deparse(substitute(N))
        N <- as.matrix(N)
#        if(length(c(which.inf(N), which.na(N))))
#               stop("valeurs manquantes ou infinies dans N")
        I <- nrow(N)
        J <- ncol(N)
        n <- sum(N)
        if(type < 1 | type > 4)
                return()        # verification du graphisme
        if(!exists(".Device", frame = 0)) {
                cat("Initialisez le graphique !!!\n")
                return()
        }
# graphique au carre ou rectangle
        par(pty = ptypar)
        # fichier si ordonancement selon fc et fl apres une analyse factorielle
        if(length(fl) != 1) {
                grfl <- 1
                fl <- as.matrix(fl)
                if(nrow(fl) != I)
                        return()
                ql <- ncol(fl)
                cat("numero de la var. ordre ligne (<=", ql, ") ?\n")
                pltfl <- scan("", numeric(), 1)
        }
        else grfl <- 0
        if(length(fc) != 1) {
                grfc <- 1
                fc <- as.matrix(fc)
                if(nrow(fc) != J)
                        return()
                qc <- ncol(fc)
                cat("numero de la var. ordre colonne (<=", qc, ") ?\n")
                pltfc <- scan("", numeric(), 1)
        }
        else grfc <- 0
        N <- N/n
        xy <- matrix(ncol = 2, nrow = I * J, NA)
        Z <- matrix(nrow = I * J, ncol = 1, NA)
        for(i in 1:I)
                for(j in 1:J) {
                        ij <- i + (j - 1) * I
                        if(grfc == 0)
                                xy[ij, 1] <- j
                        else xy[ij, 1] <- fc[j, pltfc]
                        if(grfl == 0)
                                xy[ij, 2] <- i
                        else xy[ij, 2] <- fl[i, pltfl]
                        if(type == 1)
                                Z[ij] <- N[i, j]
                        if(type == 3)
                                Z[ij] <- N[i, j]/sum(N[, j])
                        if(type == 2)
                                Z[ij] <- N[i, j]/sum(N[i,  ])
                        if(type == 4)
                                Z[ij] <- N[i, j]/(sum(N[, j]) * sum(N[i,  ])) -
                                  1
                }
# calcul de la taille des cercles et carres
        minx <- min(xy[, 1]) - 1.77 * taille * sqrt(abs(max(Z)))
        maxx <- max(xy[, 1]) + 1.77 * taille * sqrt(abs(max(Z)))
        miny <- min(xy[, 2]) - 1.77 * taille * sqrt(abs(max(Z)))
        maxy <- max(xy[, 2]) + 1.77 * taille * sqrt(abs(max(Z)))
        ming <- min(minx, miny)
        maxg <- max(maxx, maxy) # trace
        if(type == 2) {
                par(mar = c(5.1, 10, 4.1, 2.1), mgp = c(0, 5, 0))
                plot(xy, type = "p", pch = 4, xlim = c(ming, maxg), ylim = c(
                        ming, maxg), xlab = "", ylab = "", mkh = 0.01, bty =
                        "l", axes = F, las = 1, main = "Profils", col =
                        1)
                axis(2, at = 1:I, labels = dimnames(N)[[1]], col = 1, ...)
        }
        if(type == 3) {
                par(mar = c(8, 4.1, 4.1, 2.1), mgp = c(0, 2, 0))
                plot(xy, type = "p", pch = 4, xlim = c(ming, maxg), ylim = c(
                        ming, maxg), xlab = "", ylab = "", mkh = 0.01, bty =
                        "l", xaxt = "n", axes = F, las = 2, main =
                        "Profils", col = 1)
                axis(1, at = 1:J, labels = format(1:J), col = 1, ...)
        }
        if((type == 1) | (type == 4)) {
                if(type == 1)
                        titre <- "Table de Contingence"
                else titre <- "Tableau  Pij / Pi.P.j  -  1"
                plot(xy, type = "p", pch = 4, xlim = c(ming, maxg), ylim = c(
                        ming, maxg), xlab = "", xaxt = "n", yaxt = "n", ylab =
                        "", mkh = 0.01, bty = "l", main = titre, col = 1)
                axis(1, at = 1:J, labels = format(1:J), col = 1, ...)
                axis(2, at = 1:I, labels = dimnames(N)[[1]], col = 1, ...)
        }
        xyp <- matrix(nrow = I * J, ncol = 2, NA)
        xyn <- matrix(nrow = I * J, ncol = 2, NA)
        rp <- matrix(nrow = I * J, ncol = 1, NA)
        rn <- matrix(nrow = I * J, ncol = 1, NA)
        iip <- 1
        iin <- 1
        IJ <- I * J
        for(i in 1:IJ) {
                if(Z[i] > 0) {
                        rp[iip] <- taille * sqrt(Z[i])
                        xyp[iip,  ] <- xy[i,  ]
                        iip <- iip + 1
                }
                if(Z[i] < 0) {
                        rn[iin] <- 1.77 * taille * sqrt( - Z[i])
                        xyn[iin,  ] <- xy[i,  ]
                        iin <- iin + 1
                }
}
        if(any(Z >= 0))
                symbols(xyp[, 1], xyp[, 2], circles = rp, inches = F, add = T,
                        xpd = T, smo = 0, col = 2)
        if(any(Z < 0))
                symbols(xyn[, 1], xyn[, 2], squares = rn, inches = F, add = T,
                        xpd = T)
}