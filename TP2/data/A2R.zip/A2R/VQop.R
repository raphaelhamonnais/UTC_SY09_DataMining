VQop <- function(X,Y=X,Q=1,D=1){
# operateur crossproduct generalise, i.e., X'DYQ;
# Q matrice ou vecteur est une metrique sur l'espace des variables de Y,
#                   par defaut Q=1 donne l'identite
#                   si Q=k alors Q=kI
#                   si Q=vecteur alors Q=diag(vecteur);
# D est un vecteur, par defaut D=1 donne le vecteur 1/nrow(X);
Y <- as.matrix(Y)
X <- as.matrix(X)
        
if(length(D)==1) DD <- rep(1/nrow(X),nrow(X)) 
else             DD <- as.vector(D)

for(i in 1:nrow(X)) X[i,]<-DD[i]*X[i,]
if(! is.matrix(Q)) {
  QQ <- as.vector(Q)
  if(length(QQ)==1 & QQ[1]==1){ 
    V <- crossprod(X,Y)
    return(V)
  }
  if(length(QQ)==1 & QQ[1]!=1) QQ <- rep(QQ,ncol(Y))
  for(i in  1:ncol(Y)) Y[,i] <- Y[,i]*QQ[i]
  V <- crossprod(X,Y)
  return(V)
}
V <- crossprod(X,Y)%*%Q
return(V)

}