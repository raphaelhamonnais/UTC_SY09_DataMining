centresGravite <- function(X,groupes){

X      <- as.matrix(X)
DD     <- codisj(groupes)
sortie <- solve(t(DD)%*%DD)%*%t(DD)%*%X
#dimnames(sortie) <- list(paste("g",1:nrow(sortie),sep=""),colnames(X))
dimnames(sortie) <- list(1:nrow(sortie),colnames(X))
return(sortie)
}