acpxqd <- function(X,               # matrice (n x p) des variables
                   Q = 1,           # metrique des u.s. : si Q=1 alors Q=Idn, si Q est un vecteur alors Q=diag(vecteur), sinon Q=matrice
                   D = 1,           # metrique des variables, si D=1 alors 1/nIdn, si D est un vecteur alors D=diag(vecteur), sinon D=matrice
                   centrer = T,     # F on ne centre pas X, sinon T on centre
                   cor = T,         # cor=F on ne reduit pas, centrage et reduction si cor=T
                   k = 3,           # nombre de composantes retenues
                   Xl = 1,          # matrice eventuelle des u.s. supplememtaires
                   Xc = 1           # Xc matrice eventuelle des variables supplememtaires
){
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#~~~~~~~~~~~~~~~~~~~~~~~~~~  DVS d'un triplet (X,Q,D) ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
#
#    Sorties 
#
# un objet de la classe "acp" (--> classe.acp.R <--)
#
#    Fonctions exterieures appelees
#
#  Dcentred
#
#                               R.Sabatier
#
# modifiee par Romain Francois <francoisromain@free.fr>
# derniere MAJ 27/12/2004 14:43


##########################################################################################
# lecture des donnees
        if(ncol(X) < 2) stop("pas assez de variables (1)")

        nomfichX <- deparse(substitute(X))
        X        <- as.matrix(X)  # pour se pr�munir de la structure de data.frame
        n        <- nrow(X)
        p        <- ncol(X)
        if(is.null(dimnames(X))) dimnames(X) <- list(format(1:n), paste("v", 1:p,sep = ""))
        if(length(dimnames(X)[[1]]) == 0) dimnames(X)[[1]] <- format(1:n)
        if(length(dimnames(X)[[2]]) == 0) dimnames(X)[[2]] <- paste("v", 1:p, sep = "")
        Xini     <- as.matrix(X)

        if(centrer == FALSE) cor     <- FALSE
        if(cor == TRUE)      centrer <- TRUE

##################################
# initialisations
        p2     <- p * p
        n2     <- n * n
        As     <- as.matrix(1)
        Cs     <- as.matrix(1)
        CTRus  <- NULL
        COSus  <- NULL
        CTRva  <- NULL
        COSva  <- NULL   
        valp   <- NULL       # vecteur des valeurs propres
        A      <- NULL       # matrice des facteurs principaux
        C      <- NULL       # matrice des composantes principales

#########################
# calcul de la metrique Q
        if(length(Q) == 1)  Q <- diag(p)
        if(length(Q) == p)  Q <- diag(Q, nrow = p)
        if(length(Q) == p2) Q <- as.matrix(Q)       
#########################
# calcul de la metrique D
        if(length(D) == 1)  D <- diag(rep(1/n, n), nrow = n)
        if(length(D) == n)  D <- diag(D, nrow = n)
        if(length(D) == n2) D <- as.matrix(D)
        
################################################
# verifications u.s. et variables supplementaires
        if(length(Xl) != 1) {
                isup <- TRUE
                Xl   <- as.matrix(Xl)
                if(ncol(Xl) != ncol(X)) return()
                if(is.null(dimnames(Xl))) dimnames(Xl) <- list(paste("is", 1:n, sep = ""), paste("v", 1:p, sep = ""))
                if(length(dimnames(Xl)[[1]]) == 0)dimnames(Xl)[[1]]  <- paste("is", 1:n, sep = "")
                if(length(dimnames(Xl)[[2]]) == 0) dimnames(Xl)[[2]] <- paste("v", 1:p, sep = "")
        }
        else isup <- FALSE
        if(length(Xc) != 1) {
                vsup <- TRUE
                Xc <- as.matrix(Xc)
                if(nrow(Xc) != nrow(X)) return()
                if(is.null(dimnames(Xc))) dimnames(Xc) <- list(paste("i", 1:n, sep = ""), paste("vs", 1:ncol(Xc), sep = ""))
                if(length(dimnames(Xc)[[1]]) == 0) dimnames(Xc)[[1]] <- paste("i", 1:n, sep = "")
                if(length(dimnames(Xc)[[2]]) == 0) dimnames(Xc)[[2]] <- paste("vs", 1:p, sep = "")
                
        }
        else vsup <- FALSE
        if(centrer == T) {
                centrage <- Dcentred(X, D = D)
                X        <- centrage$Xc
                meanX    <- matrix(centrage$moy)
                varX     <- matrix(centrage$var)
                dimnames(meanX)  <- list(dimnames(X)[[2]], "moy")
                dimnames(varX)   <- list(dimnames(X)[[2]], "var")
                if(isup) Xl <- sweep(Xl, 2, meanX)
                if(vsup) {
                        centragevs <- Dcentred(Xc, D = D)
                        Xc         <- centragevs$Xc
                }
        }
        if(cor == T) {
           X <- centrage$Xcr
           if(isup) Xl <- sweep(Xl, 2, sqrt(varX), FUN = "/")
           if(vsup) Xc <- centragevs$Xcr
        }

################################
# decomposition de Choleski de Q
        Qhalf     <- chol(round(Q, 6))
        Y         <- X %*% t(Qhalf)     # diagonalisation
        diago     <- t(Y) %*% D %*% Y
        eg        <- eigen(diago, symmetric = T)
        valp      <- eg$values
        for(i in 1:ncol(diago)) if(valp[i] < 0) valp[i] <- 0
        inertiaX  <- sum(valp) 
####################################
# calcul des composantes principales
        Cent <- Y %*% eg$vectors
        C    <- Cent[, 1:k]
        if(k == 1) C <- as.matrix(C)
        dimnames(C) <- list(dimnames(X)[[1]], paste("c", format(1:k), sep = ""))       
###########################
# calcul des axes principaux
        Aent <- matrix(NA, nrow = ncol(X), ncol = p)
        if(length(Q) != 1) fac <- solve(Qhalf) %*% eg$vectors
        else               fac <- eg$vectors
        for(i in 1:p) Aent[, i] <- (fac[, i]) * sqrt(valp[i])
        A <- Aent[, 1:k]
        dimnames(A) <- list(dimnames(X)[[2]], paste("a", format(1:k), sep = ""))       
###############################
# calcul des facteurs principaux
        Fa <- matrix(NA, nrow = ncol(X), ncol = k)
        Fa <- Q %*% A
        dimnames(Fa) <- list(dimnames(X)[[2]], paste("f", format(1:k), sep = ""))      
##########################################################
# calcul des coordonnees u.s. et variables supplementaires
        if(isup) {
            Cs <- Xl %*% Q %*% A
            for(i in 1:k)
            Cs[, i] <- (Cs[, i])/sqrt(valp[i])
            dimnames(Cs) <- list(dimnames(Xl)[[1]], paste("c", format(1:k),sep = ""))
        }
        if(vsup) {
            As <- t(Xc) %*% D %*% C
            for(i in 1:k) As[, i] <- (As[, i])/sqrt(valp[i])
            dimnames(As) <- list(dimnames(Xc)[[2]], paste("a", format(1:k),sep = ""))
        }
######################################
# calcul  des aides a l'interpretation

                CTRus <- matrix(NA, nrow = n, ncol = k)
                COSus <- CTRus
                for(i in 1:n) for(j in 1:k) CTRus[i, j] <- round((D[i, i] * C[i, j]^2)/valp[j] * 10000, digits = 0)
                dimnames(CTRus) <- list(dimnames(X)[[1]], paste("CTA", format(1:k), sep = ""))
                for(i in 1:n) {
                   ss <- 0
                   for(j in 1:p) ss <- ss + Cent[i, j]^2
                   for(j in 1:k) COSus[i, j] <- round(Cent[i, j]^2/ss * 10000,digits = 0)
                }
                dimnames(COSus) <- list(dimnames(X)[[1]], paste("COS", format(1:k), sep = ""))

                CTRva <- matrix(NA, nrow = p, ncol = k)
                COSva <- CTRva
                for(i in 1:p) for(j in 1:k) CTRva[i, j] <- round((Q[i, i] * A[i, j]^2)/valp[j] * 10000, digits = 0)
                dimnames(CTRva) <- list(dimnames(X)[[2]], paste("CTA", format(1:k), sep = ""))
                for(i in 1:p) {
                    ss <- 0
                    for(j in 1:p) ss <- ss + Aent[i, j]^2
                    for(j in 1:k) COSva[i, j] <- round(Aent[i, j]^2/ss * 10000,digits = 0)
                }
                dimnames(COSva) <- list(dimnames(X)[[2]], paste("COS", format(1:k), sep = ""))

invisible(
  return(   new("acp",
                 nomfichX   = nomfichX, 
                 Xini       = Xini, 
                 X          = X, 
                 Q          = Q, 
                 D          = D, 
                 inertiaX   = inertiaX, 
                 k          = k, 
                 valp       = valp, 
                 Fa         = Fa, 
                 A          = A, 
                 CP         = C, 
                 CTRus      = CTRus, 
                 COSus      = COSus, 
                 CTRva      = CTRva, 
                 COSva      = COSva, 
                 As         = As, 
                 Cs         = Cs,
                 cor        = cor,
                 centrer    = centrer )))
}