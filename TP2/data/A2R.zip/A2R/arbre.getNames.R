arbre.getNames <- function(arbre # un arbre (g�n�r� par hclust2arbre
                          ){
## retourne les noms des feuilles de l'arbre (dans l'ordre de l'arbre)

if(arbre.isLeaf(arbre)) return(arbre)
return(c(arbre.getNames(arbre$left),arbre.getNames(arbre$right)))

}
