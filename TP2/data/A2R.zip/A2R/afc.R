afc<-function(N, AFCM=F,lignesup,colsup,DI = 1, DJ = 1, M = 1, k = 3, ns = F, impres = T, graph = T,colpar=1,bgpar="lavender",cexpar=0.7,
              col.ind=NULL,col.ind.sup=NULL,col.var=NULL,col.var.sup=NULL,cex.lim=c(1,1))
{
#
#       afc et afc generalisee par rapport a un modele avec metriques lignes et colonnes quelconques
#
#       afcm si AFCM=T, alors N est le resultat de MVcut(X) ou de Codisjc(X) donnant le codage disjonctif
#       complet du tabeau X. Exemple: afc(MVcut(X),AFCM=T)
#
#
#    Entrees
#
# N tableau de contingence ou resultat de MVcut ou de Codisjc si AFCM=T, 
# lignesup, matrice des lignes supplementaires
# colsup, matrice des colonnes supplementaires
# DI metrique des lignes, si absent c'est la marge
# DJ metrique des colonnes, si absent c'est la marge
# M modele (matrice meme dim que N) si c'est une afc par rapport a un modele, sinon M=1
# k nombre de composantes retenues, par defaut 3
# ns=T si afc non symetrique, si ns=F afc normale
# impres impression des resultats si T, si F rien
# graph trace des graphiques si T, si F pas de trace
# bgpar couleur du background graphique, utiliser aussi "cornsilk" ou "lightgray" utiliser aussi colours()[624]
#
#    Sorties
#
# nomfichX nom du fichier X
# Nini tableau initial
# X tableau apres eventuelle transformation
# DI metrique ligne
# DJ metrique colonne
# inertia inertie du triplet
# k rang de la DSD retenue
# valp vecteur de toutes les valeurs propres
# A matrice des k premiers axes de la DSD
# C matrice des k premieres composantes principales de la DSD
# CTRus et COSus contributions absolues et relatives des u.s. pour les k premieres composantes
# CTRva et COSva contributions absolues et relatives des variables pour les k premiers axes
#
#    Fonctions exterieures appelees
#
#       acpxqd, Dcentred
#
#                               R.Sabatier   revu par JF Durand
#                              MAJ 03/04/97            05/03/2001
#


# lecture des donnees
      
nomfichN <- deparse(substitute(N))
if(AFCM){
  nbmod<-N$nbmod
  labels<-N$labels
  N<-N$U
}
N <- as.matrix(N)
M <- as.matrix(M)

#        if(length(c(which.inf(N), which.na(N))))
#               stop("valeurs manquantes ou infinies dans N")
#        if(length(c(which.inf(M), which.na(M))))
#                stop("valeurs manquantes ou infinies dans M")

Nini <- N
I <- nrow(N)
J <- ncol(N)
IJ <- I * J
if((I <= 2)|(J<=2) ) return()
if(length(M) != 1 && ns == T) stop("conflits de parametres entre M et ns")
if(impres == F) graph <- F
        
n <- sum(N)
P <- N/n
I1 <- matrix(1, nrow = I, ncol = 1)
J1 <- matrix(1, nrow = J, ncol = 1)     # metriques si afc non symetrique
if(ns == T) {
    DJ <- diag(J)
    DI <- diag(P %*% J1, nrow = I)
}
else {
        #calcul de la metrique DI
    if(length(DI) == 1) DI <- diag(as.vector(P %*% J1))
    if(length(DI) == I) DI <- diag(as.vector(DI))
        #calcul de la metrique DJ
    if(length(DJ) == 1) DJ <- diag(as.vector(t(I1) %*% P))
    if(length(DJ) == J) DJ <- diag(as.vector(DJ))
}
	 # les elements supplementaires doivent etre des frequences
if(!missing(lignesup)){
   lignesup<-as.matrix(lignesup)
   lignesup<-sweep(lignesup,1,apply(lignesup,1,sum),FUN="/")
}
if(!missing(colsup)){
   colsup<-as.matrix(colsup)
   colsup<-sweep(colsup,2,apply(colsup,2,sum),FUN="/")
}
if(impres) {
   cat("_______________________________________________________________\n")
   if(ns == F)         cat("            - afc de ", nomfichN, " -\n")
   if(ns == T)         cat("            - afc non symetrique de ", nomfichN," -\n")
   if(length(M) == IJ) cat("              par rapport a un modele\n")
}

       # calcul de X, mis dans N
if(length(M) == 1) {
   if(ns == F)
   for(i in 1:I) for(j in 1:J) N[i, j] <- P[i, j]/(DJ[j, j] * DI[i, i]) - 1
   if(ns == T)   for(i in 1:I) for(j in 1:J) N[i, j] <- (P[i, j]/DI[i, i]) - diag(t(I1) %*%P, nrow = J)[j, j]
}
if(length(M) == IJ) for(i in 1:I) for(j in 1:J) N[i, j] <- (P[i, j] - M[i, j]/n)/(DJ[j, j] * DI[i, i])
        
res <- acpxqd(N, Q = DJ, D = DI, centrer = F, k = k)
inertia <- res@inertiaX
chi2 <- n * inertia
ddl <- (I - 1) * (J - 1)
valp <- res@valp
C <- res@CP
k <- res@k
A <- res@A
coordcolsup<-coordlignesup<-NULL
if(!missing(colsup))   coordcolsup  <-t(colsup)%*%C[,1:k]%*%solve(sqrt(diag(valp[1:k])))
if(!missing(lignesup)) coordlignesup<-lignesup%*%A[,1:k]%*%solve(sqrt(diag(valp[1:k])))

CTRus <- res@CTRus
COSus <- res@COSus
CTRva <- res@CTRva
COSva <- res@COSva


if(graph){
   par(bg=bgpar)
   palette(rainbow(6))
}
if(impres == T) {
   cat("_______________________________________________________________\n")
   cat(paste("Inertie totale =", format(inertia),"\n"))
   cat(paste("nb de lignes   =", I, "\n"))
   cat(paste("nb de colonnes =", J, "\n"))
   cat(paste("effectif total =", n, "\n"))
   if(ns == F) cat(paste("D2 d'independance =", format(chi2),", d.d.l. =", ddl, ", Chi2 critique =", 
                         format(qchisq(0.95, ddl)),"(0.05)"), "\n")
                
   cat("_______________________________________________________________\n")
   cat("diagramme des valeurs propres (o ou n) ?\n")
   plth <- scan("", character(), 1)
   if(length(plth) == 0) plth <- "n"
   if(plth == "o" || plth == "O") {
      pp <- length(valp)
      
      valtab <- matrix(0, pp, 3)
      dimnames(valtab) <- list(format(1:pp), c("val.pro.","% inert.", "% cumul."))
      valtab[, 2] <- valp/inertia * 100
      for(i in 1:pp) valtab[i, 3] <- sum(valtab[1:i, 2])
      valtab[, 1]   <- round(valp,5)
      valtab[, 2:3] <- round(valtab[,2:3],2)
      print(valtab)
	if(graph){
         par(mfrow = c(1, 1))
         barplot(valp, space = 2, names = format(1:J), col = 1:max(I,J))
         title("valeurs propres")
	}
		
   }
}

# calcul et impression des aides a l'interpretation

if((impres == T) | length(D) == I) {
   cat("_______________________________________________________________\n")
   cat("aides a l'interpretation pour les modalites lignes (o/n) ?\n")
   plta <- scan("", character(), 1)
   if(length(plta) == 0) plta <- "n"
   if(plta == "o" || plth == "O") {
      cat("Contributions absolues des", I,"modalites pour les", k,"premieres composantes\n")
      print(CTRus)
      cat("\nContributions relative des", I,"modalites pour les", k,"premieres composantes\n")
      print(COSus)
   }
}
if((impres == T) | length(D) == J) {
   cat("_______________________________________________________________\n")
   cat("aides a l'interpretation pour les modalites colonnes (o/n) ?\n")
   plta <- scan("", character(), 1)
   if(length(plta) == 0) plta <- "n"
   if(plta == "o" || plth == "O") {
      cat("Contributions absolues des", J,"modalites pour les", k, "premiers axes\n")
      print(CTRva)
      cat("\nContributions relatives des", J,"modalites pour les", k, "premiers axes\n")
      print(COSva)
   }
}

# trace des eventuels graphiques
if(graph == T) {
   cat("_______________________________________________________________\n")
   repeat {
      cat("graphique pour les composantes (lignes) (o/n) ?\n")
      pltc <- scan("", character(), 1)
	if(length(pltc) == 0) pltc<-"n"
      if((pltc == "n")) break
      
      cat("2D (1) ou 3D (2) :\n")
      pltd<-scan("",numeric(),1)
      if(pltd==1){
        cat("axe horizontal (<=", k, ") ?\n")
        pltch <- scan("", numeric(), 1)
        cat("axe vertical (<=", k, ") ?\n")
        pltcv <- scan("", numeric(), 1)
        par(mfrow = c(1, 1), pty = "s")
        axespar <- c(pltch, pltcv)
        pf.plot(axespar,C,coordlignesup,col.ind,col.ind.sup,COSus,cex.lim,valp,inertia,fleches=F,COR=F)
      }
      if(pltd==2){
        cat("axe des x (<=", k, ") ?\n")
        pltx<-scan("", numeric(), 1)
        cat("axe des y (<=", k, ") ?\n")
        plty<-scan("", numeric(), 1)
        cat("axe des z (<=", k, ") ?\n")
        pltz<-scan("", numeric(), 1)
        hyperplot.indiv(c(pltx,plty,pltz),C,coordlignesup,col.ind,col.ind.sup,COSus,cex.lim,valp,inertia)
      }
   }
   cat("_______________________________________________________________\n")
   repeat {
      cat("graphique pour les axes (colonnes) (o/n) ?\n")
      plta <- scan("", character(), 1)
	if(length(plta) == 0) plta<-"n"
      if((plta == "n")) break
      
      cat("2D (1) ou 3D (2) :\n")
      pltd<-scan("",numeric(),1)
      if(pltd==1){
         cat("axe horizontal (<=", k, ") ?\n")
         pltah <- scan("", numeric(), 1)
         cat("axe vertical (<=", k, ") ?\n")
         pltav <- scan("", numeric(), 1)
         par(mfrow = c(1, 1), pty = "s")
         axespar <- c(pltah, pltav)
         pf.plot(axespar,A,coordcolsup,col.var,col.var.sup,COSva,cex.lim,valp,inertia,fleches=F,COR=F)

   	   if(sum((diag(DI)-(1/I))^2)<1e-16){# cas AFCM
	      repeat{
               cat("relier des modalit�s d'une variable (o/n) ?\n")
               plta <- scan("", character(), 1)
	         if(length(plta) == 0) plta<-"n"
               if((plta == "n")) break
                
               palette(rainbow(12))
	         cat("numero de la variable (<=",length(nbmod),"), et de la couleur\n")
		   num<-scan("",numeric(),2)
		   if(num[1]==1)cumul<-0 else cumul<-sum(nbmod[1:(num[1]-1)])
		   lines(A[(cumul+1):(cumul+nbmod[num[1]]),axespar],col=num[2])
               text(A[(cumul+1):(cumul+nbmod[num[1]]),axespar],dimnames(A)[[1]][(cumul+1):(cumul+nbmod[num[1]])],col=num[2],cex=cexpar)
		   palette(rainbow(6))
	      }
	   }
      }
      if(pltd==2){
         cat("axe des x (<=", k, ") ?\n")
         pltx<-scan("", numeric(), 1)
         cat("axe des y (<=", k, ") ?\n")
         plty<-scan("", numeric(), 1)
         cat("axe des z (<=", k, ") ?\n")
         pltz<-scan("", numeric(), 1)
         axespar<-c(pltx,plty,pltz)
         s3d<-hyperplot.indiv(axespar,A,coordcolsup,col.var,col.var.sup,COSva,cex.lim,valp,inertia)
         if(sum((diag(DI)-(1/I))^2)<1e-16){# cas AFCM
	      repeat{
               cat("relier des modalit�s d'une variable (o/n) ?\n")
               plta <- scan("", character(), 1)
	         if(length(plta) == 0) plta<-"n"
               if((plta == "n")) break
                
               palette("default")
	         cat("numero de la variable (<=",length(nbmod),"), et de la couleur\n")
		   num<-scan("",numeric(),2)
		   if(num[1]==1)cumul<-0 else cumul<-sum(nbmod[1:(num[1]-1)])
               s3d$points(A[(cumul+1):(cumul+nbmod[num[1]]),axespar],col=num[2],type="l")
            }
	   }
      }
   }
   cat("_______________________________________________________________\n")
   repeat {
      cat("representations simultanees (o/n) ?\n")
      plta <- scan("", character(), 1)
	if(length(plta) == 0) plta<-"n"
      if((plta == "n")) break
      
      cat("2D (1) ou 3D (2) :\n")
      pltd<-scan("",numeric(),1)
      if(pltd==1){
         cat("axe horizontal (<=", k, ") ?\n")
         pltah <- scan("", numeric(), 1)
         cat("axe vertical (<=", k, ") ?\n")
         pltav <- scan("", numeric(), 1)
         par(mfrow = c(1, 1), pty = "s")
         axespar <- c(pltah, pltav)
         if(is.null(col.ind))                               col.tot    <-rep(4,dim(C)[1])
         else if(length(col.ind)==1)                        col.tot    <-rep(col.ind,dim(C)[1])
              else                                          col.tot    <-col.ind
         if(is.null(col.var))                               col.tot    <-c(col.tot,rep(2,dim(A)[1]))
         else if(length(col.var)==1)                        col.tot    <-c(col.tot,rep(col.var,dim(A)[1]))
              else                                          col.tot    <-c(col.tot,col.var)
         if(is.null(rbind(coordlignesup,coordcolsup)))      col.tot.sup<-NULL
         else{
            if(is.null(coordlignesup)|is.null(col.ind.sup)) col.tot.sup<-NULL
            else if(length(col.ind.sup)==1)                 col.tot.sup<-rep(col.ind.sup,dim(coordlignesup)[1])
                 else                                       col.tot.sup<-col.ind.sup
 
            if(is.null(coordcolsup)|is.null(col.var.sup))   col.tot.sup<-c(col.tot.sup,NULL)
            else if(length(col.var.sup)==1)                 col.tot.sup<-c(col.tot.sup,rep(col.var.sup,dim(coordcolsup)[1]))
                 else                                       col.tot.sup<-c(col.tot.sup,col.var.sup)         
         }
	 pf.plot(axespar,rbind(C,A),rbind(coordlignesup,coordcolsup),col.tot,col.tot.sup,rbind(COSus,COSva),cex.lim,valp,inertia,fleches=F,COR=F)
         if(sum((diag(DI)-(1/I))^2)<1e-16){
	      repeat {#repeat
              cat("relier des modalit�s d'une variable (o/n) ?\n")
              plta <- scan("", character(), 1)
	        if(length(plta) == 0) plta<-"n"
              if((plta == "n")) break
              palette("default")
	        cat("numero de la variable (<=",length(nbmod),"), et de la couleur\n")
	        num<-scan("",numeric(),2)
	        if(num[1]==1)cumul<-0 else cumul<-sum(nbmod[1:(num[1]-1)])
	        lines(A[(cumul+1):(cumul+nbmod[num[1]]),axespar],col=num[2],lty=2)
		truc <- A[(cumul+1):(cumul+nbmod[num[1]]),axespar]
		nnnn <- nrow(truc)
		
		x0   <- truc[1:(nnnn-1),1]
		x1   <- truc[2: nnnn   ,1]
		x1   <- (x0+x1)/2
		y0   <- truc[1:(nnnn-1),2]
		y1   <- truc[2:nnnn,2]
		y1   <- (y0+y1)/2
		
		arrows(x0=x0,x1=x1,y0=y0,y1=y1,col=num[2],lty=2)     
           }
	   }
         else{##cas afc simple
	      repeat {
               cat("relier des modalit�s d'une variable (o/n) ?\n")
               plta <- scan("", character(), 1)
	         if(length(plta) == 0) plta<-"n"
               if((plta == "n")) break
               cat("Rentrez 2 chiffres\n")
	         cat("ligne (1) ou colonne (2) ou ligne sup (3) ou col sup(4) et le numero de la couleur\n")
	         num<-scan("",numeric(),2)
	         if(num[1]==1){
	           lines(C[,axespar],col=num[2])
                 text(C[,axespar],dimnames(C)[[1]],col=num[2],cex=cexpar)
	         }
	         if(num[1]==2){
	            lines(A[,axespar],col=num[2])
                  text(A[,axespar],dimnames(A)[[1]],col=num[2],cex=cexpar)
               }
               if(num[1]==3){
	            lines(coordlignesup[,axespar],col=num[2])
                  text(coordlignesup[,axespar],dimnames(lignesup)[[1]],col=num[2],cex=cexpar)
               }
	         if(num[1]==4){
	            lines(coordcolsup[,axespar],col=num[2])
                  text(coordcolsup[,axespar],dimnames(colsup)[[2]],col=num[2],cex=cexpar)
               }
	      }
         }##
     }
     if(pltd==2){
        cat("axe des x (<=", k, ") ?\n")
        pltx<-scan("", numeric(), 1)
        cat("axe des y (<=", k, ") ?\n")
        plty<-scan("", numeric(), 1)
        cat("axe des z (<=", k, ") ?\n")
        pltz<-scan("", numeric(), 1)
        axespar<-c(pltx,plty,pltz)
        if(is.null(col.ind))                               col.tot    <-rep(4,dim(C)[1])
        else if(length(col.ind)==1)                        col.tot    <-rep(col.ind,dim(C)[1])
             else                                          col.tot    <-col.ind
        if(is.null(col.var))                               col.tot    <-c(col.tot,rep(2,dim(A)[1]))
        else if(length(col.var)==1)                        col.tot    <-c(col.tot,rep(col.var,dim(A)[1]))
             else                                          col.tot    <-c(col.tot,col.var)
        if(is.null(rbind(coordlignesup,coordcolsup)))      col.tot.sup<-NULL
        else{
           if(is.null(coordlignesup)|is.null(col.ind.sup)) col.tot.sup<-NULL
           else if(length(col.ind.sup)==1)                 col.tot.sup<-rep(col.ind.sup,dim(coordlignesup)[1])
                else                                       col.tot.sup<-col.ind.sup
           if(is.null(coordcolsup)|is.null(col.var.sup))   col.tot.sup<-c(col.tot.sup,NULL)
           else if(length(col.var.sup)==1)                 col.tot.sup<-c(col.tot.sup,rep(col.var.sup,dim(coordcolsup)[1]))
                else                                       col.tot.sup<-c(col.tot.sup,col.var.sup)         
        }
        s3d<-hyperplot.indiv(axespar,rbind(C,A),rbind(coordlignesup,coordcolsup),col.tot,col.tot.sup,rbind(COSus,COSva),cex.lim,valp,inertia)
        if(sum((diag(DI)-(1/I))^2)<1e-16){
	     repeat {
              cat("relier des modalit�s d'une variable (o/n) ?\n")
              plta <- scan("", character(), 1)
	        if(length(plta) == 0) plta<-"n"
              if((plta == "n")) break
	        cat("numero de la variable (<=",length(nbmod),"), et de la couleur\n")
	        num<-scan("",numeric(),2)
	        if(num[1]==1)cumul<-0 else cumul<-sum(nbmod[1:(num[1]-1)])
	        s3d$points3d(A[(cumul+1):(cumul+nbmod[num[1]]),axespar],col=num[2],type="l")
           }
	  }
        else{##cas afc simple
	     repeat {
              cat("relier des modalit�s d'une variable (o/n) ?\n")
              plta <- scan("", character(), 1)
	        if(length(plta) == 0) plta<-"n"
              if((plta == "n")) break
              cat("Rentrez 2 chiffres\n")
	        cat("ligne (1) ou colonne (2) ou ligne sup (3) ou col sup(4) et le numero de la couleur\n")
	        num<-scan("",numeric(),2)
	        if(num[1]==1) s3d$points3d(C[,axespar],col=num[2] ,type="l")
	        if(num[1]==2) s3d$points3d(A[,axespar],col=num[2] ,type="l")
              if(num[1]==3) s3d$points3d(coordlignesup[,axespar],col=num[2],type="l")
              if(num[1]==4) s3d$points3d(coordcolsup[,axespar]  ,col=num[2],type="l")
  }}}}
  if(ns == F) {
     cat("_______________________________________________________________\n")
     repeat {
        cat("representations barycentriques (o/n) ?\n")
        plta <- scan("", character(), 1)
	  if(length(plta) == 0) plta<-"n"
        if((plta == "n")) break
        cat("2D (1) ou 3D (2) :\n")
        pltd<-scan("",numeric(),1)
        if(pltd==1){
           cat("lignes au barycentre des colonnes (1) ou l'inverse (2) ?\n")
           bar <- scan("", numeric(), 1)
           cat("axe horizontal (<=", k, ") ?\n")
           pltah <- scan("", numeric(), 1)
           cat("axe vertical (<=", k, ") ?\n")
           pltav <- scan("", numeric(), 1)
           par(mfrow = c(1, 1), pty = "s")
           axespar <- c(pltah, pltav)
           if(bar == 1) {
              Z <- matrix(0, nrow = I + J, ncol = 2)
              Z[, 1] <- c(C[, axespar[1]], A[, axespar[1] ]/sqrt(valp[axespar[1]]))
              Z[, 2] <- c(C[, axespar[2]], A[, axespar[2] ]/sqrt(valp[axespar[2]])) 
              dimnames(Z) <- list(c(dimnames(C)[[1]],dimnames(A)[[1]]), c("1", "2"))
           }
           if(bar == 2) {
              Z <- matrix(0, nrow = I + J, ncol = 2)
              Z[, 1] <- c(C[, axespar[1]]/sqrt(valp[ axespar[1]]), A[, axespar[1]])
              Z[, 2] <- c(C[, axespar[2]]/sqrt(valp[ axespar[2]]), A[, axespar[2]])
              dimnames(Z) <- list(c(dimnames(C)[[1]],dimnames(A)[[1]]), c("1", "2"))
           }
           if(is.null(col.ind))        col.tot<-rep(4,dim(C)[1])
           else if(length(col.ind)==1) col.tot<-rep(col.ind,dim(C)[1])
                else                   col.tot<-col.ind
           if(is.null(col.var))        col.tot<-c(col.tot,rep(2,dim(A)[1]) )
           else if(length(col.var)==1) col.tot<-c(col.tot,rep(col.var,dim(A)[1]) )
                else                   col.tot<-c(col.tot,col.var)

           pf.plot(c(1,2),Z,NULL,col.tot,NULL,rbind(COSus,COSva),cex.lim,valp,inertia,fleches=F,COR=F)
           if(sum((diag(DI)-(1/I))^2)<1e-16){#
	        repeat {#repeat
                 cat("relier des modalit�s d'une variable (o/n) ?\n")
                 plta <- scan("", character(), 1)
		     if(length(plta) == 0) plta<-"n"
                 if((plta == "n")) break
                 
                 palette("default")
		     cat("numero de la variable (<=",length(nbmod),"), et de la couleur\n")
		     num<-scan("",numeric(),2)
		     if(num[1]==1) cumul<-0 else cumul<-sum(nbmod[1:(num[1]-1)])
		     lines(Z[(I+cumul+1):(I+cumul+nbmod[num[1]]),],col=num[2])
	        }
	     }
        }
        if(pltd==2){
           cat("lignes au barycentre des colonnes (1) ou l'inverse (2) ?\n")
           bar <- scan("", numeric(), 1)
           cat("axe des x (<=", k, ") ?\n")
           pltx <- scan("", numeric(), 1)
           cat("axe des y (<=", k, ") ?\n")
           plty <- scan("", numeric(), 1)
           cat("axe des z (<=", k, ") ?\n")
           pltz <- scan("", numeric(), 1)
           axespar <- c(pltx,plty,pltz)
           if(bar == 1) {
              Z <- matrix(0, nrow = I + J, ncol = 3)
              Z[, 1] <- c(C[, axespar[1]], A[, axespar[1] ]/sqrt(valp[axespar[1]]))
              Z[, 2] <- c(C[, axespar[2]], A[, axespar[2] ]/sqrt(valp[axespar[2]])) 
              Z[, 3] <- c(C[, axespar[3]], A[, axespar[3] ]/sqrt(valp[axespar[3]])) 
              dimnames(Z) <- list(c(dimnames(C)[[1]],dimnames(A)[[1]]), c("1", "2","3"))
           }
           if(bar == 2) {
              Z <- matrix(0, nrow = I + J, ncol = 3)
              Z[, 1] <- c(C[, axespar[1]]/sqrt(valp[ axespar[1]]), A[, axespar[1]])
              Z[, 2] <- c(C[, axespar[2]]/sqrt(valp[ axespar[2]]), A[, axespar[2]])
              Z[, 3] <- c(C[, axespar[3]]/sqrt(valp[ axespar[3]]), A[, axespar[3]])
              dimnames(Z) <- list(c(dimnames(C)[[1]],dimnames(A)[[1]]), c("1","2","3"))
           }
           if(is.null(col.ind))        col.tot<-rep(4,dim(C)[1])
           else if(length(col.ind)==1) col.tot<-rep(col.ind,dim(C)[1])
                else                   col.tot<-col.ind
           if(is.null(col.var))        col.tot<-c(col.tot,rep(2,dim(A)[1]) )
           else if(length(col.var)==1) col.tot<-c(col.tot,rep(col.var,dim(A)[1]) )
                else                   col.tot<-c(col.tot,col.var)

           s3d<-hyperplot.indiv(c(1,2,3),Z,NULL,col.tot,NULL,rbind(COSus,COSva),cex.lim,valp,inertia)
           if(sum((diag(DI)-(1/I))^2)<1e-16){#
	        repeat {#repeat
                 cat("relier des modalit�s d'une variable (o/n) ?\n")
                 plta <- scan("", character(), 1)
		     if(length(plta) == 0) plta<-"n"
                 if((plta == "n")) break
		     cat("numero de la variable (<=",length(nbmod),"), et de la couleur\n")
		     num<-scan("",numeric(),2)
		     if(num[1]==1) cumul<-0 else cumul<-sum(nbmod[1:(num[1]-1)])
		     s3d$points3d(Z[(I+cumul+1):(I+cumul+nbmod[num[1]]),],col=num[2],type="l")
   }}}}}
# fin des graphiques
}
palette("default")
sortie<-list(nomfichN, Nini, N, DI, DJ, inertia, k, valp, A, C, CTRus, COSus,CTRva, COSva,coordlignesup,coordcolsup)
names(sortie)<-c("nomfichN","Nini","N","DI","DJ","inertia","k","valp","A","C","CTRus","COSus","CTRva","COSva","coordlignesup","coordcolsup")
return(invisible(sortie))
}