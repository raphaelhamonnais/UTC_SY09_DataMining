Rclusplot <- function(X,groupes,COS,cols,cex=1.3,groupes.next,add=F,...){

if(any(COS>1)) COS <- COS/10000

nx <- nrow(X)
if(!add) plot(X[,1],X[,2],type="n",xlab="",ylab="",...)
abline(h=0)
abline(v=0)
text(X[,1],X[,2],1:nx,cex=apply(COS[,1:2],1,sum)*cex,col=cols[groupes])
moy <- centresGravite(X,groupes)
segments(x0=X[,1],
         y0=X[,2],
         x1=moy[groupes,1],
         y1=moy[groupes,2],
         col=cols[groupes])
if(!missing(groupes.next)) {
  indiv <- (1:nx)[groupes!=groupes.next]
  points(X[indiv,1],X[indiv,2],pch=21,cex=2,bg=cols[groupes.next[indiv]])
}
points(moy[,1],moy[,2],pch=21,cex=5,bg=cols)
text  (moy[,1],moy[,2],1:nrow(moy)   ,cex=1.2,font=2,col="white")


box()


}